#!/usr/bin/env python3

"""
Clones all the repository from a list of modules in .json format
Note: This script assumes git version 2.11+ or later
"""
import argparse
import json
import os
import pathlib
import shlex
import subprocess
import sys
import re
from os import path
from urllib import request
from urllib.request import Request
import tempfile
import time


RUN_PROCESS_ERROR = "RUN_PROCESS_ERROR"


def get_progress_bar(module_values):
    """
    Returns a progress bar if tqdm module is present, otherwise list of modules
    :param module_values: list of modules
    :return: progress_bar and True/False depending if tqdm is present
    """
    try:
        from tqdm import tqdm

        return tqdm(module_values), True
    except ImportError:
        prog_bar = module_values
        print(
            "* Tip: for a progress bar when cloning modules, install tqdm: sudo apt install python3-tqdm"
        )
        return prog_bar, False
    except Exception:
        print(
            "* Tip: for a progress bar when cloning modules, install tqdm: sudo apt install python3-tqdm"
        )


def auto_update():
    """
    Auto updates this repository so script is always last version
    """
    print("Looking for updates of script.")
    current_branch = run_process(
        "git -C {} rev-parse --abbrev-ref HEAD".format(REPO_PATH)
    ).strip()
    is_local_branch = run_process(
        "git ls-remote --heads {} {} | grep {}".format(
            REPO_URL, current_branch, current_branch
        )
    )
    if is_local_branch == "":
        # allow the development of this script in a branch that has not been created in the remote repo.
        # no update required
        return
    rev1 = run_process("git -C {} rev-parse HEAD".format(REPO_PATH))
    run_process("git -C {} pull".format(REPO_PATH))
    rev2 = run_process("git -C {} rev-parse HEAD".format(REPO_PATH))
    if rev1 != rev2:
        print("\n\n * Found update, you need to relaunch again this script !\n\n")
        sys.exit(-1)


def run_process(command, break_on_failure=True):
    """
    Runs a command as a subprocess and returns the result of execution, this is synchronous
    :param command: Bash command to be executed
    :param break_on_failure: Generates an exception if process exited with failure(exitcode != 0)
    :return: Result of execution
    """
    kwargs = {"stdout": subprocess.PIPE, "stderr": subprocess.PIPE}
    proc = subprocess.Popen(shlex.split(command), **kwargs)
    (stdout_str, stderr_str) = proc.communicate()
    return_code = proc.wait()
    if return_code != 0:
        if break_on_failure:
            print(stdout_str.decode("UTF-8"))
            raise Exception(stderr_str.decode("UTF-8"))
        return RUN_PROCESS_ERROR
    return stdout_str.decode("UTF-8")


def is_git_repo(path):
    return os.path.isdir(os.path.join(path, ".git"))


def get_context_definition_url(
    context_definition,
    context_definition_from_url,
    context_definition_from_local,
    context_definition_from_codesnapshot_file,
):
    if context_definition:
        context_definition_url = "https://gitlab.com/openbravo/ci/context_definitions/-/raw/master/{}.json".format(
            context_definition
        )
    elif context_definition_from_url:
        context_definition_url = context_definition_from_url
    elif context_definition_from_local:
        context_definition_url = "file://{}".format(context_definition_from_local)
    elif context_definition_from_codesnapshot_file:
        global temporaryFileForCodesnapshot
        temporaryFileForCodesnapshot = tempfile.NamedTemporaryFile()
        dest_file = temporaryFileForCodesnapshot.name
        run_process(
            "snapshot2json.py {} {}".format(
                context_definition_from_codesnapshot_file, dest_file
            )
        )
        context_definition_url = "file://{}".format(dest_file)
    else:
        context_definition_url = "https://gitlab.com/openbravo/ci/context_definitions/-/raw/master/retail/try-retail.json"
    return context_definition_url


def get_context_erp_automation_and_modules(
    context_definition_url, erp, automation, modules
):
    # User agent is needed because gitlab blocks webscrappers
    req = Request(context_definition_url, headers={"User-Agent": "Mozilla/5.0"})
    in_file = request.urlopen(req).read()
    config = json.loads(in_file.decode("utf-8"))
    if "imports" in config:
        for imp in config.get("imports"):
            context_definition_url = get_context_definition_url(
                imp.get("context-definition"),
                imp.get("context-definition-from-url"),
                imp.get("context-definition-from-file"),
                imp.get("context-definition-from-codesnapshot-file"),
            )
            erp, automation, modules = get_context_erp_automation_and_modules(
                context_definition_url, erp, automation, modules
            )
    if "erp" in config:
        erp = config["erp"]
    if "automation" in config:
        for automation_repo in config["automation"]:
            automation[automation_repo["javapackage"]] = automation_repo
    if "mods" in config:
        for mod in config["mods"]:
            modules[mod["javapackage"]] = mod
    if "deps" in config:
        for mod in config["deps"]:
            modules[mod["javapackage"]] = mod
    return erp, automation, modules


def create_output_dir(path_of_dir):
    pathlib.Path(path_of_dir).mkdir(parents=True, exist_ok=True)


def clone_repo(url, name_of_dir, ver):
    """
    Clones a repository, also creates a pristine for future clones,
    those pristines are clones with --mirror option, to save storage
    :param url: Url of the remote repository
    :param name_of_dir: Name of the directory where to clone the repository
    :param ver: Version to checkout after clone
    """
    # Reference to a local pristine of the repository, extracted from the URL
    ssh_url = url.replace("https://gitlab.com/", "git@gitlab.com:")
    https_url = url.replace("git@gitlab.com:", "https://gitlab.com/")
    reference = (
        url.replace("https://gitlab.com/", "")
        .replace("git@gitlab.com:", "")
        .replace(".git", "")
    )
    reference = path.join(pristines_dir, reference)
    if reference and path.isdir(reference):
        # Update referenced repo if possible, and then clone with reference
        run_process("git -C {} remote update".format(reference))
    else:
        # Create pristine, and then clone from it, it will take a little longer the first time, but faster on new runs
        print("Creating pristine at {}".format(reference))
        pathlib.Path(reference).mkdir(parents=True, exist_ok=True)
        try:
            if not clone_over_https:
                # Try ssh first and if it fails, swap to https
                res_clone = run_process(
                    "git clone --mirror {} {}".format(ssh_url, reference),
                    break_on_failure=True,
                )
            if clone_over_https or res_clone == RUN_PROCESS_ERROR:
                # Try to clone with https
                run_process("git clone --mirror {} {}".format(https_url, reference))
        except:
            max_wait_time = 3
            interval = 0.01
            tries = 0
            while (len(os.listdir(reference)) != 0) and (
                tries * interval < max_wait_time
            ):
                tries += 1
                time.sleep(interval)
                if len(os.listdir(reference)) == 0:
                    break
            if len(os.listdir(reference)) == 0:
                os.rmdir(reference)
            raise

    # Clones from pristine if possible, and if not from url
    if not clone_over_https:
        # Try ssh first and if it fails, swap to https
        res_clone = run_process(
            "git clone --reference {} --dissociate {} {}".format(
                reference, ssh_url, name_of_dir
            ),
            break_on_failure=False,
        )
    if clone_over_https or res_clone == RUN_PROCESS_ERROR:
        # Try to clone with https
        run_process(
            "git clone --reference {} --dissociate {} {}".format(
                reference, https_url, name_of_dir
            )
        )


def checkout_repo(name_of_dir, ver, reset_hard_to):
    branch_name = run_process(
        "git -C {} rev-parse --abbrev-ref HEAD".format(name_of_dir)
    )[:-1]
    if branch_name != ver:
        print("Fixing branch of {} from {} to {}".format(name_of_dir, branch_name, ver))
        run_process("git -C {} checkout {}".format(name_of_dir, ver))
    if with_reset_hard and reset_hard_to:
        print("Fixing reset hard of {} to {}".format(name_of_dir, reset_hard_to))
        run_process("git -C {} reset --hard {!r}".format(name_of_dir, reset_hard_to))


def fix_repo_origin(url, name_of_dir):
    repo_url = run_process(
        "git -C {} config --get remote.origin.url".format(name_of_dir)
    )[:-1]
    if url.replace("git@gitlab.com:", "https://gitlab.com/") != repo_url.replace(
        "git@gitlab.com:", "https://gitlab.com/"
    ):
        new_url = url
        if "git@gitlab.com:" in repo_url:
            new_url = new_url.replace("https://gitlab.com/", "git@gitlab.com:")
        print(
            "Fixing origin url of {} from {} to {}".format(name_of_dir, repo_url, new_url)
        )
        run_process("git -C {} remote set-url origin {}".format(name_of_dir, new_url))
        run_process("git -C {} fetch --all".format(name_of_dir))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="This script will clone a specific context_definition locally and prepare a workspace, "
        "with specified versions."
    )
    parser.add_argument(
        "--pristines-dir",
        "-p",
        help="directory where pristines will be retrieved from and saved to",
        dest="pristines_dir",
        required=True,
    )
    parser.add_argument(
        "--output-dir",
        "-o",
        help="Output directory where the workspace will be created, "
        "it will also be created if it didn't existed previously",
        dest="output_dir",
        required=True,
    )
    parser.add_argument(
        "--clone-automation",
        "-a",
        help="Use this parameter to clone also the automation repo",
        dest="clone_automation",
        action="store_true",
    )
    parser.add_argument(
        "--only-pack",
        "-k",
        help="Only clone the retail pack, ignore external modules",
        dest="only_pack",
        action="store_true",
    )
    parser.add_argument(
        "--only-erp",
        "-e",
        help="Only clone the erp, ignore all modules",
        dest="only_erp",
        action="store_true",
    )
    parser.add_argument(
        "--context-definition",
        "-c",
        help="Use a json from https://gitlab.com/openbravo/ci/context_definitions"
        "Example: retail/try-retail",
        dest="context_definition",
    )
    parser.add_argument(
        "--context-definition-from-url",
        "-u",
        help="Use a json from any url",
        dest="context_definition_from_url",
    )
    parser.add_argument(
        "--context-definition-from-file",
        "-l",
        help="Use a json from local file system",
        dest="context_definition_from_local",
    )
    parser.add_argument(
        "--context-definition-from-codesnapshot-file",
        "-s",
        help="Use a json converted from a local codesnapshot file",
        dest="context_definition_from_codesnapshot_file",
    )
    parser.add_argument(
        "--clone-over-https",
        help="Choose to clone over https instead of defaulting to ssh",
        dest="clone_over_https",
        action="store_true",
        default=False,
    )
    parser.add_argument(
        "--fix-existing-repos",
        help="Change branch or version in existing repos",
        dest="fix_existing_repos",
        action="store_true",
        default=False,
    )
    parser.add_argument(
        "--with-reset-hard",
        help="If the json has a param reset_hard_to use it and do git reset --hard to the specified version. CAUTION: could cause loss of local commits",
        dest="with_reset_hard",
        action="store_true",
        default=False,
    )
    args = parser.parse_args()

    executable_path = os.path.realpath(sys.argv[0])
    REPO_PATH = re.match(r"(.*)/[^/]*$", executable_path).group(1)
    REPO_URL = run_process("git -C {} config --get remote.origin.url".format(REPO_PATH))
    auto_update()

    print("Cloning workspace.")
    print(
        "Note: If asked to provide username iteratively, consider caching or storing your credentials:\n"
        "\tgit config --global credential.helper 'cache --timeout <Number of seconds to cache, default 900>'\n"
        "\tor git config --global credential.helper store"
    )
    pristines_dir = args.pristines_dir
    output_dir = args.output_dir
    clone_automation = args.clone_automation
    only_pack = args.only_pack
    only_erp = args.only_erp
    clone_over_https = args.clone_over_https
    fix_existing_repos = args.fix_existing_repos
    with_reset_hard = args.with_reset_hard
    context_definition_url = get_context_definition_url(
        args.context_definition,
        args.context_definition_from_url,
        args.context_definition_from_local,
        args.context_definition_from_codesnapshot_file,
    )

    print("Using context definition: {}".format(context_definition_url))

    create_output_dir(output_dir)

    repos_in_retail_pack = {
        "org.openbravo.mobile.core",
        "org.openbravo.retail.config",
        "org.openbravo.retail.discounts",
        "org.openbravo.retail.pack",
        "org.openbravo.retail.poshwmanager",
        "org.openbravo.retail.posterminal",
        "org.openbravo.retail.returns",
        "org.openbravo.retail.sampledata",
        "org.openbravo.core2",
        "org.openbravo.pos2",
        "org.openbravo.pos2.sampledata",
    }

    erp, automation, modules = get_context_erp_automation_and_modules(
        context_definition_url, {}, {}, {}
    )

    if only_pack:
        if not "org.openbravo.retail.sampledata" in modules:
            # for old pos compatibility, new pos has retail.sampledata in the json
            modules["org.openbravo.retail.sampledata"] = {
                "method": "git",
                "params": {
                    "url": "https://gitlab.com/openbravo/product/pmods/org.openbravo.retail.sampledata",
                    "ver": "master",
                },
                "javapackage": "org.openbravo.retail.sampledata",
            }
        new_modules = {}
        for mod in repos_in_retail_pack:
            if mod in modules:
                new_modules[mod] = modules[mod]
        modules = new_modules

    if only_erp:
        modules = {}

    erp_url = erp["params"]["url"]
    pristine_erp = path.join(pristines_dir, "openbravo")
    erp_ver = erp["params"]["ver"]
    erp_reset_hard_to = erp["params"].get("reset_hard_to")

    if path.isdir(path.join(output_dir, ".git")) and path.isdir(
        path.join(output_dir, "modules")
    ):
        if fix_existing_repos:
            fix_repo_origin(erp_url, output_dir)
            checkout_repo(output_dir, erp_ver, erp_reset_hard_to)
        else:
            print(
                "A git repository already exists on {}, skipping erp clone".format(
                    output_dir
                )
            )
    else:
        # Clone ERP
        print("Cloning ERP")
        clone_repo(erp_url, output_dir, erp_ver)
        checkout_repo(output_dir, erp_ver, erp_reset_hard_to)

    if clone_automation:
        for automation_repo in automation.values():
            automation_dir = path.join(
                output_dir, "../", automation_repo["javapackage"]
            )
            if path.isdir(automation_dir):
                if fix_existing_repos:
                    fix_repo_origin(automation_repo["params"]["url"], automation_dir)
                    checkout_repo(automation_dir, automation_repo["params"]["ver"], automation_repo["params"].get("reset_hard_to"))
                else:
                    print(
                        "A git repository already exists on {}, skipping automation clone".format(
                            automation_dir
                        )
                    )
            else:
                # Clone Automation
                print("Cloning automation repo " + automation_repo["javapackage"])
                clone_repo(
                    automation_repo["params"]["url"],
                    automation_dir,
                    automation_repo["params"]["ver"],
                )
                checkout_repo(automation_dir, automation_repo["params"]["ver"], automation_repo["params"].get("reset_hard_to"))

    # Module repositories
    print("Cloning modules")
    progress_bar, tqdm_available = get_progress_bar(modules.values())
    for module in progress_bar:
        if path.isdir(path.join(output_dir, "modules", module["javapackage"])):
            if fix_existing_repos:
                fix_repo_origin(
                    module["params"]["url"],
                    path.join(output_dir, "modules", module["javapackage"]),
                )
                checkout_repo(
                    path.join(output_dir, "modules", module["javapackage"]),
                    module["params"]["ver"],
                    module["params"].get("reset_hard_to")
                )
            else:
                print(
                    "A git repository already exists on {}, skipping {} clone".format(
                        output_dir, module["javapackage"]
                    )
                )
        else:
            if tqdm_available:
                progress_bar.set_description("Cloning {}".format(module["javapackage"]))
            else:
                print("Cloning {}".format(module["javapackage"]))
            clone_repo(
                module["params"]["url"],
                path.join(output_dir, "modules", module["javapackage"]),
                module["params"]["ver"],
            )
            checkout_repo(
                path.join(output_dir, "modules", module["javapackage"]),
                module["params"]["ver"],
                module["params"].get("reset_hard_to")
            )
    print("Finished cloning modules")
