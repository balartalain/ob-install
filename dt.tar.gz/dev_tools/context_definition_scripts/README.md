# README

## Important

202410: After any change to the scripts, execute these tests. They have to succed:

    ./test_all.sh


## scripts in this folder used in Jenkins

These files are a copy of these managed scripts in Jenkins
    add_revisions_to_context_definition.py          Config json add revisions
    create_context_from_context_definition.py       Config json clone repos

    These 2 files are used to fill and transfer the information of the context definition.
    They are used always together.
    The file revisions.json, the output of the add_revisions script, is not expected to be used by any other process or user. It is just a file to be consumed by the create_context script in the same job or to be passed to another job and be consumed there.

This test is executed by the ci2ci_test_add_and_clone_context_definition job
    test_add_and_clone_context_definition.sh

    The test is using these support files:
        context_definition_sample.json
        expected_revisions.json

## The rest of the files in this folder are

I+D
    v2.
        It replaces json with yml, creating smaller files and providing support for comments
        Not in production, but could be the base for a future option

        load_json_save_in_v2_format.py

        I have been testing ways to improve how we process and transfer the information of the context definition between the script that adds the revisions and the one that clones it

        tests:
            test_load_json_save_in_v2_format.py

        support files
            context_definition_sample.json
            expected_revisions.yml

        ignorable output
            revisions_json.tmp
            revisions_raw.tmp
            revisions_yml.tmp