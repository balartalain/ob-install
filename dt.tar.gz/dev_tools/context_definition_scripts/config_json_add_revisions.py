#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Config json add revisions
import time
import logging
import pathlib
import os
import re
import sys
import json
import socket
import subprocess
import shutil
import shlex
import string
import multiprocessing
import ctypes
import traceback

""" adds revisions to the json file """
""" this script can be executed in the dev computer """
""" usage:
        python3 add_revisions_to_context_definition.py json_data
        python3 add_revisions_to_context_definition.py filepath_to_json_file
        python3 add_revisions_to_context_definition.py filepath_to_json_file <source_repo>
        python3 add_revisions_to_context_definition.py snapshot_name snapshot_repo
    examples:
        python3 add_revisions_to_context_definition.py retail.json
        python3 add_revisions_to_context_definition.py Snapshot_Dev_GIT {GITLAB_ROOT}/customers/RUB/Snapshots
        python3 add_revisions_to_context_definition.py '{"desc":"Some descripttion","mods":[{"...'
"""

# tasks depending on the host executing this script
# not in production:
#   log environment variables
#   log stats
# not in builds.openbravo.com or cicd.openbravo.com
#   use git_over_ssh instead of git_over_http

# discover environment
IS_PRODUCTION_SERVER = os.getenv('IS_PRODUCTION_SERVER')  # True = builds.openbravo.com, False = cicd, None = dev computer
is_running_in_dev_computer = IS_PRODUCTION_SERVER is None
is_run_in_multiprocessing_mode = not IS_PRODUCTION_SERVER is None  # if in builds or cicd
is_convert_https_to_ssh = True  # not IS_PRODUCTION_SERVER is None # if in builds or cicd
is_production = IS_PRODUCTION_SERVER == 'true'
if (is_running_in_dev_computer):
    RETAIL_MODULES = "org.openbravo.mobile.core org.openbravo.retail.pack org.openbravo.retail.config org.openbravo.retail.posterminal org.openbravo.retail.poshwmanager org.openbravo.retail.discounts org.openbravo.retail.sampledata org.openbravo.retail.returns"
else:
    RETAIL_MODULES = os.getenv('RETAIL_MODULES')
if RETAIL_MODULES is None:
    raise Exception("RETAIL_MODULES cannot be None")

# setup environment
DRY_RUN = os.getenv('DRY_RUN_SOURCE')  # dry_run can also be set as an environment variable
# dry_run can be rue/False. False: run the script but do not make requests to the sourcecode server to ask for revisions. Fill with dummy data
if DRY_RUN is None:
    dry_run = is_running_in_dev_computer
else:
    dry_run = DRY_RUN.lower() != 'false'
log_initial_level = logging.INFO if is_production else logging.DEBUG
multiprocessing_batch_size = 10  # the maximum number of processes that can be executed at the same time, reduced to 1, related to rate limit changes in GitLab.com that affected the repo clone
if (is_run_in_multiprocessing_mode):
    multiprocessing_batch_size = 10  # in main servers (cicd and builds), too many requests create too many threads and can take down the server
gitlab_retries_when_fatal_or_error = 3  # retries when gitlab returns error 429 because too many requests per minute
gitlab_retry_wait = 60  # seconds to wait after a 429 error
force_multiprocessing_also_in_local = False

# global assignations
EXECUTABLE_NAME = pathlib.Path(os.path.basename(__file__)).stem
EXECUTABLE_PATH = os.path.dirname(os.path.realpath(__file__))

# TODO: remove IS_NEW_ROOT_IN_USE when possible. Required for testing
IS_NEW_ROOT_IN_USE = os.getenv('IS_NEW_ROOT_IN_USE', 'false').lower() == 'true'
if IS_NEW_ROOT_IN_USE:
    # from jan-2025
    GITLAB_ROOT_OLD = 'git@gitlab.com:openbravo'
    GITLAB_ROOT = 'git@gitlab.com:orisha-group/bu-retail/openbravo'
else:
    GITLAB_ROOT = 'git@gitlab.com:openbravo'
    # up to dec-2024
###

DEFAULT_CONTEXT_DEFINITIONS_REPO = f'{GITLAB_ROOT}/ci/context_definitions'
JSON_OUTPUT_FILENAME = 'revisions.json'
RETAIL_PACK_MODULES = RETAIL_MODULES.split(' ')

# region loggger

CYAN = "\033[0;36m"
GREEN = '\033[0;32m'
IRED = "\033[1;91m"
ORANGE = '\033[0;33m'
RED = "\033[0;31m"
WHITE = "\033[0;37m"
YELLOW = "\033[0;33m"
NC = '\033[0m'  # No Color

logger = logging.getLogger()
logger.setLevel(log_initial_level)
stream_handler = logging.StreamHandler()  # Common handler for all logs


# Custom formatter based on log level
class CustomFormatter(logging.Formatter):
    formats = {
        logging.ERROR: f'{RED}%(message)s{NC}',
        logging.WARNING: f'{ORANGE}%(message)s{NC}',
        logging.INFO: f'{GREEN}%(message)s{NC}',
        logging.DEBUG: '%(message)s'
    }

    def format(self, record):
        log_fmt = self.formats.get(record.levelno)
        formatter = logging.Formatter(log_fmt, datefmt='%Y-%m-%d %H:%M:%S')
        return formatter.format(record)


stream_handler.setFormatter(CustomFormatter())
logger.addHandler(stream_handler)
# endregion


# region Exceptions handler
def handle_exception(exc_type, value, exc_tb, MAX_TRACE_LINES=5) -> None:
    """
    Catch uncaught exceptions, filter and beautify the output.
    """
    extracted_tb = traceback.extract_tb(exc_tb)
    trace_info = []
    max_lens = [0, 0, 0, 0]  # idx, line_number, code_path, text lengths
    for idx, (file_path, line_number, func_name, text) in enumerate(extracted_tb):
        if EXECUTABLE_PATH in file_path:
            file_path_output = os.path.realpath(file_path).replace(EXECUTABLE_PATH + '/', '').replace(EXECUTABLE_NAME + '.py', '')
            func_name_output = '' if func_name == '<module>' else func_name
            code_path = f"{file_path_output}:{func_name_output}" if file_path_output else func_name_output
            entry = (idx + 1, line_number, code_path, text)
            for i, field in enumerate(entry):
                max_lens[i] = max(max_lens[i], len(str(field)))
            trace_info.append((idx + 1, line_number, code_path, text))
    trace_list = [
        f'\n{ORANGE}[{idx:>{max_lens[0]}}] {line_number:>{max_lens[1]}} {code_path:<{max_lens[2]}} {CYAN}{text:<{max_lens[3]}}{NC}'
        for idx, line_number, code_path, text in reversed(trace_info[-MAX_TRACE_LINES:])
    ]
    formatted_value = "\n".join(line.strip() for line in str(value).split("\n"))
    traceback_str = f"Traceback:" + "".join(trace_list) if trace_list else ""
    logger.error(f"\n{RED}{exc_type.__name__}\n{formatted_value}{NC}\n{traceback_str}")


sys.excepthook = handle_exception
# endregion


# region classes
class Thread_safe_counter(object):
    def __init__(self):
        self.val = multiprocessing.Value(ctypes.c_int, 0)

    def increment(self, n=1):
        with self.val.get_lock():
            self.val.value += n  # type: ignore
        # print(self.val.value, end=" ") # activate to track how many requests are being sent to the gitlab server

    @property
    def value(self):
        return self.val.value


# globals
dev_tools_path = None
count_of_git_commands = Thread_safe_counter()
git_stat = dict()
git_stat['clone'] = Thread_safe_counter()
git_stat['checkout'] = Thread_safe_counter()
git_stat['ls-remote'] = Thread_safe_counter()
git_stat['fatal_or_error'] = Thread_safe_counter()
# endregion


# region functions
def stat_git_command(command):
    command_splitted = command.split(' ')
    for git_command in git_stat:
        if git_command in command_splitted:
            git_stat[git_command].increment()
            return
    raise Exception("This git command has to be added to the git_stat dictionary:\n{}".format(command))


def is_git_repo(path):
    if not os.path.exists(path):
        return False
    if not os.path.exists(os.path.join(path, '.git')):
        return False
    return True


def get_first_match_line(lines, string_to_find):
    return [line for line in lines.split('\n') if string_to_find in line][0]  # return the first matched line


def get_error_message_most_significant_line(error_message):
    if 'fatal:' in error_message:
        return get_first_match_line(error_message, 'fatal:')  # return the first 'fatal:' line
    if 'error:' in error_message:
        return get_first_match_line(error_message, 'error:')  # return the first 'error:' line
    # raise Exception('Unknown error_message cannot be processed. @RM: modify the managed script. Content of the error_message:\n{}'.format(error_message))
    return error_message


def run_process(command):
    # logger.debug("Executing: {}".format(command))
    if "git " in command.lower():
        count_of_git_commands.increment()
        stat_git_command(command)
    kwargs = {}
    kwargs['stdout'] = subprocess.PIPE
    kwargs['stderr'] = subprocess.PIPE
    proc = subprocess.Popen(shlex.split(command), **kwargs)
    (stdout_str, stderr_str) = proc.communicate()
    return_code = proc.wait()
    # logger.debug(stdout_str.decode('UTF-8'))
    if return_code != 0:
        # NOTE: error 429 raises when too many requests are sent to the gitlab server. check https://about.gitlab.com/blog/2020/12/17/automation-check-in-and-rate-limit-changes-on-gitlab-dot-com/
        error_message = stderr_str.decode('UTF-8')
        # significant_error_message = get_error_message_most_significant_line(error_message)
        logger.error("{}".format(error_message))
        git_stat['fatal_or_error'].increment()
        global gitlab_retries_when_fatal_or_error  # the value will be picked for each thread (i.e: not thread safe as intented)
        if gitlab_retries_when_fatal_or_error != 0:
            gitlab_retries_when_fatal_or_error = gitlab_retries_when_fatal_or_error - 1
            logger.error("Wait and retry ({} retries left)".format(gitlab_retries_when_fatal_or_error))
            global gitlab_retry_wait
            time.sleep(gitlab_retry_wait)  # wait a bit and try again
            return run_process(command)
        else:
            raise Exception("Command failed:\n\t{}".format(command))
    return stdout_str.decode('UTF-8')


def clone_repo(repo_url, target_dir, revision, delete_existing=True):
    if delete_existing:
        if os.path.exists(target_dir):
            shutil.rmtree(target_dir)

    if (is_convert_https_to_ssh):
        repo_url = repo_url.replace("https://gitlab.com/", "git@gitlab.com:")

    # if is_git_repo(target_dir):
    #     logger.info('Updating {}'.format(repo_url))
    #     run_process("git -C {} checkout -f".format(target_dir))
    #     run_process("git -C {} pull".format(target_dir))
    # else:
    logger.info("Cloning {}".format(repo_url))
    run_process("git clone {} {}".format(repo_url, target_dir))

    # logger.debug('Moving head of {} to revision {}'.format(target_dir, revision))
    run_process("git -C {} checkout -f {}".format(target_dir, revision))
    # run_process("git -C {} pull {}".format(target_dir,revision))


def get_revisionID(method, url, revision):
    if method == 'hg':
        if dry_run:
            if revision == 'tip':
                return 'dummy_hg_rev'
            revision_hash = revision
        else:
            response = run_process("hg identify --id {} --rev {}".format(url, revision))
            revision_hash = response.strip('\n')
    else:  # default to 'git'
        if dry_run:
            if revision == 'master':
                response = 'dummy_git_rev dummy_git_text'
            else:
                response = revision
        else:
            response = run_process("git ls-remote {} {}".format(url, revision))
        if len(response.split()) < 2:
            # it does not exist as a branch. if it is a hash (hex value), assume it is fine. TODO: change this with the correct command to check if the revision exists in the repo
            if all(c in string.hexdigits for c in revision):
                revision_hash = revision
            else:
                raise Exception("The branch '{}' does not exist in '{}'".format(revision, url))
        else:
            revision_hash = response.split()[0]
    logger.info('{0: <5} {1: <45} {2}'.format(method, revision_hash, url))
    return revision_hash


def replace_keyword(url, keyword, keyword_value):
    if url.startswith(keyword):
        url = url.replace(keyword, keyword_value)
    return url


def replace_keywords(url, javapackage):
    git_group = f"{GITLAB_ROOT}/product"
    url = replace_keyword(url, "product/openbravo", os.path.join(git_group, "openbravo"))
    url = replace_keyword(url, "DEVEL/pi", os.path.join(git_group, "openbravo"))
    url = replace_keyword(url, "PMODS-BRANCHES", os.path.join(git_group, "pmods-branches"))
    url = replace_keyword(url, "PMODS", os.path.join(git_group, "pmods"))
    url = replace_keyword(url, "MODS", os.path.join(git_group, "mods"))
    url = url.replace("JAVAPACKAGE", javapackage)
    if (is_convert_https_to_ssh):
        # we will always use ssh, check the request/minute limits https://docs.gitlab.com/ee/user/gitlab_com/#rate-limits
        git_group = git_group.replace("https://gitlab.com/", "git@gitlab.com:")
        url = url.replace("https://gitlab.com/", "git@gitlab.com:")
    if IS_NEW_ROOT_IN_USE == True and GITLAB_ROOT_OLD in url:
        url = url.replace(GITLAB_ROOT_OLD, GITLAB_ROOT)
    return url, git_group


def set_revisionID(repo_entry):
    params = repo_entry['params']
    javapackage = repo_entry.get('javapackage', '')
    if repo_entry['method'] == 'git':  # default to method = git
        del repo_entry['method']
    params['url'], git_group = replace_keywords(params['url'], javapackage)
    # logger.debug(f"{params['url']} == {git_group}pmods/{javapackage}")
    params['ver'] = get_revisionID(repo_entry.get("method", "git"), params['url'], params['ver'])
    if params['url'] == f"{git_group}/pmods/{javapackage}":  # default to url = "{GITLAB_ROOT}/product/pmods/{javapackage}",
        # logger.debug("  url removed")
        del params['url']
    # logger.debug(repo_entry)


def is_json_file(file):
    if not os.path.exists(file):
        raise Exception("File not found at '{}'".format(file))
    with open(file) as f:
        try:
            json.load(f)
            return True
        except ValueError as error:
            # logger.debug("invalid json: %s" % error)
            return False


def get_tools_path(workspace):
    global dev_tools_path
    if dev_tools_path == None:
        # clone the repository containing the scripts to manage the json and snapshot files that contain the context definition
        dev_tools_pathname = 'dev_tools'
        dev_tools = f"{GITLAB_ROOT}/ci/{dev_tools_pathname}"
        dev_tools_path = os.path.join(workspace, dev_tools_pathname)
        clone_repo(dev_tools, dev_tools_path, 'master')
    return dev_tools_path


def get_definitive_json_source(workspace, json_source, context_definition_repo):
    # clone the repository where the context definition is located
    context_definition_repo_pathname = 'context_definitions'
    context_definition_repo_path = os.path.join(workspace, context_definition_repo_pathname)
    clone_repo(context_definition_repo, context_definition_repo_path, 'master')

    # process the json that contains the list of the repostiries
    json_source = os.path.join(context_definition_repo_path, json_source)
    if not is_json_file(json_source):
        snapshot_source = os.path.join(context_definition_repo_path, json_source)
        snapshot2json_output_filename = 'snapshot2json_output.json'
        run_process("{}/snapshot2json.py {} {}".format(get_tools_path(workspace), snapshot_source, snapshot2json_output_filename))
        json_source = os.path.join(workspace, snapshot2json_output_filename)
    return json_source


def add_pair_to_json(key, value, is_append):
    if is_append:
        json_with_revisions[key].append(value)
    else:
        json_with_revisions[key] = value


def multiprocessing_func(key, value, is_append):
    set_revisionID(value)
    return key, value, is_append
# endregion


json_with_revisions = {}
json_with_revisions_pack = {}


# region main
def main():
    logger.info("=========== add revisions to json/snapshot (start) ===========")

    # show initial variables
    logger.info('Environment:')
    if dry_run:
        logger.info(re.sub(r'\.?0+$', '', '\t{0: <40} {1}'.format('dry_run', dry_run)))
    else:
        logger.debug(re.sub(r'\.?0+$', '', '\t{0: <40} {1}'.format('dry_run', dry_run)))
    logger.debug(re.sub(r'\.?0+$', '', '\t{0: <40} {1}'.format('EXECUTABLE_NAME', EXECUTABLE_NAME)))
    logger.debug(re.sub(r'\.?0+$', '', '\t{0: <40} {1}'.format('IS_NEW_ROOT_IN_USE', IS_NEW_ROOT_IN_USE)))
    logger.debug(re.sub(r'\.?0+$', '', '\t{0: <40} {1}'.format('is_production', is_production)))
    logger.debug(re.sub(r'\.?0+$', '', '\t{0: <40} {1}'.format('is_running_in_dev_computer', str(is_running_in_dev_computer))))
    logger.debug(re.sub(r'\.?0+$', '', '\t{0: <40} {1}'.format('is_convert_https_to_ssh', is_convert_https_to_ssh)))
    logger.debug(re.sub(r'\.?0+$', '', '\t{0: <40} {1}'.format('is_run_in_multiprocessing_mode', is_run_in_multiprocessing_mode)))
    if is_run_in_multiprocessing_mode:
        logger.debug(re.sub(r'\.?0+$', '', '\t{0: <40} {1:6.2f}'.format('multiprocessing_batch_size', multiprocessing_batch_size)))
    logger.debug(re.sub(r'\.?0+$', '', '\t{0: <40} {1:6.2f}'.format('gitlab_retries_when_fatal_or_error', gitlab_retries_when_fatal_or_error)))
    logger.debug(re.sub(r'\.?0+$', '', '\t{0: <40} {1}'.format('log_initial_level', logging.getLevelName(log_initial_level))))

    # process arguments
    if len(sys.argv) == 1:
        raise Exception(f"Usage: {sys.argv[0]} json_filepath [context_definition_repo]")
    json_source_argv = sys.argv[1]

    logger.info(re.sub(r'\.?0+$', '', '\t{0: <40} {1}'.format('json_file', json_source_argv)))
    logger.info("")

    # enable this script to be executed in a dev computer
    if is_running_in_dev_computer:
        workspace = os.path.join('/tmp', 'execution')
        hostname = socket.gethostname()
        logger.info("NOTE: testing in '{}' at '{}'".format(hostname, workspace))
        if not os.path.exists(workspace):
            os.mkdir(workspace)
        os.chdir(workspace)
    else:
        workspace = os.getenv('WORKSPACE')

    # if the json_source_argv is already a json, return it. if not, get it from the repository
    is_json = True
    data = None
    try:
        data = json.loads(json_source_argv)
    except OSError as err:
        print("OS error: {0}".format(err))
    except ValueError as e:
        # logger.debug("no json source was provided. search for the json in a repository")
        is_json = False

    if not is_json:
        if len(sys.argv) <= 2:
            # if the repository is not provided, use the default
            context_definition_repo_argv = DEFAULT_CONTEXT_DEFINITIONS_REPO
        else:
            context_definition_repo_argv = sys.argv[2]
        logger.info("Download dev_tools and context_definition from repositories:")
        json_source = get_definitive_json_source(workspace, json_source_argv, context_definition_repo_argv)
        with open(json_source) as json_contents:
            data = json.load(json_contents)

    # process json
    chunks_to_get_revisions = []
    for group, group_value in data.items():
        # logger.debug("group: {}".format(group))
        if group == 'erp':
            chunks_to_get_revisions.append([group, group_value, False])
            continue
        if group == 'mods' or group == 'deps' or group == 'automation':  # these groups are arrays
            add_pair_to_json(group, [], False)
            for subgroup in data[group]:
                chunks_to_get_revisions.append([group, subgroup, True])
            continue
        # the rest of the groups are just added back
        add_pair_to_json(group, group_value, False)

    logger.info('Add/check revisions to the list of repositories:')
    if is_running_in_dev_computer and not force_multiprocessing_also_in_local:
        # clone the repos sequentially. added as example and because visualstudio code does not support multiprocessing debugging
        for chunk in chunks_to_get_revisions:
            (key, value, is_append) = chunk
            # logger.debug(key, value, is_append)
            (key, value, is_append) = multiprocessing_func(key, value, is_append)
            add_pair_to_json(key, value, is_append)
    else:
        # unleash the beast. clone the repos in parallel to speed up the process
        # set the revisions in parallel
        pool = multiprocessing.Pool(processes=multiprocessing_batch_size)
        multiple_results = []
        for chunk in chunks_to_get_revisions:
            multiple_results.append(pool.apply_async(multiprocessing_func, chunk))
        for res in multiple_results:
            (key, value, is_append) = res.get()
            add_pair_to_json(key, value, is_append)

    # create the output file
    json_output = os.path.join(workspace, JSON_OUTPUT_FILENAME)

    # remove any existing files
    if os.path.exists(json_output):
        os.remove(json_output)

    # save the json
    with open(json_output, 'w') as json_output_file:
        json.dump(json_with_revisions, json_output_file, separators=(',', ':'), indent=None if not dry_run else 4)
    logger.info("the json file '{}' has been created".format(json_output))

    logger.debug('')
    logger.debug('stats:')
    logger.debug(re.sub(r'\.?0+$', '', '\t{0: <40} {1:9.2f}'.format('repositories', len(chunks_to_get_revisions))))
    logger.debug(re.sub(r'\.?0+$', '', '\t{0: <40} {1:9.2f}'.format('git commands executed:', count_of_git_commands.value)))
    logger.debug(re.sub(r'\.?0+$', '', '\t{0: <40} {1:9.2f}'.format('commands/repo:', round(count_of_git_commands.value/len(chunks_to_get_revisions), 2))))
    logger.debug(re.sub(r'\.?0+$', '', '\t{0: <40}'.format('git stats:')))
    for git_command in git_stat:
        logger.debug(re.sub(r'\.?0+$', '', '\t\t{0: <22} {1:9.2f}'.format(git_command, git_stat[git_command].value)))

    logger.info("=========== add revisions to json/snapshot ( end ) ===========")
    logger.info("___")
# endregion


if __name__ == "__main__":
    main()
