#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Config json clone repos
import socket
import ctypes
import re
import glob
import shutil
import shlex
import subprocess
import os
import sys
import json
import logging
import hashlib
import multiprocessing
import pathlib
import time
import traceback

""" clone repos in json file """
""" this script can be executed in the dev computer """

# TODO
# - delete the modules that are not in the json file / wipe the workspace all the times

# args
#  0. the script will look for an environment variable called CONTEXT_DEFINITION
#  1. context_definition
#
# examples to feed arg[1] (context_definition)
# awo.json = '{"erp": {"method": "git", "params": {"url": "https://gitlab.com/openbravo/product/openbravo", "ver": "dda9525220e77a9ce565265b297785ed68c17129", "ver_orig": "master"}}, "mods": [{"method": "git", "params": {"url": "https://gitlab.com/openbravo/product/mods/org.openbravo.distributionorder", "ver": "81af15e661ce00a58635c90e8773c0e778f9854d", "ver_orig": "master"}, "javapackage": "org.openbravo.distributionorder"}, {"method": "git", "params": {"url": "https://gitlab.com/openbravo/product/pmods/org.openbravo.warehouse.advancedwarehouseoperations", "ver": "6d60f7b13259cff80dc7a23be957e2a593b4e795", "ver_orig": "master"}, "javapackage": "org.openbravo.warehouse.advancedwarehouseoperations"}, {"method": "git", "params": {"url": "https://gitlab.com/openbravo/product/pmods/org.openbravo.warehouse.advancedwarehouseoperations.printing.bartender", "ver": "fd006672a5b33d0e9e20faf4e8d76dd048742339", "ver_orig": "master"}, "javapackage": "org.openbravo.warehouse.advancedwarehouseoperations.printing.bartender"}, {"method": "git", "params": {"url": "https://gitlab.com/openbravo/product/pmods/org.openbravo.warehouse.advancedwarehouseoperations.template", "ver": "17aba07c0928bbca7c7ab6ebdc57668be9814c89", "ver_orig": "master"}, "javapackage": "org.openbravo.warehouse.advancedwarehouseoperations.template"}, {"method": "git", "params": {"url": "https://gitlab.com/openbravo/product/pmods/org.openbravo.warehouse.advancedwarehouseoperations.distributionorders", "ver": "b51db0e4ceccb7221d971ea2d749475248d9317d", "ver_orig": "master"}, "javapackage": "org.openbravo.warehouse.advancedwarehouseoperations.distributionorders"}, {"method": "git", "params": {"url": "https://gitlab.com/openbravo/product/pmods/org.openbravo.warehouse.advancedwarehouseoperations.sampledata", "ver": "9f0c15b9f93e1debacd164de142a88149e621714", "ver_orig": "master"}, "javapackage": "org.openbravo.warehouse.advancedwarehouseoperations.sampledata"}, {"method": "git", "params": {"url": "https://gitlab.com/openbravo/product/pmods/org.openbravo.warehouse.advancedwarehouseoperations.testingutils", "ver": "adb06e5bca20a5c7bac5ad293a674ddb93dc38ff", "ver_orig": "master"}, "javapackage": "org.openbravo.warehouse.advancedwarehouseoperations.testingutils"}, {"method": "git", "params": {"url": "https://gitlab.com/openbravo/product/pmods/org.openbravo.warehouse.advancedwarehouseoperations.batchwavepicking", "ver": "3607fbb0f3dd20d849e8fea5a73f96d1c11fa873", "ver_orig": "master"}, "javapackage": "org.openbravo.warehouse.advancedwarehouseoperations.batchwavepicking"}, {"method": "git", "params": {"url": "https://gitlab.com/openbravo/product/pmods/org.openbravo.warehouse.advancedwarehouseoperations.operatorloadbalancing", "ver": "e051c5fd1e946899493302228d7fb21ba5212595", "ver_orig": "master"}, "javapackage": "org.openbravo.warehouse.advancedwarehouseoperations.operatorloadbalancing"}, {"method": "git", "params": {"url": "https://gitlab.com/openbravo/product/pmods/org.openbravo.warehouse.advancedwarehouseoperations.edl", "ver": "7fa0fdf5a9906033ef22e38aaf3dc2693614f6c6", "ver_orig": "master"}, "javapackage": "org.openbravo.warehouse.advancedwarehouseoperations.edl"}, {"method": "git", "params": {"url": "https://gitlab.com/openbravo/product/mods/org.openbravo.distributionorder.es_ES", "ver": "2fe8809618549a3d7c5dd23c1ca21ee3395dc3ca", "ver_orig": "master"}, "javapackage": "org.openbravo.distributionorder.es_ES"}, {"method": "git", "params": {"url": "https://gitlab.com/openbravo/product/pmods/org.openbravo.warehouse.advancedwarehouseoperations.distributionorders.es_ES", "ver": "81b0e5937bca520b168744f54ca5c3bf07b9f4d4", "ver_orig": "master"}, "javapackage": "org.openbravo.warehouse.advancedwarehouseoperations.distributionorders.es_ES"}, {"method": "git", "params": {"url": "https://gitlab.com/openbravo/product/pmods/org.openbravo.warehouse.advancedwarehouseoperations.es_ES", "ver": "f8c3d684ba9ec27e2bb34af279f84eb9961ffc58", "ver_orig": "master"}, "javapackage": "org.openbravo.warehouse.advancedwarehouseoperations.es_ES"}, {"method": "git", "params": {"url": "https://gitlab.com/openbravo/product/pmods/org.openbravo.warehouse.advancedwarehouseoperations.printing.bartender.es_ES", "ver": "87056b00c7de6f9aaeb6f53bc602fbf469acc168", "ver_orig": "master"}, "javapackage": "org.openbravo.warehouse.advancedwarehouseoperations.printing.bartender.es_ES"}], "deps": [{"method": "git", "params": {"url": "https://gitlab.com/openbravo/product/mods/org.openbravo.utility.opencsv", "ver": "2d9c6331e4f88d33892779946e771391ce1e4ed2", "ver_orig": "master"}, "javapackage": "org.openbravo.utility.opencsv"}, {"method": "git", "params": {"url": "https://gitlab.com/openbravo/product/pmods/org.openbravo.mobile.core", "ver": "639df74f1cffee0bd25bf515bd0e231bb4408e38", "ver_orig": "master"}, "javapackage": "org.openbravo.mobile.core"}, {"method": "git", "params": {"url": "https://gitlab.com/openbravo/product/pmods/org.openbravo.externaldata.integration", "ver": "bfbcf5aa9ff60c2221176fa0a4a5ec9dd7c369b2", "ver_orig": "master"}, "javapackage": "org.openbravo.externaldata.integration"}, {"method": "git", "params": {"url": "https://gitlab.com/openbravo/product/pmods/org.openbravo.service.external.integration", "ver": "8f4bdb7547ec2baf6f3bba9b639ead3aa0f7addd", "ver_orig": "master"}, "javapackage": "org.openbravo.service.external.integration"}], "scripts": {"checks-without-tomcat": [{"file": "awo_junit.sh", "params": ["/srv/ci/workspace/mod-awo"]}]}}'
# with hg = '{"desc":"Snapshot_BUT_Upgrade_Modules","erp":{"method":"git","params":{"url":"https://gitlab.com/openbravo/product/openbravo","ver":"master","ver_orig":"master"}},"mods":[{"method":"hg","params":{"url":"http://depots.phidias.fr:8090/phidiasrepo/hg/fr.phidias.openbravo.ecotax","ver":"71e045c19009","ver_orig":"71e045c190093b59c5fb4fe7a29a5b004349f6a5"},"javapackage":"fr.phidias.openbravo.ecotax"},{"method":"hg","params":{"url":"http://depots.phidias.fr:8090/phidiasrepo/hg/fr.phidias.openbravo.retail.ecotax","ver":"7b03859943a2","ver_orig":"7b03859943a220001f7ae33eac9b3dfeb9a1d4f9"},"javapackage":"fr.phidias.openbravo.retail.ecotax"}]}'
# with scripts = '{"desc":"Config for retail team","erp":{"method":"git","params":{"url":"https://gitlab.com/openbravo/product/openbravo","ver":"0c00c52ea9344566da701f054d6942a89d46fba7","ver_orig":"master"}},"scripts":{"checks-without-tomcat":[{"file":"retail_junit.sh","params":["/srv/ci/workspace/mod-retail"]}]},"checks-with-tomcat":[{"file":"retail_junit_tomcat.sh","params":["/srv/ci/workspace/mod-retail"]}]}}'
# erp.json = '{"erp": {"method": "git", "params": {"url": "https://gitlab.com/openbravo/product/openbravo", "ver": "dda9525220e77a9ce565265b297785ed68c17129", "ver_orig": "master"}}}'
# retail_pack.json = '{"erp": {"method": "git", "params": {"url": "https://gitlab.com/openbravo/product/openbravo", "ver": "dda9525220e77a9ce565265b297785ed68c17129", "ver_orig": "master"}}, "mods": [{"method": "git", "params": {"url": "https://gitlab.com/openbravo/product/pmods/org.openbravo.mobile.core", "ver": "639df74f1cffee0bd25bf515bd0e231bb4408e38", "ver_orig": "master"}, "javapackage": "org.openbravo.mobile.core"}, {"method": "git", "params": {"url": "https://gitlab.com/openbravo/product/pmods/org.openbravo.retail.pack", "ver": "7b19b40caa58dd71f42fdcec01c5fc6725c0cfa1", "ver_orig": "master"}, "javapackage": "org.openbravo.retail.pack"}, {"method": "git", "params": {"url": "https://gitlab.com/openbravo/product/pmods/org.openbravo.retail.config", "ver": "5b1cdb8bf081ae080f4f06b41eed6f72144f9e58", "ver_orig": "master"}, "javapackage": "org.openbravo.retail.config"}, {"method": "git", "params": {"url": "https://gitlab.com/openbravo/product/pmods/org.openbravo.retail.posterminal", "ver": "7324ca91d074dc84ea4c70e938375f302c758524", "ver_orig": "master"}, "javapackage": "org.openbravo.retail.posterminal"}, {"method": "git", "params": {"url": "https://gitlab.com/openbravo/product/pmods/org.openbravo.retail.poshwmanager", "ver": "8178490349f07de593140059df7e5fc5204a4cd1", "ver_orig": "master"}, "javapackage": "org.openbravo.retail.poshwmanager"}, {"method": "git", "params": {"url": "https://gitlab.com/openbravo/product/pmods/org.openbravo.retail.discounts", "ver": "50388e03e9dd941d7f8f288ed1dbea6d43c07de6", "ver_orig": "master"}, "javapackage": "org.openbravo.retail.discounts"}, {"method": "git", "params": {"url": "https://gitlab.com/openbravo/product/pmods/org.openbravo.retail.sampledata", "ver": "79c07d37ec0bba4679bb3b112959342bab77e516", "ver_orig": "master"}, "javapackage": "org.openbravo.retail.sampledata"}, {"method": "git", "params": {"url": "https://gitlab.com/openbravo/product/pmods/org.openbravo.retail.returns", "ver": "97c6a5f6a51516f185e713acbfcbbc9e35282f8e", "ver_orig": "master"}, "javapackage": "org.openbravo.retail.returns"}]}'
# erp with tests = {"desc": "config for jobs in builds.openbravo.com", "erp": {"method": "git", "params": {"url": "https://gitlab.com/openbravo/product/openbravo.git", "ver": "e6da5ee6275a5db671255def22f8952b24b6bbb5"}}, "mods": [], "automation": [{"method": "git", "params": {"url": "https://gitlab.com/openbravo/ci/backoffice-test", "ver": "90247690f1361b7dab2a51a098b88b11f1097057"}, "javapackage": "backoffice-test"}]}

# discover environment
hostname = socket.gethostname()
IS_PRODUCTION_SERVER = os.getenv('IS_PRODUCTION_SERVER')  # True = builds.openbravo.com, False = cicd, None = dev computer
is_running_in_dev_computer = IS_PRODUCTION_SERVER is None
is_production = IS_PRODUCTION_SERVER == 'true'
if (is_running_in_dev_computer):
    RETAIL_MODULES = "org.openbravo.mobile.core org.openbravo.retail.pack org.openbravo.retail.config org.openbravo.retail.posterminal org.openbravo.retail.poshwmanager org.openbravo.retail.discounts org.openbravo.retail.sampledata org.openbravo.retail.returns"
else:
    RETAIL_MODULES = os.getenv('RETAIL_MODULES')

# setup environment
DRY_RUN = os.getenv('DRY_RUN_SOURCE')  # dry_run can also be set as an environment variable
# dry_run can be rue/False. False: run the script but do not make requests to the sourcecode server to ask for revisions. Fill with dummy data
if DRY_RUN is None:
    dry_run = is_running_in_dev_computer
else:
    dry_run = DRY_RUN.lower() != 'false'
log_initial_level = logging.INFO if is_production else logging.DEBUG
multiprocessing_batch_size = 10  # the maximum number of processes that can be executed at the same time, reduced to 1, related to rate limit changes in GitLab.com that affected the repo clone
if (hostname == 'builds.openbravo.com' or hostname == 'cicd.openbravo.com'):
    multiprocessing_batch_size = 10  # in main servers (cicd and builds), too many requests create too many threads and can take them down the server
gitlab_retries_when_fatal_or_error = 5  # retries when gitlab returns error 429 because too many requests per minute
gitlab_retry_wait = 60  # seconds to wait after a 429 error
force_multiprocessing_also_in_local = True

# global assignations
EXECUTABLE_NAME = pathlib.Path(os.path.basename(__file__)).stem
EXECUTABLE_PATH = os.path.dirname(os.path.realpath(__file__))


# TODO: remove IS_NEW_ROOT_IN_USE when possible. Required for testing
IS_NEW_ROOT_IN_USE = os.getenv('IS_NEW_ROOT_IN_USE', 'false').lower() == 'true'
if IS_NEW_ROOT_IN_USE:
    # from jan-2025
    GITLAB_ROOT = 'git@gitlab.com:orisha-group/bu-retail/openbravo'
else:
    # up to dec-2024
    GITLAB_ROOT = 'git@gitlab.com:openbravo'
###

DEFAULT_CONTEXT_DEFINITIONS_REPO = f'{GITLAB_ROOT}/ci/context_definitions.git'
RETAIL_PACK_MODULES = RETAIL_MODULES.split(' ')


# region loggger

CYAN = "\033[0;36m"
GREEN = '\033[0;32m'
IRED = "\033[1;91m"
ORANGE = '\033[0;33m'
RED = "\033[0;31m"
WHITE = "\033[0;37m"
YELLOW = "\033[0;33m"
NC = '\033[0m'  # No Color

logger = logging.getLogger()
logger.setLevel(log_initial_level)
stream_handler = logging.StreamHandler()  # Common handler for all logs


# Custom formatter based on log level
class CustomFormatter(logging.Formatter):
    formats = {
        logging.ERROR: f'{RED}%(message)s{NC}',
        logging.WARNING: f'{ORANGE}%(message)s{NC}',
        logging.INFO: f'{GREEN}%(message)s{NC}',
        logging.DEBUG: '%(message)s'
    }

    def format(self, record):
        log_fmt = self.formats.get(record.levelno)
        formatter = logging.Formatter(log_fmt, datefmt='%Y-%m-%d %H:%M:%S')
        return formatter.format(record)


stream_handler.setFormatter(CustomFormatter())
logger.addHandler(stream_handler)
# endregion


# region Exceptions handler
def handle_exception(exc_type, value, exc_tb, MAX_TRACE_LINES=5) -> None:
    """
    Catch uncaught exceptions, filter and beautify the output.
    """
    extracted_tb = traceback.extract_tb(exc_tb)
    trace_info = []
    max_lens = [0, 0, 0, 0]  # idx, line_number, code_path, text lengths
    for idx, (file_path, line_number, func_name, text) in enumerate(extracted_tb):
        if EXECUTABLE_PATH in file_path:
            file_path_output = os.path.realpath(file_path).replace(EXECUTABLE_PATH + '/', '').replace(EXECUTABLE_NAME + '.py', '')
            func_name_output = '' if func_name == '<module>' else func_name
            code_path = f"{file_path_output}:{func_name_output}" if file_path_output else func_name_output
            entry = (idx + 1, line_number, code_path, text)
            for i, field in enumerate(entry):
                max_lens[i] = max(max_lens[i], len(str(field)))
            trace_info.append((idx + 1, line_number, code_path, text))
    trace_list = [
        f'\n{ORANGE}[{idx:>{max_lens[0]}}] {line_number:>{max_lens[1]}} {code_path:<{max_lens[2]}} {CYAN}{text:<{max_lens[3]}}{NC}'
        for idx, line_number, code_path, text in reversed(trace_info[-MAX_TRACE_LINES:])
    ]
    formatted_value = "\n".join(line.strip() for line in str(value).split("\n"))
    traceback_str = f"Traceback:" + "".join(trace_list) if trace_list else ""
    logger.error(f"\n{RED}{exc_type.__name__}\n{formatted_value}{NC}\n{traceback_str}")


sys.excepthook = handle_exception
# endregion


class Thread_safe_counter(object):
    def __init__(self):
        self.val = multiprocessing.Value(ctypes.c_int, 0)

    def increment(self, n=1):
        with self.val.get_lock():
            self.val.value += n
        # print(self.val.value, end=" ") # activate to track how many requests are being sent to the gitlab server

    @property
    def value(self):
        return self.val.value


# globals
count_of_git_commands = Thread_safe_counter()
git_stat = dict()
git_stat['clone'] = Thread_safe_counter()
git_stat['checkout'] = Thread_safe_counter()
git_stat['fetch'] = Thread_safe_counter()
git_stat['fatal_or_error'] = Thread_safe_counter()


def stat_git_command(command):
    command_splitted = command.split(' ')
    for git_command in git_stat:
        if git_command in command_splitted:
            git_stat[git_command].increment()
            return
    raise Exception("This git command has to be added to the git_stat dictionary:\n{}".format(command))


def check_condition(check, msg_if_error):
    """Show descriptive initialization errors"""
    if not check:
        logger.info('')
        logger.info("Usage: python {} context_definition_in_json_format".format(os.path.basename(__file__)))
        raise Exception("{}".format(msg_if_error))


class RepoInfo:

    def __init__(self, method, target_folder, url, desired_namespace, revision, skip):
        self.method = method
        self.revision = revision
        self.target_folder = target_folder
        self.url = url
        self.desired_namespace = 'backoffice' if not desired_namespace else desired_namespace
        self.skip = skip  # e.g. when a ret-test job requires only retail pack modules
        self.url_namespace = self.url.rsplit('/', 1)[0]
        self.hashed = self.get_hash(self.url_namespace, self.desired_namespace)

    def __str__(self):
        return '{0: <5} {1: <45} {2}'.format(self.method, self.revision, self.url)

    def get_hash(self, url_namespace, desired_namespace):
        # NOTE: the resulting hash must be same as in the pipelines
        #   (RepoInfo class): hashedNamespace = String.format("%s#%s", MessageDigest.getInstance("MD5").digest(uriBase.bytes).encodeHex().toString(), namespace)
        # e.g:
        # 	if url = 'https://bitbucket.org/gpscode/but_com.openbravo.but.reports-but-upgrade-dev'
        # 	the hashed_namespace = 51717a28446cc46e536c429e7ad17e98#but_com.openbravo.but.reports-but-upgrade-dev
        return "{}#{}".format(hashlib.md5(url_namespace.encode()).hexdigest(), desired_namespace)

    def clone(self):
        if self.skip:
            logger.info('{0: <45} {1: <10} {2}'.format(self.revision, '  -  ', self.url))
            return
        HG = 'hg'
        if self.method == HG:
            self.__clone_hg_repo()
        else:
            self.__clone_git_repo()

    def __clone_hg_repo(self):
        logger.info('{0: <45} {1: <10} {2}'.format(self.revision, 'clone', self.url))
        run_process("hg clone {} -r {} {}".format(self.url, self.revision, self.target_folder))

    def __clone_git_repo(self):
        """ git clone using gitcache """
        if self.desired_namespace == '':
            self.desired_namespace = self.url.rsplit('/', 1)[-1]
            self.desired_namespace = self.desired_namespace.replace('.git', '')

        # Ensure the reference repository directory exists
        if not os.path.exists(git_reference_root_path):
            os.makedirs(git_reference_root_path)

        repo_cache_path = os.path.join(git_reference_root_path, self.hashed)
        # Check if the reference repository needs to be created or updated
        if not os.path.exists(repo_cache_path):
            logger.debug(f"    Adding repo to cache: {self.hashed}")
            run_process("git clone --mirror {} {}".format(self.url, repo_cache_path))
        else:
            # logger.debug('Updating reference repo in cache')
            run_process("git -C {} fetch --all --prune".format(repo_cache_path))

        # Handle the target folder based on its status
        if is_git_repo(self.target_folder):
            logger.info('{0: <45} {1: <10} {2}'.format(self.revision, 'fetch', self.url))
            run_process("git -C {} fetch --prune".format(self.target_folder))
        else:
            logger.info('{0: <45} {1: <10} {2}'.format(self.revision, 'clone', self.url))
            if not is_dir_empty(self.target_folder):
                logger.info("    The target directory '{}' was dirty. Removed all files.".format(self.target_folder))
                empty_directory(self.target_folder)
            run_process("git clone --reference {} {} {}".format(repo_cache_path, self.url, self.target_folder))

        # logger.debug('Moving head to revision {}'.format(self.revision))
        run_process("git -C {} checkout -f {}".format(self.target_folder, self.revision))


def get_first_match_line(lines, string_to_find):
    return [line for line in lines.split('\n') if string_to_find in line][0]  # return the first matched line


def get_error_message_most_significant_line(error_message):
    error_msg = ""
    if 'fatal:' in error_message:
        error_msg = get_first_match_line(error_message, 'fatal:')  # return the first 'fatal:' line
    if 'ERROR:' in error_message:
        error_msg = error_msg + "\n" + get_first_match_line(error_message, 'ERROR:')  # return the first 'error:' line
    # raise Exception('Unknown error_message cannot be processed. @RM: modify the managed script. Content of the error_message:\n{}'.format(error_message))
    if error_msg != "":
        return error_msg
    else:
        return error_message


def run_process(command):
    # logger.debug("Executing: {}".format(command))
    if "git " in command.lower():
        count_of_git_commands.increment()
        stat_git_command(command)
    if dry_run:
        return
    kwargs = {}
    kwargs['stdout'] = subprocess.PIPE
    kwargs['stderr'] = subprocess.PIPE
    proc = subprocess.Popen(shlex.split(command), **kwargs)
    (stdout_str, stderr_str) = proc.communicate()
    return_code = proc.wait()
    # logger.debug(stdout_str.decode('UTF-8'))
    if return_code != 0:
        # NOTE: error 429 raises when too many requests are sent to the gitlab server. check https://about.gitlab.com/blog/2020/12/17/automation-check-in-and-rate-limit-changes-on-gitlab-dot-com/
        error_message = stderr_str.decode('UTF-8')
        significant_error_message = get_error_message_most_significant_line(error_message)
        logger.error("{}".format(significant_error_message))
        git_stat['fatal_or_error'].increment()
        global gitlab_retries_when_fatal_or_error  # the value will be picked for each thread (i.e: not thread safe as intented)
        if gitlab_retries_when_fatal_or_error != 0:
            gitlab_retries_when_fatal_or_error = gitlab_retries_when_fatal_or_error - 1
            logger.error("Wait and retry ({} retries left)".format(gitlab_retries_when_fatal_or_error))
            global gitlab_retry_wait
            time.sleep(gitlab_retry_wait)  # wait a bit and try again
            run_process(command)
        else:
            raise Exception("Command failed:\n\t{}\n{}".format(command, error_message))


def is_dir_empty(path):
    if os.path.exists(path) and os.path.isdir(path):
        if not os.listdir(path):
            return True
        else:
            return False
    else:
        # the directory doesn't exist
        return True


def is_git_repo(path):
    if not os.path.exists(path):
        return False
    if not os.path.exists(os.path.join(path, '.git')):
        return False
    return True


def delete_file_or_dir(file_or_dir):
    if not os.path.exists(file_or_dir):
        return False
    if os.path.isdir(file_or_dir):
        shutil.rmtree(file_or_dir)
    else:
        os.remove(file_or_dir)
    return True


def empty_directory(path):
    contents = glob.glob("{}/*".format(path))
    for i in contents:
        delete_file_or_dir(i)
    contents = glob.glob("{}/.*".format(path))
    for i in contents:
        delete_file_or_dir(i)


def replace_keyword(url, keyword, keyword_value):
    if url.startswith(keyword):
        url = url.replace(keyword, keyword_value)
    return url


def replace_keywords(url, javapackage):
    git_group = f"{GITLAB_ROOT}/product"
    if url == None:
        url = f"PMODS/{javapackage}"
    url = replace_keyword(url, "product/openbravo", os.path.join(git_group, "openbravo"))
    url = replace_keyword(url, "DEVEL/pi", os.path.join(git_group, "openbravo"))
    url = replace_keyword(url, "PMODS-BRANCHES", os.path.join(git_group, "pmods-branches"))
    url = replace_keyword(url, "PMODS", os.path.join(git_group, "pmods"))
    url = replace_keyword(url, "MODS", os.path.join(git_group, "mods"))
    url = url.replace("JAVAPACKAGE", javapackage)
    if (hostname != 'builds.openbravo.com' and hostname != 'cicd.openbravo.com'):
        # use git_over_ssh from the containers. git_over_ssh gitlab.com limits are lower that git_over_https
        url = url.replace("https://gitlab.com/", "git@gitlab.com:")
    return url


def add_repo_to_pool(method, url, javapackage, revision, destination_path, skip=False):
    global repos_to_process
    url_expanded = replace_keywords(url, javapackage)
    repos_to_process.append(RepoInfo(method, destination_path, url_expanded, javapackage, revision, skip))


def clone_group(group_name, revisions, modsToTest, destination_path):
    if group_name not in revisions.keys():
        return
    if not os.path.exists(destination_path):
        os.makedirs(destination_path)
    group_content = revisions[group_name]
    for mod in group_content:
        mod_javapackage = mod["javapackage"]
        mod_params = mod["params"]
        mod_url = mod_params.get('url', None)
        mod_ver = mod_params["ver"]
        mod_method = mod.get('method', 'git')
        if group_name == 'mods':  # all mods in the 'mods' group are eligible for testing
            with open(modsToTest, "a") as modsToTest_file:
                modsToTest_file.write("{}\n".format(mod_javapackage))
        skip = False
        add_repo_to_pool(mod_method, mod_url, mod_javapackage, mod_ver, os.path.join(destination_path, mod_javapackage), skip)


def multiprocessing_func(ri):
    ri.clone()


repos_to_process = []

# region main


def main():
    logger.info("=========== clone repos based on json (start) ===========")

    # show initial variables
    if dry_run:
        logger.info('\tdry_run                       {}'.format(dry_run))
    else:
        logger.debug('\tdry_run                       {}'.format(dry_run))
    logger.debug('\tIS_NEW_ROOT_IN_USE            {}'.format(IS_NEW_ROOT_IN_USE))
    logger.debug('\tIS_PRODUCTION_SERVER          {}'.format(IS_PRODUCTION_SERVER))
    logger.debug('\tis_production                 {}'.format(is_production))
    logger.debug('\tmultiprocessing_batch_size    {}'.format(multiprocessing_batch_size))
    logger.debug('\tlog_initial_level             {}'.format(logging.getLevelName(log_initial_level)))
    logger.debug('\tis_running_in_dev_computer    {}'.format(is_running_in_dev_computer))
    logger.info("")

    # enable this script to be executed in a dev computer
    global git_reference_root_path
    if is_running_in_dev_computer:
        logger.info("NOTE: testing in '{}' (presumably a dev host)".format(hostname))
        # change to the directory where the running script file(.py) exists
        this_script_location = os.path.dirname(os.path.abspath(__file__))
        workspace = os.path.join('/tmp', 'execution')
        if not os.path.exists(workspace):
            os.makedirs(workspace)
        os.chdir(workspace)
        git_reference_root_path = '/tmp/srvci/repositories/git'
        if not os.path.exists(git_reference_root_path):
            os.makedirs(git_reference_root_path)
        job_name = 'try-ret-x'
    else:
        workspace = os.getenv('WORKSPACE')
        if dry_run:
            workspace = os.path.join(workspace, "dry_run")
            if not os.path.isdir(workspace):
                os.makedirs(workspace)
        git_reference_root_path = '/srv/ci/node_shared/repositories/git'
        job_name = os.getenv('JOB_NAME')

    context_definition = os.getenv('CONTEXT_DEFINITION') or os.getenv('REPO_REVISIONS') or (sys.argv[1] if len(sys.argv) > 1 else None)
    # checks
    check_condition(context_definition, "You must create an environment variable named CONTEXT_DEFINITION or REPO_REVISIONS with the json or provide its contents as the first argument for this script")
    if context_definition is None:
        raise Exception("context_definition cannot be None")
    check_condition(len(context_definition) > 10, "The context definition does not have valid content. Got:\n'{}'".format(context_definition))

    GIT = 'git'
    modules_path = os.path.join(workspace, 'modules')
    sandbox_path = os.path.join(workspace, 'SANDBOX')
    modsToTest = os.path.join(sandbox_path, 'modsToTest')
    automation_repo_retail = os.getenv('AUTOMATION_REPO_RETAIL')

    # load the json
    try:
        revisions = json.loads(context_definition)
    except ValueError as e:
        raise Exception(f"Failed to convert the context definition in a json: {e}")

    # erp
    if 'erp' in revisions.keys():
        erp_method = revisions["erp"].get('method', "git")
        erp_params = revisions["erp"]["params"]
        # erp_url = erp_params["url"]
        # erp_ver = erp_params["ver"]
        ri = RepoInfo(erp_method, os.path.join(workspace, '.'), erp_params["url"], '', erp_params["ver"], False)
        ri.clone()  # the erp must be cloned first. the rest are added to the multitasking pool

    # FIXME: we cannot add any content to the workspace before the erp is cloned because it is done in the workspace folder and removes any existint content. we should never clone a repo in the root of the workspace

    if not os.path.isdir(sandbox_path):
        os.makedirs(sandbox_path)

    if os.path.isfile(modsToTest):
        os.remove(modsToTest)
    os.mknod(modsToTest)  # the file must exits, even if empty

    # collect all the repositories and add them to the pool

    clone_group('mods', revisions, modsToTest, modules_path)

    clone_group('deps', revisions, modsToTest, modules_path)

    if 'scripts' in revisions.keys():
        scripts_repos = {}
        for mod in revisions['scripts']:
            script_group = revisions['scripts'][mod]
            for script_info in script_group:
                if not 'url' in script_info:
                    # add the default tools repo if it is not specified
                    scripts_repos['context_definitions'] = DEFAULT_CONTEXT_DEFINITIONS_REPO
        for javapackage in scripts_repos:
            tools_path = os.path.join(workspace, 'SANDBOX', 'tools', javapackage)
            add_repo_to_pool(GIT, scripts_repos[javapackage], javapackage, 'master', tools_path)

    # add the automation repositories, if any
    if job_name == 'mod-selenium' and not 'automation' in revisions.keys():
        revisions['automation'] = []
        automation = revisions['automation']
        mobile_test = {}
        mobile_test["javapackage"] = automation_repo_retail
        mobile_test["method"] = 'git'
        mobile_test["params"] = {}
        mobile_test["params"]["url"] = f"{GITLAB_ROOT}/ci/{automation_repo_retail}"
        mobile_test["params"]["ver"] = 'master'
        automation.append(mobile_test)
        logger.debug("Missing automation key in json. Adding {}".format(mobile_test['javapackage']))
    if 'automation' in revisions.keys():
        for automation in revisions['automation']:
            automation_path = os.path.join(workspace, 'SANDBOX', 'automation', automation["javapackage"])
            add_repo_to_pool(automation.get('method', "git"), automation["params"]["url"], automation["javapackage"], automation["params"]["ver"], automation_path)

    # add api repositories, for api jobs
    api_jobs = ['try-ret-api', 'ret-api', 'try-api', 'int-api']
    if job_name in api_jobs:
        if 'backoffice_api' in revisions.keys():
            for backoffice_api in revisions['backoffice_api']:
                backoffice_api_path = os.path.join(workspace, 'SANDBOX', backoffice_api["javapackage"])
                add_repo_to_pool(backoffice_api.get('method', "git"), backoffice_api["params"]["url"], backoffice_api["javapackage"], backoffice_api["params"]["ver"], backoffice_api_path)
        if 'mobile_api' in revisions.keys():
            for mobile_api in revisions['mobile_api']:
                mobile_api_path = os.path.join(workspace, 'SANDBOX', mobile_api["javapackage"])
                add_repo_to_pool(mobile_api.get('method', "git"), mobile_api["params"]["url"], mobile_api["javapackage"], mobile_api["params"]["ver"], mobile_api_path)

    if is_running_in_dev_computer:
        # clone the repos sequentially. added as example and because visualstudio code does not support multiprocessing debugging
        for ri in repos_to_process:
            # logger.info(ri)
            ri.clone()
    else:
        # unleash the beast. clone the repos in parallel to speed up the process
        pool = multiprocessing.Pool(processes=multiprocessing_batch_size)
        pool.map(multiprocessing_func, repos_to_process)
        pool.close()

    if not is_production:
        logger.info('')
        logger.info('stats:')
        logger.info(re.sub(r'\.?0+$', '', '\t{0: <30} {1:9.2f}'.format('repositories', len(repos_to_process) + 1)))
        logger.info(re.sub(r'\.?0+$', '', '\t{0: <30} {1:9.2f}'.format('git commands executed:', count_of_git_commands.value)))
        logger.info(re.sub(r'\.?0+$', '', '\t{0: <30} {1:9.2f}'.format('commands/repo:', round(count_of_git_commands.value/(len(repos_to_process) + 1), 2))))
        logger.info(re.sub(r'\.?0+$', '', '\t{0: <30} {1:9.2f}'.format('git stats:', len(git_stat))))
        for git_command in git_stat:
            logger.info('\t\t{0: <27} {1:}'.format(git_command, git_stat[git_command].value))

    logger.info("=========== clone repos based on json ( end ) ===========")
    logger.info("___")
    # endregion


if __name__ == "__main__":
    main()
