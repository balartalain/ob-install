#!/usr/bin/env python3

import os
import sys
import json
import os
import socket
import subprocess
import shlex


verbose = False
is_running_in_dev_computer = not os.getenv('WORKSPACE')


def is_git_repo(path):
    if not os.path.exists(path):
        return False
    if not os.path.exists(os.path.join(path, '.git')):
        return False
    return True

def run_process(command):
    if verbose:
        print("Executing: {}".format(command))
    kwargs = {}
    kwargs['stdout'] = subprocess.PIPE
    kwargs['stderr'] = subprocess.PIPE
    proc = subprocess.Popen(shlex.split(command), **kwargs)
    (stdout_str, stderr_str) = proc.communicate()
    return_code = proc.wait()
    if verbose:
        print(stdout_str.decode('UTF-8'))
    if return_code != 0:
        print(stdout_str.decode('UTF-8'))
        raise Exception(stderr_str.decode('UTF-8'))
    return stdout_str.decode('UTF-8')

def get_revisionID(method, url, revision):
    if method == 'git':
        response = run_process("git ls-remote {} {}".format(url, revision))
        if len(response.split()) < 2:
            # it does not exist as a branch. if it is a hash (hex value), assume it is fine. TODO: change this with the correct command to check if the revision exists in the repo
            if all(c in string.hexdigits for c in revision):
                revision_hash = revision
            else:
                raise Exception("ERROR: the branch '{}' does not exist in '{}'".format(revision, url))
        else:
            revision_hash = response.split()[0]
    elif method == 'hg':
        response = run_process("hg identify --id {} --rev {}".format(url, revision))
        revision_hash = response.strip('\n')
    else:
        raise Exception("ERROR: the {} method is not valid or has not been implemented".format(method))
    print('{0: <5} {1: <45} {2}'.format(method, revision_hash, url))
    return revision_hash

def get_url_hash(ws_path):
    # FIXME: this is a very weak way to get the path
    path = run_process("git -C {} remote -v".format(ws_path))
    #path = run_process("git -C {} log -1 --pretty='format:%H'".format(ws_path))
    url = path.split()[1]
    if verbose:
        print ("path of", ws_path,':', url)

    # url = repo.remote("origin").url
    #revision_hash = get_revisionID('git', url, 'master')
    revision_hash = run_process("git -C {} log -1 --pretty='format:%H'".format(ws_path))
    return [url, revision_hash]


def get_repos_from_path(path_name, group_name):
    mod_config[group_name] = []
    repos_path = os.path.join(workspace, path_name)
    dir_list = []
    if os.path.exists(repos_path):
        dir_list = os.listdir(repos_path)
    for repo in dir_list:
        repo_path = os.path.join(repos_path, repo)
        is_git = is_git_repo(repo_path)
        if is_git:
            (url, hashid) = get_url_hash(repo_path)
            mod_config[group_name].append({"method": "git", "params": {"url": url, "ver": hashid}, "javapackage": repo})


print("=========== get revisions in the existing workspace (start) ===========")


# enable this script to be executed in a dev computer
if is_running_in_dev_computer:
    print("NOTE: testing in '{}' (presumably a dev host)".format(socket.gethostname()))
    # change to the directory where the running script file(.py) exists
    this_script_location = os.path.dirname(os.path.abspath(__file__))
    workspace = os.path.join('/tmp', 'execution')
    if not os.path.exists(workspace):
        os.makedirs(workspace)
    os.chdir(workspace)
else:
    workspace = os.getenv('WORKSPACE')

json_file = os.path.join(workspace, 'revisions.json')
json_file_inject = os.path.join(workspace, 'revisions.properties')

# Generate details in json format
mod_config = {}
mod_config["desc"] = "config for jobs in builds.openbravo.com"

# Get info for erp
(url, hashid) = get_url_hash(workspace)
mod_config["erp"] = {"method": "git", "params": {"url": url, "ver": hashid}}

# Get info for automation
get_repos_from_path('modules', 'mods')
get_repos_from_path('automation', 'automation')

json.dump(mod_config, open(json_file, 'w'), indent=4)  # save the file in the workspace
with open(json_file_inject, "w") as text_file:  # create a file that will be loaded by jenkins
    text_file.write("REPO_REVISIONS={}".format(json.dumps(mod_config)))


print("=========== get revisions in the existing workspace (end) ===========")
print("")
