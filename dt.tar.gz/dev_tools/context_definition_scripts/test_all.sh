#!/bin/bash

set -e

./test_clone_json_add_and_clone.sh

echo
echo
pytest test_gitlab_root_01.py

echo
echo
pytest test_gitlab_root_02.py

echo
echo
pytest test_gitlab_root_02_2025.py

echo
echo
pytest test_gitlab_root_03.py

echo
echo
pytest test_gitlab_root_03_2025.py

echo
echo
./v2/test_load_json_save_in_v2_format.py
