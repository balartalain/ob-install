#!/bin/bash

set -e

RED='\033[0;31m'
ORANGE="\033[33m"
GREEN='\033[0;32m'
NC='\033[0m' # No Color

WORKSPACE=${WORKSPACE:-/tmp/execution}

python3 config_json_add_revisions.py $(pwd)/test_subjects/context_definition_sample.json
echo ""
echo -e "Test that the generated revisions.json has the expected content${ORANGE}"
# if diff ${WORKSPACE}/revisions.json expected_revisions.json; then
if jq -S . ${WORKSPACE}/revisions.json | diff -u - <(jq -S . test_subjects/expected_revisions.json); then
    echo -e "${GREEN}revisions.json has the expected content${NC}"
else
    echo -e "${RED}The output of config_json_add_revisions.py does not equal to expected_revisions.json${NC}"
    exit 1
fi

echo ""
export CONTEXT_DEFINITION=$(jq -c . $(pwd)/test_subjects/expected_revisions.json)
python3 config_json_clone_repos.py

echo -e "${GREEN}Tests: OK${NC}"
