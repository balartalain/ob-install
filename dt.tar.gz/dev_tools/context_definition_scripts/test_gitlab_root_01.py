#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Test gitlab root modifications

import pytest
import os
import json
from unittest.mock import patch, MagicMock
from config_json_add_revisions import main

# Define constants
GITLAB_ROOT = 'git@gitlab.com:openbravo'
# GITLAB_ROOT = 'git@gitlab.com:orisha-group/bu-retail/openbravo'
EXPECTED_REPO_URL = f'{GITLAB_ROOT}/product/ci/context_definitions'
TEST_JSON_PATH = '/tmp/test_revisions.json'
EXECUTABLE_PATH = os.path.dirname(os.path.realpath(__file__))
CONTEXT_DEFINITIONS = os.path.abspath(os.path.join(EXECUTABLE_PATH, "../../context_definitions"))
assert os.path.exists(CONTEXT_DEFINITIONS), f"the context_definitions repository must exist at '{CONTEXT_DEFINITIONS}' for these tests to run"

# Mock data to simulate file and environment setup
TEST_JSON_DATA = {
    "desc": "Config for testing",
    "erp": {
        "method": "git",
        "params": {
            "url": f"{GITLAB_ROOT}/product/openbravo",
            "ver": "master"
        }
    }
}


@pytest.fixture
def setup_environment(monkeypatch):
    # Mock environment variables, paths, and files
    monkeypatch.setenv('IS_PRODUCTION_SERVER', 'false')
    monkeypatch.setenv('DRY_RUN', 'false')
    assert CONTEXT_DEFINITIONS != None
    monkeypatch.setattr('sys.argv', ['config_json_add_revisions.py', os.path.join(CONTEXT_DEFINITIONS, 'erp/erp.json')])
    with open(TEST_JSON_PATH, 'w') as f:
        json.dump(TEST_JSON_DATA, f)


def test_gitlab_root_update(setup_environment):
    # Patch GITLAB_ROOT to ensure consistency
    with patch('config_json_add_revisions.GITLAB_ROOT', GITLAB_ROOT):
        # Mock external processes (e.g., subprocess for git)
        with patch('config_json_add_revisions.run_process') as mock_run_process:
            mock_run_process.return_value = 'dummy_git_rev dummy_git_text'

            # Run main function and capture output
            main()

            # Verify the correct URL is used
            for call in mock_run_process.call_args_list:
                command = call[0][0]
                if 'clone' in command:
                    assert GITLAB_ROOT in call[0][0]

            # Validate output JSON structure and data
            with open('/tmp/execution/revisions.json') as result_file:
                output_data = json.load(result_file)
                assert output_data["erp"]["params"]["url"].startswith(GITLAB_ROOT)
                assert "revisions.json" in result_file.name
