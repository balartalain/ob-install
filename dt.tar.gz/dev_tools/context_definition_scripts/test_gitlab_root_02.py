#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Test to validate GITLAB_ROOT usage in config_json_add_revisions

import pytest
import os
import json
from unittest.mock import patch
from config_json_add_revisions import main

# Define constants
GITLAB_ROOT = 'git@gitlab.com:openbravo'
EXECUTABLE_PATH = os.path.dirname(os.path.realpath(__file__))
CONTEXT_DEFINITIONS = os.path.abspath(os.path.join(EXECUTABLE_PATH, "../../context_definitions"))
assert os.path.exists(CONTEXT_DEFINITIONS), f"the context_definitions repository must exist at '{CONTEXT_DEFINITIONS}' for these tests to run"
INPUT_JSON_PATH = os.path.join(EXECUTABLE_PATH, 'test_subjects/context_definition_sample.json')
EXPECTED_OUTPUT_PATH = os.path.join(EXECUTABLE_PATH, 'test_subjects/expected_revisions.json')


@pytest.fixture
def setup_environment(monkeypatch):
    # Setup to mock environment and ensure GITLAB_ROOT is used
    monkeypatch.setattr('sys.argv', ['config_json_add_revisions.py', INPUT_JSON_PATH])


def test_gitlab_root_consistency(setup_environment):
    # Patch GITLAB_ROOT to be the specific value for this test
    with patch('config_json_add_revisions.GITLAB_ROOT', GITLAB_ROOT):
        # Mock external processes to avoid actual network calls
        with patch('config_json_add_revisions.run_process') as mock_run_process:
            mock_run_process.return_value = 'dummy_git_rev dummy_git_text'

            # Run the main function to generate the output
            main()

            # Read the generated output file
            output_path = '/tmp/execution/revisions.json'
            with open(output_path) as result_file:
                output_data = json.load(result_file)

            # Read the expected output for comparison
            with open(EXPECTED_OUTPUT_PATH) as expected_file:
                expected_data = json.load(expected_file)

            # Assert the structure matches
            assert output_data == expected_data, "The generated JSON does not match the expected output."

            # Ensure all URLs start with the specified GITLAB_ROOT
            for key, value in output_data.items():
                if isinstance(value, dict) and "params" in value:
                    assert value["params"]["url"].startswith(GITLAB_ROOT), f"URL in {key} does not start with {GITLAB_ROOT}"
