import pytest
import subprocess
import os
import json
import re

# Constants for expected values
GITLAB_ROOT = 'git@gitlab.com:orisha-group/bu-retail/openbravo'
EXECUTABLE_PATH = os.path.dirname(os.path.realpath(__file__))
CONTEXT_DEFINITIONS = os.path.abspath(os.path.join(EXECUTABLE_PATH, "../../context_definitions"))
assert os.path.exists(CONTEXT_DEFINITIONS), f"the context_definitions repository must exist at '{CONTEXT_DEFINITIONS}' for these tests to run"
INPUT_JSON_PATH = os.path.join(EXECUTABLE_PATH, 'test_subjects/context_definition_sample.json')
EXPECTED_OUTPUT_PATH = os.path.join(EXECUTABLE_PATH, 'test_subjects/expected_revisions_2025.json')


@pytest.fixture
def setup_environment(monkeypatch):
    monkeypatch.setenv('IS_NEW_ROOT_IN_USE', 'true')  # Ensures new GITLAB_ROOT is used for the test


def test_gitlab_root_consistency(setup_environment):
    # Read the input JSON
    with open(INPUT_JSON_PATH, 'r') as file:
        input_json = json.load(file)
    input_json_str = json.dumps(input_json, separators=(',', ':'))

    # Run the script in a subprocess with environment variables set by monkeypatch
    result = subprocess.run(
        ['python3', 'config_json_add_revisions.py', input_json_str],
        capture_output=True,
        text=True,
        env=os.environ  # ensures monkeypatched env vars are used
    )

    # Concatenate stdout and stderr
    all_output = result.stdout + result.stderr

    # Read the expected output
    with open(EXPECTED_OUTPUT_PATH, 'r') as file:
        expected_output = json.load(file)

    # Read the generated output
    with open('/tmp/execution/revisions.json', 'r') as file:
        generated_output = json.load(file)

    # Assertions
    assert re.search(r"IS_NEW_ROOT_IN_USE\s+True", all_output), "Expected 'IS_NEW_ROOT_IN_USE: True' in the console log output"
    assert GITLAB_ROOT in all_output, f"Expected GITLAB_ROOT '{GITLAB_ROOT}' to be in the output"
    assert generated_output == expected_output, "The generated JSON does not match the expected output."

    # Check if all URLs start with GITLAB_ROOT
    for key, value in generated_output.items():
        if isinstance(value, dict) and "params" in value:
            assert value["params"]["url"].startswith(GITLAB_ROOT), f"URL in {key} does not start with {GITLAB_ROOT}"


if __name__ == "__main__":
    pytest.main([__file__])
