import pytest
import subprocess
import os
import json
import re

# Constants for expected values
GITLAB_ROOT = 'git@gitlab.com:openbravo'
EXECUTABLE_PATH = os.path.dirname(os.path.realpath(__file__))
REVISIONS_SOURCE = os.path.join(EXECUTABLE_PATH, 'test_subjects/expected_revisions.json')


@pytest.fixture
def setup_environment(monkeypatch):
    # Set environment variables using monkeypatch
    # monkeypatch.setenv('IS_PRODUCTION_SERVER', 'false')
    # monkeypatch.setenv('DRY_RUN', 'false')
    monkeypatch.setenv('IS_NEW_ROOT_IN_USE', 'false')  # Ensures new GITLAB_ROOT is used for the test


def test_gitlab_root_consistency(setup_environment, capsys):
    # Prepare context definition as an argument
    with open(REVISIONS_SOURCE, 'r') as file:
        context_definition = json.load(file)
    context_definition_str = json.dumps(context_definition, separators=(',', ':'))

    # Run the script in a subprocess with environment variables set by monkeypatch
    result = subprocess.run(
        ['python3', 'config_json_clone_repos.py', context_definition_str],
        capture_output=True,
        text=True,
        env=os.environ  # ensures monkeypatched env vars are used
    )

    # Concatenate stdout and stderr
    all_output = result.stdout + result.stderr

    # Assertions
    assert re.search(r"IS_NEW_ROOT_IN_USE\s+False", all_output), "Expected 'IS_NEW_ROOT_IN_USE: False' in the console log output"
    assert GITLAB_ROOT in all_output, f"Expected GITLAB_ROOT '{GITLAB_ROOT}' to be in the output"
    assert "=========== clone repos based on json (start) ===========" in all_output
    assert "=========== clone repos based on json ( end ) ===========" in all_output
    assert f"{GITLAB_ROOT}/ci/context_definitions.git" in all_output


if __name__ == "__main__":
    pytest.main([__file__])
