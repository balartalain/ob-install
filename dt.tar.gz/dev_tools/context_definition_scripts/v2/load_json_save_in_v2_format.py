import traceback
import os
import sys
import json
import pickle
import yaml
import pathlib

EXECUTABLE_NAME = pathlib.Path(os.path.basename(__file__)).stem
EXECUTABLE_PATH = os.path.dirname(os.path.realpath(__file__))

print(EXECUTABLE_NAME)

RED = '\033[0;31m'
GREEN = '\033[0;32m'
ORANGE = '\033[0;33m'
NC = '\033[0m'  # No Color


def handle_exception(exc_type, value, exc_tb) -> None:
    # catch uncaught exceptions
    FILTER_ERROR_TRACE = True
    ERROR_TRACEBACK_MAX_LINES = 2
    traceback_lines = []
    idx = 0
    for file_name, line_number, func_name, text in traceback.extract_tb(exc_tb):
        idx += 1
        if FILTER_ERROR_TRACE == False or EXECUTABLE_PATH in str(file_name):
            traceback_lines.append('\n  [%d] File "%s", line %d, in function "%s"\n\t%s' % (idx, file_name, line_number, func_name, text))
    traceback_to_output = ''
    for line in traceback_lines[-ERROR_TRACEBACK_MAX_LINES:][::-1]:
        traceback_to_output += line
    traceback_to_output = f"Traceback: {RED}{traceback_to_output}{NC}" if traceback_to_output else ''
    print(f'\n{ORANGE}Exception ocurred:\n{ORANGE}Type: {RED}{exc_type.__name__}\n{ORANGE}Message:\n{RED}{value}{ORANGE}\n{traceback_to_output}')


sys.excepthook = handle_exception


class Module:
    def __init__(self, **kwargs):
        self.url = kwargs.get('params').get('url', None)
        self.ver = kwargs.get('params').get('ver', 'master')
        self.method = kwargs.get('method', 'git')
        self.pkg = kwargs.get('javapackage', None)
        self.group = None

        # remove reduntant info
        git_root_default = "git@gitlab.com:openbravo"
        if (self.url == f"{git_root_default}/product/pmods/{self.pkg}"):
            self.group = 'pmods'
            self.url = None
        if (self.url == f"{git_root_default}/product/mods/{self.pkg}"):
            self.group = 'mods'
            self.url = None

        # Remove known keys and check if any unexpected keys are left
        for key in ['params', 'method', 'javapackage']:
            kwargs.pop(key, None)
        if kwargs:
            raise ValueError(f"Unexpected keys in Module: {', '.join(kwargs.keys())}")


class Script:
    def __init__(self, file, params=None):
        self.file = file
        self.params = params if params is not None else []


class Config:
    def __init__(self, desc, mods, deps, scripts, erp):
        self.desc = desc
        self.version = 2
        self.mods = [Module(**mod) for mod in mods]
        self.deps = [Module(**dep) for dep in deps]
        self.erp = [Module(**erp)]  # Even if it's a single module, treat it as a list for consistency
        assert len(self.erp) == 1
        self.erp[0].pkg = self.erp[0].url.split('/')[-1]
        # Handle scripts properly by iterating over each script in each section
        self.scripts = {}
        for section_name, script_list in scripts.items():
            script_scope = []
            for script in script_list:
                script_instance = Script(script['file'], script.get('params'))
                script_scope.append(script_instance)
            if script_scope:
                self.scripts[section_name] = script_scope


    def save_to_file_raw(self, filename):
        with open(filename, 'wb') as file:
            pickle.dump(self, file)

    def get_config_dict(self):
        def sort_section(section):
            sorted_elements = [
                {
                    'pkg': m.pkg,
                    **({'method': m.method} if m.method != 'git' else {}),
                    **({'url': m.url} if m.url != None else {}),
                    **({'group': m.group} if m.group != None else {}),
                    'ver': m.ver
                }
                for m in sorted(section, key=lambda m: m.pkg or "")
            ]
            return sorted_elements

        def script_section_to_dict(section):
            return [
                {'file': script.file, 'params': script.params}
                for script in section
            ]

        config_dict = {
            "version": self.version,
            "desc": self.desc,
            "mods": sort_section(self.mods),
            "deps": sort_section(self.deps),
            "scripts": {k: script_section_to_dict(v) for k, v in self.scripts.items()},
            "erp": sort_section(self.erp)
        }
        return config_dict


    def save_to_file_yml(self, filename):
        with open(filename, 'w') as file:
            yaml.dump(self.get_config_dict(), file, default_flow_style=False, sort_keys=False)

    def save_to_file_json(self, filename):
        # print(self.get_config_dict())
        with open(filename, 'w') as file:
            json.dump(self.get_config_dict(), file, indent=4)


def load_config(filename):
    with open(filename, 'r') as file:
        data = json.load(file)
        try:
            return Config(**data)
        except ValueError as e:
            print(f"Error processing configuration: {e}")
            return None


if __name__ == '__main__':
    # Example usage:
    config = load_config('context_definition_sample.json')

    print(config)
    print(config.version)
    print(config.desc)
    for module in config.erp:
        print(f"{module.pkg} - {module.url}")
    for module in config.mods:
        print(f"{module.pkg} - {module.url}")
    for module in config.deps:
        print(f"{module.pkg} - {module.url}")
    for script in config.scripts:
        print(f"{script} - {script}")

    config.save_to_file_raw('revisions_raw.tmp')
    config.save_to_file_yml('revisions_yml.tmp')
    config.save_to_file_json('revisions_json.tmp')
