#!/usr/bin/python3

import unittest
from unittest.mock import mock_open, patch, ANY
import yaml
import json
import os
from load_json_save_in_v2_format import Config  # Replace with actual import if necessary

EXECUTABLE_PATH = os.path.dirname(os.path.realpath(__file__))
test_samples = os.path.abspath(f"{EXECUTABLE_PATH}/../test_subjects")


class TestConfigInitialization(unittest.TestCase):
    def test_initialization(self):
        with open(f'{test_samples}/context_definition_sample.json', 'r') as file:
            config_data = json.load(file)
        config = Config(**config_data)

        self.assertEqual(config.desc, "Config for translations")
        self.assertEqual(config.version, 2)

        self.assertIsInstance(config.erp, list)
        self.assertEqual(len(config.erp), 1)
        self.assertEqual(config.erp[0].pkg, "openbravo")
        self.assertEqual(config.erp[0].url, "git@gitlab.com:openbravo/product/openbravo")

        self.assertIsInstance(config.mods, list)
        self.assertEqual(len(config.mods), 4)
        self.assertEqual(config.mods[0].pkg, "org.openbravo.v3.translation.pack.es_ES")
        self.assertEqual(config.mods[0].group, "pmods")
        self.assertEqual(config.mods[0].url, None)
        self.assertEqual(config.mods[1].pkg, "org.openbravo.client.htmlwidget.es_ES")
        self.assertEqual(config.mods[1].group, "mods")
        self.assertEqual(config.mods[1].url, None)

        self.assertIsInstance(config.deps, list)
        self.assertEqual(len(config.deps), 3)
        self.assertEqual(config.deps[0].pkg, "org.openbravo.accrualsanddeferrals")
        self.assertEqual(config.deps[0].group, "pmods")
        self.assertEqual(config.deps[0].url, None)
        self.assertEqual(config.deps[0].ver, "e255a8eff79ca4297eb37c246d1683bb20692897")
        self.assertEqual(config.deps[0].method, "git")
        self.assertEqual(config.deps[2].pkg, "org.openbravo.api")
        self.assertEqual(config.deps[2].group, None)
        self.assertEqual(config.deps[2].url, "git@gitlab.com:openbravo/product/pmods/customPkg")
        self.assertEqual(config.deps[2].ver, "master")

        self.assertIsInstance(config.scripts, dict)
        self.assertEqual(len(config.scripts), 1)
        self.assertIsInstance(config.scripts["checks-without-tomcat"], list)
        self.assertEqual(len(config.scripts["checks-without-tomcat"]), 2)
        script1 = config.scripts["checks-without-tomcat"][0]
        self.assertEqual(script1.file, "localization/translations_junit.sh")
        self.assertEqual(script1.params, ['$WORKSPACE'])
        script2 = config.scripts["checks-without-tomcat"][1]
        self.assertEqual(script2.file, "script2.py")
        self.assertEqual(script2.params, [])


class TestConfigSerialization(unittest.TestCase):
    def test_serialize_mods(self):
        erp = {
            'method': 'git',
            'params': {
                'url': 'git@gitlab.com:openbravo/product/openbravo',
                'ver': 'f0d9f3891917a70f2199a8b54ad4fea5184f2823'
            }
        }
        mod_data = {
            'method': 'get',
            'params': {
                'url': 'example.com',
                'ver': '1.0'
            },
            'javapackage': 'example'
        }
        config = Config(desc='test', mods=[mod_data], deps=[], scripts={}, erp=erp)
        expected_output = [{
            'method': 'get',
            'url': 'example.com',
            'ver': '1.0',
            'javapackage': 'example'
        }]
        actual_output = [{
            'method': m.method,
            'url': m.url,
            'ver': m.ver,
            'javapackage': m.pkg
        } for m in config.mods]
        self.assertEqual(actual_output, expected_output)


class TestConfigFileWriting(unittest.TestCase):
    def test_save_to_file_yml(self):
        erp = {
            'method': 'git',
            'params': {
                'url': 'git@gitlab.com:openbravo/product/openbravo',
                'ver': 'f0d9f3891917a70f2199a8b54ad4fea5184f2823'
            }
        }
        config = Config(desc="Example", mods=[], deps=[], scripts={}, erp=erp)
        expected_yaml = "desc: Example\n..."
        with patch("builtins.open", mock_open()) as mocked_file:
            with patch("yaml.dump", return_value=expected_yaml) as mock_yaml_dump:
                config.save_to_file_yml("dummy.yml")
                mocked_file.assert_called_once_with("dummy.yml", 'w')
                mock_yaml_dump.assert_called_once()


class TestConfigSaveToFile(unittest.TestCase):
    def test_save_to_file(self):
        # Load the sample of a context definition
        with open(f'{test_samples}/context_definition_sample.json', 'r') as file:
            config_data = json.load(file)
        config = Config(**config_data)

        # Load expected YAML content from a file
        with open(f'{EXECUTABLE_PATH}/expected_revisions.yml', 'r') as file:
            expected_yaml = file.read()

        # Use mock_open to simulate file operations
        with patch("builtins.open", mock_open()) as mocked_file:
            with patch("yaml.dump") as mock_yaml_dump:
                config.save_to_file_yml("revisions.yml.tmp")
                # Ensure the file was opened in write mode
                mocked_file.assert_called_once_with("revisions.yml.tmp", 'w')
                # Convert expected_yaml to a dictionary and compare with what yaml.dump received
                expected_data = yaml.safe_load(expected_yaml)
                mock_yaml_dump.assert_called_once_with(expected_data, mocked_file(), default_flow_style=False, sort_keys=ANY)


if __name__ == '__main__':
    unittest.main()
