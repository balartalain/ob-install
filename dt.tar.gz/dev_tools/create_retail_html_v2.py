#!/usr/bin/env python3

import re
import sys
import datetime
import os
import html
import jenkins
import traceback
import logging
import pickle
import socket
from abc import ABC, abstractmethod
from pathlib import Path
from urllib.parse import urlparse

# configuration
OUTPUT_FILENAME = "retail.html"
PI_MOBILE_NUM_SUITES = 8
PI_MOBILE_MODULES_NUM_SUITES = 6
IS_CACHE_ACTIVE = False

# discover environment
EXECUTABLE_PATH = Path(os.path.dirname(__file__))
EXECUTABLE_FILENAME = os.path.basename(__file__)
EXECUTABLE_NAME = Path(os.path.basename(__file__)).stem
HOSTNAME = socket.gethostname()
IS_PRODUCTION_SERVER = os.getenv('IS_PRODUCTION_SERVER')  # True = builds.openbravo.com, False = cicd, None = dev computer
is_running_in_dev_computer = IS_PRODUCTION_SERVER is None
if IS_PRODUCTION_SERVER == None:
    IS_PRODUCTION_SERVER = HOSTNAME == 'builds.openbravo.com'

# setup environment
dry_run = is_running_in_dev_computer  # True/False. False: run the script but do not make requests to the sourcecode server to ask for revisions. Fill with dummy data

CYAN = "\033[0;36m"
GREEN = '\033[0;32m'
IRED = "\033[1;91m"
ORANGE = '\033[0;33m'
RED = "\033[0;31m"
WHITE = "\033[0;37m"
YELLOW = "\033[0;33m"
NC = '\033[0m'  # No Color

# logger

log_levels = {
    50: 'CRITICAL',
    40: 'ERROR',
    30: 'WARNING',
    20: 'INFO',
    10: 'DEBUG',
    0: 'NOTSET'
}


def log_success(self, message, *args, **kws):
    if self.isEnabledFor(LOG_SUCCESS_LEVEL):
        self._log(LOG_SUCCESS_LEVEL, "{}{}{}".format(GREEN, message, NC), args, **kws)


def log_attention(self, message, *args, **kws):
    if self.isEnabledFor(LOG_ATTENTION_LEVEL):
        self._log(LOG_ATTENTION_LEVEL, "{}{}{}".format(ORANGE, message, NC), args, **kws)


def log_failed(self, message, *args, **kws):
    if self.isEnabledFor(LOG_FAILED_LEVEL):
        self._log(LOG_FAILED_LEVEL, "{}{}{}".format(RED, message, NC), args, **kws)


if IS_PRODUCTION_SERVER == True:
    log_initial_level = logging.INFO
else:
    log_initial_level = logging.DEBUG
LOG_FORMAT = '%(message)s'
# LOG_FORMAT = '%(asctime)-15s %(levelname)-10s %(message)s'
LOG_SUCCESS_LEVEL = 25  # info is 20
LOG_ATTENTION_LEVEL = 30  # warning is 30
LOG_FAILED_LEVEL = 40  # error is 40
logging.addLevelName(LOG_SUCCESS_LEVEL, "SUCCESS")
logging.addLevelName(LOG_ATTENTION_LEVEL, "ATTENTION")
logging.addLevelName(LOG_FAILED_LEVEL, "FAILED")
logging.Logger.success = log_success  # type: ignore
logging.Logger.attention = log_attention  # type: ignore
logging.Logger.failed = log_failed  # type: ignore
logger = logging.getLogger(__name__)
handler = logging.StreamHandler(sys.stdout)
formatter = logging.Formatter(LOG_FORMAT)
handler.setFormatter(formatter)
logger.addHandler(handler)
logger.setLevel(log_initial_level)

logger.debug("EXECUTABLE_FILENAME\t{}".format(EXECUTABLE_FILENAME))
logger.debug("EXECUTABLE_PATH\t\t{}".format(EXECUTABLE_PATH))
logger.info("IS_PRODUCTION_SERVER\t{}".format(IS_PRODUCTION_SERVER))
logger.info("LOG_LEVEL\t\t{}".format(log_levels.get(log_initial_level, "UNKNOWN")))


def handle_exception(exc_type, value, exc_tb) -> None:
    """
    Catch uncaught exceptions and filter and beautify the output
    """
    if issubclass(exc_type, KeyboardInterrupt):
        # sys.__excepthook__(exc_type, value, exc_tb)
        return
    traceback_line = ""
    traceback_str = ""
    idx = 0
    for file_path, line_number, func_name, text in traceback.extract_tb(exc_tb)[:]:
        idx += 1
        file_name = Path(file_path).stem
        # build the output
        if file_name != EXECUTABLE_NAME:
            # traceback_line += '%s:' % (file_name)
            # print(file_path,func_name)
            continue
        traceback_line = '\n%s[%d] ' % (ORANGE, idx)
        traceback_line += '%d' % (line_number)
        if func_name != "<module>":
            traceback_line += ':%s' % (func_name)
        traceback_line += '%s %s' % (CYAN, text)
        file_name = Path(file_path).stem
        traceback_str += traceback_line
    if traceback_str != "":
        traceback_str = "Traceback: {}{}{}".format(ORANGE, traceback_str, NC)
    error_message_formatted = ""
    for s in str(value).split("\n"):
        error_message_formatted += "  {}\n".format(s.strip())
    logger.failed("\n%s:\n%s\n%s" % ("{}{}".format(NC, exc_type.__name__), "{}{}{}".format(RED, error_message_formatted, NC), traceback_str))


sys.excepthook = handle_exception


class APIInterface(ABC):
    """
    Methods that should be implemented by a class that fetches data from a Jenkins server
    """
    @abstractmethod
    def get_build_console_output(self):
        """
        Fetches the console output of a specified job build.

        This method constructs a file path from a given job name and build number,
        verifies the existence of the file, and then reads the file content (console output).
        If the specified file doesn't exist, it raises an exception.

        Args:
            job_name (str): The name of the job.
            build_number (int): The build number associated with the job.

        Returns:
            str: The console output of the job build.

        Raises:
            Exception: If the console output does not exist.
        """
        pass

    @abstractmethod
    def get_job_info(self):
        """
        Retrieves information about a specific job build.

        This method fetches and formats build information including the status of the build,
        the build number, URL, result, duration, display name and the relative path of artifacts.
        If the requested build does not exist, the Jenkins API may raise an exception.

        Args:
            job_name (str): The name of the job.
            build_number (int): The build number associated with the job.

        Returns:
            dict: A dictionary containing key information about the job build.

        Raises:
            Exception: If the job or build does not exist.
        """
        pass

    @abstractmethod
    def get_test_report(self):
        """
        Retrieves a test report for a specific job build.

        This method queries and organizes a test report related to a specific job build,
        including pass/fail status, error messages, and test statistics. If the requested
        build does not exist or if there is no test report associated with it, an exception
        may be thrown.

        Args:
            job_name (str): The name of the job.
            build_number (int): The build number associated with the job.

        Returns:
            dict: A dictionary containing key information about the test report.

        Raises:
            Exception: If the job, build, or test report does not exist.
        """
        pass


class JenkinsHttpRequestApi(APIInterface):
    """
    A class that implements the APIInterface.

    This class is responsible for fetching data from a Jenkins server using HTTP requests.
    """

    def __init__(self):
        raise Exception("JenkinsHttpRequestApi requires implementation")

    def get_build_console_output(self):
        pass

    def get_job_info(self):
        pass

    def get_test_report(self):
        pass


class JenkinsPythonApi(APIInterface):
    """
    A class that implements the methods defined in the APIInterface.

    This class is responsible for fetching data from a Jenkins server using the python3-jenkins module.
    """

    def __init__(self, ci_base_url, API_USER, API_TOKEN):
        self.server = jenkins.Jenkins("{}:443".format(ci_base_url), username=API_USER, password=API_TOKEN)

    def get_build_console_output(self, job_name, build_number):
        file_path = f"/srv/ci/jobs/{job_name}/builds/{build_number}/log"
        if not os.path.isfile(file_path):
            raise Exception(f"No such file: {file_path}")
        with open(file_path, 'r') as file:
            console_output = file.read()
        # logger.debug('fetched console output')
        return console_output

    def get_job_info(self, job_name, build_number):
        build_info = self.server.get_build_info(job_name, int(build_number))
        data = {
            'building': build_info['building'],
            'number': build_info['number'],
            'url': build_info['url'],
            'result': build_info['result'],
            'duration': build_info['duration'],
            'displayName': build_info['displayName'],
            'artifacts': [artifact['relativePath'] for artifact in build_info['artifacts']]
        }
        # logger.debug('fetched job info')
        return data

    def get_test_report(self, job_name, build_number):
        test_report = self.server.get_build_test_report(job_name, int(build_number))
        # logger.debug('fetched test report')
        return test_report


class JenkinsPythonApiWithCache(APIInterface):
    """
    A class that implements the methods defined in the APIInterface.

    This class is responsible for fetching data from a Jenkins server using the python3-jenkins module.
    Activates caching when IS_CACHE_ACTIVE is True. Useful for cache optimization and identifying potential groupings or reductions of calls.
    """

    def __init__(self, ci_base_url, API_USER, API_TOKEN):
        logger.info("IS_CACHE_ACTIVE\t\t{}".format(IS_CACHE_ACTIVE))
        self.server = jenkins.Jenkins("{}:443".format(ci_base_url), username=API_USER, password=API_TOKEN)
        self.jenkinsPythonApi = JenkinsPythonApi(ci_base_url, API_USER, API_TOKEN)
        self.job_info_cache = self.__Cache('get_job_info_cache.pkl')
        self.test_report_cache = self.__Cache('get_test_report_cache.pkl')

    class __Cache:
        def __init__(self, cache_file):
            self.cache_file = cache_file
            self.cache_folder = os.path.join(EXECUTABLE_PATH, 'cache')
            if not os.path.exists(self.cache_folder):
                os.makedirs(self.cache_folder)
            self.cache_file_path = os.path.join(self.cache_folder, cache_file)
            if os.path.exists(self.cache_file_path):
                with open(self.cache_file_path, 'rb') as f:
                    self.cache = pickle.load(f)
            else:
                self.cache = {}

        def get(self, key, fetch_func, *args):
            if key in self.cache and IS_CACHE_ACTIVE == True:
                logger.debug(f'\tgot {key} from {self.cache_file} cache')
                return self.cache[key]
            else:
                result = fetch_func(*args)
                if IS_CACHE_ACTIVE == True:
                    self.cache[key] = result
                    logger.debug(f'\tcaching {key} to {self.cache_file}')
                    with open(self.cache_file_path, 'wb') as f:
                        pickle.dump(self.cache, f)
                return result

    def get_build_console_output(self, job_name, build_number):
        return self.jenkinsPythonApi.get_build_console_output(job_name, build_number)

    def get_job_info(self, job_name, build_number):
        fetch_func = self.__fetch_job_info
        return self .job_info_cache.get((job_name, build_number), fetch_func, job_name, int(build_number))

    def __fetch_job_info(self, job_name, build_number):
        return self.jenkinsPythonApi.get_job_info(job_name, build_number)

    def get_test_report(self, job_name, build_number):
        fetch_func = self.__fetch_test_report
        return self.test_report_cache.get((job_name, build_number), fetch_func, job_name, int(build_number))

    def __fetch_test_report(self, job_name, build_number):
        return self.jenkinsPythonApi.get_test_report(job_name, build_number)


class HTMLTextGenerator:
    def __init__(self, jenkins_api, ci_base_url, BUILD_URL, LIST_OF_BUILDS):
        self.jenkins_api = jenkins_api
        self.ci_base_url = ci_base_url
        self.BUILD_URL = BUILD_URL
        self.list_of_builds = LIST_OF_BUILDS
        match = re.search(r'https?://[a-z]+.openbravo.com/job/(([a-z-]+-)init(-selenium)?)/([0-9]+)/?', BUILD_URL)
        if not match:
            raise Exception("ERROR: 'BUILD_URL' must be something like: https://cicd.openbravo.com/job/try-ret-init/2481 but is: {}".format(BUILD_URL))
        self.init_job_name = match.group(1)
        self.job_prefix = match.group(2)
        init_build_number = match.group(4)
        # logger.info("init_job_name\t\t{}".format(init_job_name))
        # logger.debug("job_prefix\t\t{}".format(job_prefix))
        # logger.info("init_build_number\t{}".format(init_build_number))
        self.builds_map = self.get_info_of_a_try_retail_run(self.init_job_name, init_build_number)
        self.job_modules_prefix = self.job_prefix + "test-" if self.job_prefix == "ret-" else self.job_prefix

    def does_build_exist(self, job_name, build_number):
        # logger.debug(f"check if the build exist {job_name} {build_number}")
        expected_path = f"/srv/ci/jobs/{job_name}/builds/{build_number}"
        # Check if it exists and return
        return os.path.exists(expected_path)

    def get_param(self, job_json, param_name):
        for param in job_json["api"]["actions"][0]["parameters"]:
            if param["name"] == param_name:
                return param["value"]
        return None

    def get_info_of_a_try_retail_run(self, init_job_name, init_build_number):
        # logger.info(f"Processing {self.ci_base_url}/job/{init_job_name}/{init_build_number}")

        logger.info(f"retrieving console output from {self.ci_base_url}/job/{init_job_name}/{init_build_number}/consoleText")  # e.g.: https://cicd.openbravo.com/job/ret-qa-init/1137/consoleText/
        console_output = self.jenkins_api.get_build_console_output(init_job_name, init_build_number)
        build_map = {init_build_number: {"jobs": {init_job_name: {"build_num": init_build_number, "console": console_output}}}}
        # logger.debug(build_build_url_num(init_job_name, init_build_number))
        build_map[init_build_number]["jobs"][init_job_name]["api"] = self.jenkins_api.get_job_info(init_job_name, init_build_number)
        builds_url = []
        # e.g. self.list_of_builds = try-ret-modules-oracle-suite5,94;try-ret-test-pgsql-suite1,187;try-ret-full-pgsql,133
        jobnames_and_buildnumbers = self.list_of_builds.split(',')
        count = len(jobnames_and_buildnumbers)
        if count % 2 != 0:
            raise Exception("ERROR: 'LIST_OF_BUILDS' must be a comma separated string of pairs. e.g. 'try-ret-modules-pgsql-suite1,94,try-ret-test-pgsql-suite1,187,try-ret-full-pgsql,133...'")
        index = 0
        logger.debug(f"list of builds found:")
        while index < count:
            job_name = jobnames_and_buildnumbers[index]
            build_number = jobnames_and_buildnumbers[index + 1]
            if self.does_build_exist(job_name, build_number):
                logger.debug(f"- {self.ci_base_url}/job/{job_name}/{build_number}")
                builds_url.append([job_name, build_number])
            index += 2
        if builds_url:
            logger.info(f"retrieving build information from:")
            for url in builds_url:
                build_name = url[0]
                build_number = url[1]
                build_map[init_build_number]["jobs"][build_name] = {"build_number": build_number}
                logger.info(f"- {self.ci_base_url}/job/{job_name}/{build_number}")
                build_map[init_build_number]["jobs"][build_name]["api"] = self.jenkins_api.get_job_info(build_name, build_number)
                if 'suite' in build_name:
                    build_map[init_build_number]["jobs"][build_name]["testResult"] = self.jenkins_api.get_test_report(build_name, build_number)

        return build_map

    def get_list_ordered_of_jobs(self):
        LIST_NORMAL_JOBS = ["full", "checks", "checks-modules", "dbcons", "api"]
        LIST_DB = ["pgsql", "pgsql_2"]
        job_list = []
        for job in LIST_NORMAL_JOBS:
            if job == "api":
                job_list.append("%s%s" % (self.job_prefix, job))
            else:
                for db in LIST_DB:
                    job_list.append("%s%s-%s" % (self.job_prefix, job, db))
        for suite in range(1, PI_MOBILE_NUM_SUITES+1):
            for db in LIST_DB:
                job_list.append("%stest-%s-suite%s" % (self.job_prefix, db, suite))
        for suite in range(1, PI_MOBILE_MODULES_NUM_SUITES+1):
            for db in LIST_DB:
                job_list.append("%smodules-%s-suite%s" % (self.job_modules_prefix, db, suite))
        return job_list

    def get_job_desc(self, job_json):
        return "%s" % job_json["displayName"]

    def get_img_url(self, job_api_json, test_class):
        job_url = job_api_json["url"]
        test_name = test_class.split('.')[-1:][0]
        img_name = test_name + "."
        for artifact in job_api_json["artifacts"]:
            if img_name in artifact:
                return job_url + "artifact/" + artifact
        return ""

    def generate_html_text(self):
        # img size 495px - 900px
        img_reduction = 2
        img_height = 495 / img_reduction
        img_width = 900 / img_reduction
        with open(os.path.join(EXECUTABLE_PATH, f"{EXECUTABLE_NAME}.html"), 'r') as file:
            style = file.read()
        html_text = f"<html><head>\n{style}</head><body>"
        html_text += "<div class='menu-bar'>"
        html_text += "<button id='showHideTimes' class='button-item' onclick='showHideTimes()'>Show suites times</button>"
        html_text += "<button id='showHideOnlyErrors' class='button-item' onclick='showHideOnlyErrors()'>Show only failed</button>"
        html_text += "<button id='showHideStackTraceRepetitiveError' class='button-item' onclick='showHideStackTraceRepetitiveError()'>Hide StrackTrace of repeated errors</button>"
        html_text += '<a id="showHideRepoVersions" class="button-item" href="' + self.BUILD_URL + '/artifact/jsonToBuild.json">Show repo versions</a>'
        html_text += "</div>"
        builds_keys = list(self.builds_map.keys())
        if len(builds_keys) == 1:
            init_key = builds_keys[0]
            try_retail_map = self.builds_map[init_key]
            try_retail_url = try_retail_map["jobs"][self.init_job_name]["api"]["url"]
            try_retail_desc = self.get_job_desc(try_retail_map["jobs"][self.init_job_name]["api"])
            try_retail_duration = str(datetime.timedelta(seconds=int(try_retail_map["jobs"][self.init_job_name]["api"]["duration"] / 1000)))
            html_text += "<div class='try-init-menu'><div class='try-init-item'><div class='try-init-link'><a href='%s'>%s</a></div><div class='try-init-time time'> [%s]</div></div></div>" % (try_retail_url, try_retail_desc, try_retail_duration)
            # print ("job api keys: ", try_retail_map["jobs"][self.init_job_name]["api"].keys())
            html_text += "<br/><br/><div class='wrapper'>"
            for job in self.get_list_ordered_of_jobs():
                if job not in try_retail_map["jobs"].keys():
                    continue
                job_map = try_retail_map["jobs"][job]
                div_class = "job"
                if "pgsql_2" in job:
                    div_class += " pg2"
                elif "api" in job:
                    div_class += " api"
                else:
                    div_class += " pg"
                html_text += "<div class='%s'>" % div_class

                job_status = job_map["api"]["result"]
                class_success = ""
                status_color = "blue"
                if job_status == "SUCCESS":
                    status_color = "green"
                    class_success = "success"
                elif job_status == "UNSTABLE":
                    status_color = "orange"
                elif job_status == "FAILURE":
                    status_color = "red"
                job_url = job_map["api"]["url"]
                # print("job api keys: ", job_map["api"].keys())
                job_duration = str(datetime.timedelta(seconds=int(job_map["api"]["duration"] / 1000)))
                html_text += "<div class='jobtitle %s'><div class='jobname'><a href='%s'>%s</a></div> <div class='status'><span style='color:%s'>%s</span></div> <div class='totaltime time'>Job time: %s</div> " % (class_success, job_url, job[len(self.job_prefix):].replace('-', ' '), status_color, job_status, job_duration)
                if "suite" in job:
                    if "testResult" in job_map and job_map["testResult"] != None:
                        job_results = job_map["testResult"]
                        html_text += " <div class='teststime time'>All tests time: %s</div>" % str(datetime.timedelta(seconds=int(job_results["duration"])))
                        html_text += "</div>"
                        for suite in job_results["suites"]:
                            html_text += "<div class='timesuite time'>[%s - Time of suite %s]</div>" % (str(datetime.timedelta(seconds=int(suite["duration"]))), suite["name"].split('.')[-1:][0])
                        if job_status == "UNSTABLE":
                            html_text += "<br/>Failed tests: %s" % job_results["failCount"]
                            automation_repo = "mobile-test"
                            suites_like_this_url = job_url+"/artifact/SANDBOX/automation/"+automation_repo+"/last-results/"+job+"/logs/suiteLikeTestList.log"
                            html_text += "<div class='suites_like_this'><a href='%s'>suitesLikeThis</a></div>" % suites_like_this_url
                            failing_cases = {}
                            for suite in job_results["suites"]:
                                # print("suite keys: "), suite.keys()
                                for case in suite["cases"]:
                                    # print("case keys: "), case.keys()
                                    if (case["status"] == "REGRESSION") or (case["status"] == "FAILED"):
                                        if case["errorDetails"]:
                                            error_key = re.sub(r'\[\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\+\d{4}\]', '', case["errorDetails"])
                                            if error_key not in failing_cases:
                                                failing_cases[error_key] = []
                                            failing_cases[error_key].append(case)
                            for error_key in failing_cases:
                                if len(failing_cases[error_key]) > 1:
                                    case_group = failing_cases[error_key][0]
                                    test_failing_from = job_map["api"]["number"] - case_group["failedSince"]
                                    failing_from_html_text = ""
                                    if test_failing_from > 0:
                                        failing_from_html_text = "<span style='color:red'><br/>(Failing for %s consecutive builds)</span>" % test_failing_from
                                    html_text += "<br/><br/><span style='font-weight:bold'>This error has happened %s times in this job</span>%s<div class='errorText'><pre>%s</pre></div>" % (len(failing_cases[error_key]), failing_from_html_text, case_group["errorDetails"])
                                    test_name = ".".join(case_group["className"].split('.')[4:])
                                    img_link = self.get_img_url(job_map['api'], test_name)
                                    html_text += "<br/><div class='img'><a href='%s'><img class='error_img' src='%s' alt='image' height='%spx' width='%spx'/></a></div>" % (img_link, img_link, img_height, img_width)
                                    html_text += "<div class='failing_group'>"
                                    for case in failing_cases[error_key]:
                                        test_name = ".".join(case["className"].split('.')[4:])
                                        stack_trace = ""
                                        for line in case["errorStackTrace"].split('\n'):
                                            if test_name in line and "(" in line:
                                                # stack_trace += ".".join(line.split('.')[-3:])+"\n"
                                                stack_trace += line.split('(')[1:][0][:-1] + "\n"
                                        html_text += "<br/><div class='stackTraceTitle'><span style='font-weight:bold'>StackTrace:</span>  [%s]</div><div style:'display:inline;' class='stackTraceText'><pre>%s</pre></div>" % (test_name, stack_trace)
                                    html_text += "</div>"
                                elif len(failing_cases[error_key]) == 1:
                                    case = failing_cases[error_key][0]
                                    test_failing_from = job_map["api"]["number"] - case["failedSince"]
                                    failing_from_html_text = ""
                                    if test_failing_from > 0:
                                        failing_from_html_text = "<span style='color:red'><br/>(Failing for %s consecutive builds)</span>" % test_failing_from
                                    # html_text += "<br/><br/>Test %s<br/>(Failing for %s consecutive builds)<br/>Error:<br/><pre>%s</pre><br/><br/>stderr:<br><pre>%s</pre>" % ( ".".join(case["className"].split('.')[4:]), job_number - case["failedSince"], case["errorDetails"], case["stderr"])
                                    test_name = ".".join(case["className"].split('.')[4:])
                                    html_text += "<br/><br/><span style='font-weight:bold'>%s</span>%s<div class='errorText'><pre>%s</pre></div>" % (test_name, failing_from_html_text, html.escape(case["errorDetails"]))
                                    stack_trace = ""
                                    for line in case["errorStackTrace"].split('\n'):
                                        if test_name in line:
                                            # stack_trace += ".".join(line.split('.')[-3:])+"\n"
                                            if "(" in line:
                                                stack_trace += line.split('(')[1:][0][:-1] + "\n"
                                            else:
                                                stack_trace += line + "\n"
                                    html_text += "<br/><div class='stackTraceTitle'><span style='font-weight:bold'>StackTrace:</span></div><div style:'display:inline;' class='stackTraceText'><pre>%s</pre></div>" % stack_trace
                                    img_link = self.get_img_url(job_map['api'], test_name)
                                    html_text += "<br/><div class='img'><a href='%s'><img class='error_img' src='%s' alt='image' height='%spx' width='%spx'/></a></div>" % (img_link, img_link, img_height, img_width)
                    else:
                        html_text += "</div>"
                else:
                    html_text += "</div>"

                # if "api" in job:
                #  html_text += "<br/><br/><br/><br/>"
                html_text += "</div>"
            html_text += "</div>"
        elif len(builds_keys) > 1:
            html_text += "Many"
        else:
            logger.info("Nothing to print")
        html_text += "</body></html>"
        return html_text


def get_file_size_in_kb(file_path):
    size_in_bytes = os.path.getsize(file_path)
    size_in_kb = size_in_bytes / 1024
    return round(size_in_kb, 2)


def read_credentials():
    # Read credentials from a file
    home_dir = os.path.expanduser("~")
    CREDENTIALS_FILEPATH = os.path.join(home_dir, ".jenkins_api_credentials.txt")
    logger.debug("CREDENTIALS_FILEPATH\t{}".format(CREDENTIALS_FILEPATH))
    API_USER = None
    API_TOKEN = None
    with open(CREDENTIALS_FILEPATH, 'r') as file:
        lines = file.readlines()
        for line in lines:
            if 'API_USER' in line:
                API_USER = line.split('=')[1].strip()
            if 'API_TOKEN' in line:
                API_TOKEN = line.split('=')[1].strip()
    logger.debug("API_USER\t\t{}".format(API_USER))
    if API_USER == None or API_TOKEN == None:
        raise Exception(f"ERROR: credentials (API_USER and/or API_TOKEN) missing in '{CREDENTIALS_FILEPATH}'")
    return API_USER, API_TOKEN


def main():
    API_USER, API_TOKEN = read_credentials()

    # args
    if len(sys.argv) != 4:
        raise Exception(f"ERROR: 4 arguments are required ({len(sys.argv)} given). Usage: {sys.argv[0]} BUILD_URL output_path try_ret_init_build_number list_of_builds")

    BUILD_URL = sys.argv[1]
    OUTPUT_PATH = os.path.realpath(sys.argv[2])
    LIST_OF_BUILDS = sys.argv[3]

    logger.info("BUILD_URL\t\t{}".format(BUILD_URL))
    if not os.path.isdir(OUTPUT_PATH):
        raise Exception("ERROR: the output_path '{}' must exist".format(OUTPUT_PATH))
    # ci_base_url="https://ci.openbravo.com"
    ci_base_url = '{uri.scheme}://{uri.netloc}'.format(uri=urlparse(BUILD_URL))
    logger.debug("ci_base_url\t\t{}".format(ci_base_url))
    OUTPUT_PATH = os.path.join(OUTPUT_PATH, OUTPUT_FILENAME)
    logger.info("OUTPUT_PATH\t\t{}".format(OUTPUT_PATH))
    logger.info('')

    # 1. create the API handler
    if IS_CACHE_ACTIVE == True:
        jenkinsPythonApi = JenkinsPythonApiWithCache(ci_base_url, API_USER, API_TOKEN)  # uses python3-jenkins api and caches the results
    else:
        jenkinsPythonApi = JenkinsPythonApi(ci_base_url, API_USER, API_TOKEN)  # uses python3-jenkins api
    # jenkinsPythonApi = JenkinsHttpRequestApi(ci_base_url, API_USER, API_TOKEN)  # uses http requests

    # 2. generate HTML using the API handler
    html_generator = HTMLTextGenerator(jenkinsPythonApi, ci_base_url, BUILD_URL, LIST_OF_BUILDS)
    html_text = html_generator.generate_html_text()

    # 3. write the HTML to the output path
    with open(OUTPUT_PATH, "w") as text_file:
        text_file.write(html_text)

    logger.success(f"report available at {OUTPUT_PATH}")


if __name__ == "__main__":
    # This code is run when script is executed directly
    main()
