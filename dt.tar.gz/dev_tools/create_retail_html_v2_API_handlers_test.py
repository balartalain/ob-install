import unittest
from unittest.mock import MagicMock, patch, mock_open
import jenkins
from create_retail_html_v2 import JenkinsPythonApi
# from create_retail_html_v2 import JenkinsPythonApiWithCache
# from create_retail_html_v2 import JenkinsHttpRequestApi


class TestAPI(unittest.TestCase):
    def setUp(self):
        self.api = JenkinsPythonApi('http://localhost', 'user', 'token')
        self.api.server = MagicMock(spec=jenkins.Jenkins)

    def test_get_build_console_output(self):
        with patch('os.path.isfile', return_value=True):
            with patch('builtins.open', mock_open(read_data='console output'), create=True) as m:
                output = self.api.get_build_console_output('job', 123)
                self.assertEqual(output, 'console output')

    def test_get_build_console_output_file_not_found(self):
        with patch('os.path.isfile', return_value=False):
            with self.assertRaises(Exception) as context:
                self.api.get_build_console_output('job', 123)
            self.assertTrue('No such file' in str(context.exception))

    def test_get_job_info(self):
        self.api.server.get_build_info.return_value = {
            'building': False,
            'number': 123,
            'url': 'http://localhost/job/123',
            'result': 'SUCCESS',
            'duration': 10,
            'displayName': 'Job 123',
            'artifacts': [{'relativePath': 'path'}],
        }
        expected_data = {
            'building': False,
            'number': 123,
            'url': 'http://localhost/job/123',
            'result': 'SUCCESS',
            'duration': 10,
            'displayName': 'Job 123',
            'artifacts': ['path'],
        }
        data = self.api.get_job_info('job', '123')
        self.assertEqual(data, expected_data)

    def test_get_test_report(self):
        self.api.server.get_build_test_report.return_value = {
            'duration': 10,
            'suites': [
                {
                    'duration': 5,
                    'name': 'TestSuite1',
                    'cases': [
                        {
                            'status': 'REGRESSION',
                            'errorDetails': 'Some error details [2023-07-16T12:34:56+0000]'
                        },
                        {
                            'status': 'PASSED'
                        },
                        {
                            'status': 'FAILED',
                            'errorDetails': 'Some other error details [2023-07-16T12:34:56+0000]'
                        }
                    ]
                },
                {
                    'duration': 5,
                    'name': 'TestSuite2',
                    'cases': [
                        {
                            'status': 'PASSED'
                        }
                    ]
                }
            ],
            'failCount': 2
        }
        data = self.api.get_test_report('job', '123')
        self.assertEqual(data, self.api.server.get_build_test_report.return_value)


if __name__ == '__main__':
    unittest.main()
