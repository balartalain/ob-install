#!/usr/bin/env python3

"""
Launches a try, try-retail or try-retail with modules build
on jenkins with the current workspace given a set of parameters
"""

import argparse
import json
import logging.handlers
import os
import re
import shlex
import shutil
import subprocess
import sys
import signal
import traceback
import time
import tempfile
import atexit
from pathlib import Path
from datetime import datetime
from xml.dom.minidom import parseString as parseXml
from urllib import request, error
from multiprocessing.pool import Pool

# discover environment
EXECUTABLE_PATH = Path(os.path.dirname(__file__))
EXECUTABLE_FILENAME = os.path.basename(__file__)
EXECUTABLE_NAME = Path(os.path.basename(__file__)).stem

CYAN = "\033[0;36m"
GREEN = '\033[0;32m'
IRED = "\033[1;91m"
ORANGE = '\033[0;33m'
RED = "\033[0;31m"
WHITE = "\033[0;37m"
YELLOW = "\033[0;33m"
NC = '\033[0m'  # No Color

# logger

log_levels = {
    50: 'CRITICAL',
    40: 'ERROR',
    30: 'WARNING',
    20: 'INFO',
    10: 'DEBUG',
    0: 'NOTSET'
}


def log_success(self, message, *args, **kws):
    if self.isEnabledFor(LOG_SUCCESS_LEVEL):
        self._log(LOG_SUCCESS_LEVEL, "{}{}{}".format(GREEN, message, NC), args, **kws)


def log_attention(self, message, *args, **kws):
    if self.isEnabledFor(LOG_ATTENTION_LEVEL):
        self._log(LOG_ATTENTION_LEVEL, "{}{}{}".format(ORANGE, message, NC), args, **kws)


def log_failed(self, message, *args, **kws):
    if self.isEnabledFor(LOG_FAILED_LEVEL):
        self._log(LOG_FAILED_LEVEL, "{}{}{}".format(RED, message, NC), args, **kws)


log_initial_level = logging.DEBUG
# log_format = '%(asctime)-15s  [line %(lineno)-4d] [%(levelname)-7s]   %(message)s'
LOG_FORMATTER = logging.Formatter("%(asctime)s %(message)s", datefmt='%Y-%m-%d %H:%M:%S')
# LOG_FORMAT = '%(asctime)-15s %(levelname)-10s %(message)s'
LOG_SUCCESS_LEVEL = 25  # info is 20
LOG_ATTENTION_LEVEL = 30  # warning is 30
LOG_FAILED_LEVEL = 40  # error is 40
logging.addLevelName(LOG_SUCCESS_LEVEL, "SUCCESS")
logging.addLevelName(LOG_ATTENTION_LEVEL, "ATTENTION")
logging.addLevelName(LOG_FAILED_LEVEL, "FAILED")
logging.Logger.success = log_success  # type: ignore
logging.Logger.attention = log_attention  # type: ignore
logging.Logger.failed = log_failed  # type: ignore
logger = logging.getLogger(__name__)
stream_handler = logging.StreamHandler(sys.stdout)
stream_handler.setFormatter(LOG_FORMATTER)
logger.addHandler(stream_handler)
logger.setLevel(log_initial_level)

# logger.debug("EXECUTABLE_FILENAME\t{}".format(EXECUTABLE_FILENAME))
# logger.debug("EXECUTABLE_PATH\t\t{}".format(EXECUTABLE_PATH))
# logger.info("LOG_LEVEL\t\t{}".format(log_levels.get(log_initial_level, "UNKNOWN")))


def handle_exception(exc_type, value, exc_tb) -> None:
    """
    Catch uncaught exceptions and filter and beautify the output
    """
    if issubclass(exc_type, KeyboardInterrupt):
        # sys.__excepthook__(exc_type, value, exc_tb)
        return
    traceback_line = ""
    traceback_str = ""
    idx = 0
    for file_path, line_number, func_name, text in traceback.extract_tb(exc_tb)[:]:
        idx += 1
        # file_name = Path(file_path).stem
        # build the output
        # if file_name != EXECUTABLE_NAME:
        #     # traceback_line += '%s:' % (file_name)
        #     # print(file_path,func_name)
        #     continue
        traceback_line = '\n%s[%d] ' % (ORANGE, idx)
        traceback_line += '%d' % (line_number)
        if func_name != "<module>":
            traceback_line += ':%s' % (func_name)
        traceback_line += '%s %s' % (CYAN, text)
        file_name = Path(file_path).stem
        traceback_str += traceback_line
    if traceback_str != "":
        traceback_str = "Traceback: {}{}{}".format(ORANGE, traceback_str, NC)
    error_message_formatted = ""
    for s in str(value).split("\n"):
        error_message_formatted += "  {}\n".format(s.strip())
    logger.failed("\n%s:\n%s\n%s" % ("{}{}".format(NC, exc_type.__name__), "{}{}{}".format(RED, error_message_formatted, NC), traceback_str))


sys.excepthook = handle_exception

try_queue_url = "https://gitlab.com/openbravo/devel/try_queues"
try_save_path = tempfile.mkdtemp(prefix="try_queues_")

# This is the default modules json file for try-retail, if no try-retail modules.json is provided
try_retail_default_json_url = "https://gitlab.com/openbravo/ci/context_definitions/-/raw/master/retail/try-retail.json"
try_pos2_default_json_url = "https://gitlab.com/openbravo/ci/context_definitions/-/raw/master/retail/pos2_modules.json"

EXECUTABLE_NAME = os.path.basename(__file__)
executable_path = os.path.realpath(sys.argv[0])
match = re.match(r"(.*)/[^/]*$", executable_path)
if match:
    REPO_PATH = match.group(1)
else:
    raise ValueError("Failed to match REPO_PATH pattern in executable path")
RUN_PROCESS_ERROR = "RUN_PROCESS_ERROR"

multiprocessing_batch_size = (
    10  # the maximum number of processes that can be executed at the same time
)
# Those hardcoded modules allow to remove or add them when executing try or try-retail
retail_modules = [
    {
        "name": "org.openbravo.retail.discounts",
        "path": "modules/org.openbravo.retail.discounts",
    },
    {
        "name": "org.openbravo.retail.posterminal",
        "path": "modules/org.openbravo.retail.posterminal",
    },
    {
        "name": "org.openbravo.retail.config",
        "path": "modules/org.openbravo.retail.config",
    },
    {"name": "org.openbravo.mobile.core", "path": "modules/org.openbravo.mobile.core"},
    {
        "name": "org.openbravo.retail.returns",
        "path": "modules/org.openbravo.retail.returns",
    },
    {
        "name": "org.openbravo.retail.sampledata",
        "path": "modules/org.openbravo.retail.sampledata",
    },
    {
        "name": "org.openbravo.retail.poshwmanager",
        "path": "modules/org.openbravo.retail.poshwmanager",
    },
    {"name": "org.openbravo.retail.pack", "path": "modules/org.openbravo.retail.pack"},
]
# include retail pack to pos2

pos2_base_modules = [
    {"name": "org.openbravo.pos2", "path": "modules/org.openbravo.pos2", },
    {"name": "org.openbravo.core2", "path": "modules/org.openbravo.core2", },
    {"name": "org.openbravo.pos2.sampledata", "path": "modules/org.openbravo.pos2.sampledata", },
]

samplebpintegration = [
    {"name": "org.openbravo.retail.samplebpintegration", "path": "modules/org.openbravo.retail.samplebpintegration", },
]

pos2_modules = pos2_base_modules + retail_modules

valid_jobs = [
    "ALL",
    "SIMPLE",
    "SELENIUM",
    "ACCOUNTING",
    "APR",
    "SALPRO",
    "FORMATTING",
    "APR_DEFAULT",
]

def auto_update():
    """
    Auto updates this repository so script is always last version
    """
    current_branch = run_process(
        "git -C {} rev-parse --abbrev-ref HEAD".format(REPO_PATH)
    ).strip()
    is_local_branch = run_process(
        "git ls-remote --heads {} {} | grep {}".format(
            REPO_URL, current_branch, current_branch
        )
    )
    if is_local_branch == "":
        # allow the development of this script in a branch that has not been created in the remote repo.
        # no update required
        return
    rev1 = run_process("git -C {} rev-parse HEAD".format(REPO_PATH))
    run_process("git -C {} pull".format(REPO_PATH))
    rev2 = run_process("git -C {} rev-parse HEAD".format(REPO_PATH))
    if rev1 != rev2:
        logger.info("\n\n * Found update, you need to relaunch again this script !\n\n")
        sys.exit(-1)


def run_process(command, break_on_failure=True):
    """
    Runs a command as a subprocess and returns the result of execution, this is synchronous
    :param command: Bash command to be executed
    :param break_on_failure: Generates an exception if process exited with failure(exitcode != 0)
    :return: Result of execution
    """
    kwargs = {"stdout": subprocess.PIPE, "stderr": subprocess.PIPE}
    proc = subprocess.Popen(shlex.split(command), **kwargs)
    (stdout_str, stderr_str) = proc.communicate()
    return_code = proc.wait()
    if return_code != 0:
        if break_on_failure:
            logger.error(stdout_str.decode("UTF-8"))
            raise Exception(stderr_str.decode("UTF-8"))
        return RUN_PROCESS_ERROR
    return stdout_str.decode("UTF-8")


def get_repo_rev(prev_url, branch):
    """
    Retrieve branch remote SHA, try first with SSH and if it fails, fall back to HTTPS
    :param prev_url: URL of the remote repository
    :param branch: branch to get revision from
    :return: revision of master-branch for automation-repo
    """

    ssh_url = prev_url.replace("https://gitlab.com/", "git@gitlab.com:")
    revision = run_process("git ls-remote {}.git {}".format(ssh_url, branch), False)
    # if it fails, try http (required for CI)
    if revision == RUN_PROCESS_ERROR:
        revision = run_process("git ls-remote {}.git {}".format(prev_url, branch))
    return revision.split()[0]


def get_revision(repo):
    """
    Returns current revision of provided repository path and also returns if it has been pushed or not
    :param repo: Repository path
    :return: current revision, pushed state, remote used for the push
    """
    remote = ""
    revision = run_process("git -C {} rev-parse HEAD".format(repo))
    revision = revision.replace("\n", "")
    has_been_pushed = run_process(
        "git -C {} branch -r --sort=committerdate --contains {}".format(repo, revision)
    )
    if not has_been_pushed:
        return revision, False, remote
    else:
        # For checking on what remote our changes are, assume origin and if not, the first remote listed
        if "origin" in has_been_pushed:
            remote = "origin"
        else:
            for line in has_been_pushed.splitlines():
                remote = line.partition("/")[0].strip()
                break
        return revision, True, remote


def check_if_repo_exist(repo):
    """
    Checks if a repository exists or not
    :param repo: Repository path
    :return: True if repo exists, False otherwise
    """
    return os.path.exists(repo) and os.path.exists(os.path.join(repo, ".git"))


def get_repo_url(repo, remote):
    """
    Returns parsed repository url in https:// format
    :param repo: Repository path
    :param remote: Remote used for the push
    :return: URL of repository
    """
    url = run_process("git -C {} config --get remote.{}.url".format(repo, remote))
    if url.startswith("git"):
        url = url.replace(":", "/")
        url = url.replace("git@", "https://")

    url = url.replace(".git", "")
    url = url.replace("\n", "")
    return url


def is_json_file(file):
    """
    Returns if a file is a valid json file
    :param file: Json file path
    :return: True if file is a valid json, False otherwise
    """
    if not os.path.exists(file):
        raise Exception("ERROR: file not found at '{}'".format(file))
    with open(file) as fp:
        try:
            json.load(fp)
            return True
        except ValueError:
            return False


class UpdateScript(argparse.Action):
    def __init__(self, option_strings, dest, nargs=None, **kwargs):
        super(UpdateScript, self).__init__(option_strings, dest, nargs=nargs, **kwargs)

    def __call__(self, parser, namespace, values, option_string=None):
        # Here you would put your script update logic
        # For the purpose of this example, let's say it's a git pull command
        result = subprocess.run(['git', 'pull'], capture_output=True, text=True)
        print(result.stdout)
        parser.print_help()
        parser.exit()


def _parse_args():
    # Setup parser with arguments
    parser = argparse.ArgumentParser(
        description="This script will execute try or try-retail with current workspace commits.",
        usage='%(prog)s --desc "description" [--backoffice|--retail|--pos2]\n'
        + "For more information run %(prog)s with -h option",
        add_help=False,  # We disable the built-in help so we can add our custom one
        epilog="""
Notes:
  * http://build.openbravo.com/view/try or try-retail to follow the build or see the queue
  * The script uses the versions selected (git SHA) in the repositories, not the master of the repos

Typical usage:
  %(prog)s --desc "description" [--backoffice|--retail|--pos2]
        """,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    parser.add_argument('-h', '--help', action=UpdateScript, nargs=0)

    typical = parser.add_argument_group("typical")
    # Add your existing arguments here

    typical = parser.add_argument_group("typical")
    typical.add_argument(
        "--desc",
        "-d",
        help="build description, give some info about the push to "
        "try so you can identify easily in the mail the try run",
    )
    typical.add_argument(
        "--backoffice", "-b", action="store_true", help="executes try(backoffice)",
    )
    typical.add_argument(
        "--retail", "-r", help="executes try-retail", action="store_true"
    )
    typical.add_argument(
        "--pos2", "-p2", help="executes try-pos2", action="store_true"
    )
    typical.add_argument(
        "--api",
        help="To test custom api changes in ../backoffice-api or ../mobile-api, targeted fro master branch, for releases(api tags will be used).",
        action="store_true"
    )
    typical.add_argument(
        "--ignore-local-changes",
        "-c",
        dest="ignore_local_changes",
        action="store_true",
        help="consider local changes as warnings instead of errors and proceed with try/try-retail execution",
    )
    typical.add_argument(
        "--priority",
        "-p",
        dest="priority",
        action="store_true",
        help="if set to true this try/try-retail run will be added to the top of the build queue",
    )

    advanced = parser.add_argument_group("advanced")
    advanced.add_argument(
        "--jobs-to-run",
        help="in case of running try, sets the jobs to run. Separate them by ','.\n"
        "Valid options: ALL, SIMPLE, SELENIUM, ACCOUNTING, APR, SALPRO, FORMATTING, APR_DEFAULT",
        dest="jobs_to_run",
        default="SIMPLE,SELENIUM,APR_DEFAULT,FORMATTING,ACCOUNTING",
    )
    advanced.add_argument(
        "--ignore-automation-repo",
        "-a",
        dest="ignore_automation_repo",
        action="store_true",
        help="Don't force to specify the automation repo",
    )
    advanced.add_argument(
        "--automation-repo-path",
        "-m",
        dest="automation_repo_path",
        help="use the local version of the automation repo (mobile-test) defined in the path. "
        "It is  mandatory to specify the automation repo, if not it will check the default place ../mobile-test, "
        "if not found will exit with a failure. "
        "If you want to skip this check use the --ignore-automation-repo parameter",
        default="../mobile-test",
    )

    advanced.add_argument(
        "--quiet",
        "-q",
        action="store_true",
        help="set logging level to warning, by default is info",
    )
    advanced.add_argument(
        "--verbose",
        "-v",
        action="store_true",
        help="set logging level to debug, by default is info",
    )
    advanced.add_argument(
        "--edit-before-push",
        action="store_true",
        help="allows to edit resulting json before push",
    )
    advanced.add_argument(
        "--db2",
        "--db2",
        dest="db2",
        help="set db2 database version (reserved for future use, not implemented yet)",
    )
    advanced.add_argument(
        "--db-postgres-version",
        "--postgres",
        dest="db_postgres_version",
        help="set postgres database version",
    )
    advanced.add_argument(
        "--nodejs-version",
        "--nodejs",
        dest="nodejs_version",
        help="specify the Node.js version. Accepts both major version (e.g. '18') or detailed version (e.g. '18.17.0')",
    )
    advanced.add_argument(
        "--java-version",
        "--java",
        dest="java_version",
        help="set java jre/jdk version",
    )
    advanced.add_argument(
        "--only-notify-failure",
        dest="notify_only_failure",
        help="only sends notification mails on failure, instead of always",
        action="store_true",
    )
    advanced.add_argument(
        "--notification-mails",
        dest="notification_mails",
        help="sets extra notification mails to be notified",
    )
    advanced.add_argument(
        "--dry-run", action="store_true", help="do not trigger a build in jenkins"
    )
    advanced.add_argument(
        "--build-with-dry-run", action="store_true", help="triggers a DRY_RUN build in Jenkins "
    )
    advanced.add_argument(
        "--ignore-local-repositories",
        "-IL",
        action="store_true",
        help="ignore all local repositories and use versions provided from json or by default",
    )
    advanced.add_argument(
        "--cicd",
        action="store_true",
        help="use cicd to test the build",
    )
    parser.add_argument(
        "repository_path",
        metavar="repo",
        default=".",
        nargs="?",
        help="path to openbravo repository to run try/try-retail on",
    )
    parser.add_argument(
        "out_file",
        metavar="outfile",
        default="/tmp/try-push.json",
        nargs="?",
        help="path to save resulting json",
    )
    advanced.add_argument(
        "--suite-prefix",
        dest="suite_prefix",
        default="01",
        help="01 = execute all tests. "
        "90 = execute only 2 tests in each job (good to know the health of the framework and jobs). "
        "the prefix must correspond with the prefix used inside mobile-test",
    )
    advanced.add_argument(
        "--dev-mode",
        action="store_true",
        help="activates development mode, skipping certain parts of the script for a streamlined development experience.",
    )
    parser.add_argument(
        "--context-definition",
        "-j",
        help="Use a json from https://gitlab.com/openbravo/ci/context_definitions"
        "Example: retail/try-retail",
        dest="context_definition",
    )
    parser.add_argument(
        "--context-definition-from-url",
        "-u",
        help="Use a json from any url",
        dest="context_definition_from_url",
    )
    parser.add_argument(
        "--context-definition-from-file",
        "-l",
        "--modules-json",
        help="Use a json from local file system",
        dest="context_definition_from_local",
    )

    return parser.parse_args(), parser


def get_params(arguments):
    """
    Gets the extra parameters from args provided by the user and returns them as expected by jenkins
    :param arguments Arguments already parsed containing params
    :return: parameters
    """
    result_params = {}
    if arguments.db2:
        result_params["db2"] = arguments.db2
    if arguments.db_postgres_version:
        result_params["db_postgres_version"] = arguments.db_postgres_version
    if arguments.nodejs_version:
        result_params["nodejs_version"] = arguments.nodejs_version
    if arguments.java_version:
        result_params["java_version"] = arguments.java_version
    if arguments.suite_prefix:
        result_params["suite_prefix"] = arguments.suite_prefix
    if arguments.build_with_dry_run:
        result_params["dry_run"] = "Yes"
    if arguments.notify_only_failure:
        result_params["notification"] = "FAILURE"
    else:
        result_params["notification"] = "ALWAYS"
    if arguments.notification_mails and len(arguments.notification_mails) > 0:
        split_mails = arguments.notification_mails.split(",")
        if len(split_mails) > 0:
            result_params["notification_add"] = split_mails

    return result_params


def check_if_modules_exist(modules):
    """
    Checks if retail modules exist and are indeed git repositories
    :return: True if retail modules exist and are git repositories, False otherwise
    """
    repos_exist = True
    for module in modules:
        if not check_if_repo_exist(os.path.join(erp_repo_path, module["path"])):
            # Ignore sampledata, as it is not always present
            if try_retail and module["name"] == "org.openbravo.retail.sampledata":
                continue
            logger.error(
                "{} module repository does not exist or is not a git repository.".format(
                    module["name"]
                )
            )
            repos_exist = False
    return repos_exist


def has_local_changes(repo):
    """
    Checks if a repository has local changes and ignore untracked files
    :param repo: Repository path
    :return: True if repository has local changes, False otherwise
    """
    status = run_process("git -C {} status -uno --porcelain".format(repo))
    return status != ""


def get_context_definition_url(
    context_definition, context_definition_from_url, context_definition_from_local
):
    if context_definition:
        context_definition_url = "https://gitlab.com/openbravo/ci/context_definitions/-/raw/master/{}.json".format(
            context_definition
        )
    elif context_definition_from_url:
        context_definition_url = context_definition_from_url
    elif context_definition_from_local:
        # File is first resolved to absolute path
        context_definition_from_local = os.path.abspath(context_definition_from_local)
        context_definition_url = "file://{}".format(context_definition_from_local)
    else:
        if try_pos2:
            context_definition_url = "https://gitlab.com/openbravo/ci/context_definitions/-/raw/master/retail/pos2-modules.json"
        else:
            context_definition_url = "https://gitlab.com/openbravo/ci/context_definitions/-/raw/master/retail/try-retail.json"
    return context_definition_url


def get_context_erp_automation_and_modules(
    context_definition_url, erp, automation, mods, deps
):
    # User agent is needed because gitlab blocks webscrappers
    req = request.Request(context_definition_url, headers={"User-Agent": "Mozilla/5.0"})
    in_file = request.urlopen(req).read()
    config = json.loads(in_file.decode("utf-8"))
    if "imports" in config:
        for imp in config.get("imports"):
            context_definition_url = get_context_definition_url(
                imp.get("context-definition"),
                imp.get("context-definition-from-url"),
                imp.get("context-definition-from-file"),
            )
            erp, automation, mods, deps = get_context_erp_automation_and_modules(
                context_definition_url, erp, automation, mods, deps
            )
    if "erp" in config:
        erp = config["erp"]
    if "automation" in config:
        for automation_repo in config["automation"]:
            automation[automation_repo["javapackage"]] = automation_repo
    if "mods" in config:
        for mod in config["mods"]:
            mods[mod["javapackage"]] = mod
    if "deps" in config:
        for mod in config["deps"]:
            deps[mod["javapackage"]] = mod
    return erp, automation, mods, deps


def get_config_json(context_definition_url):
    erp, automation, mods, deps = get_context_erp_automation_and_modules(
        context_definition_url, {}, {}, {}, {}
    )
    config_summary = {}
    config_summary["erp"] = erp
    config_summary["automation"] = automation.values()
    config_summary["mods"] = mods.values()
    config_summary["deps"] = deps.values()
    return config_summary

def get_api_checks_repo_changeset(api_repo, api_java_package):
    if custom_api:
        if check_if_repo_exist(api_repo) :
            if has_local_changes(api_repo):
                if ignore_local_changes:
                    logger.warning("Local changes detected in {} repo..format(api_repo)")
                else:
                    logger.error(
                        "Local changes detected in api repo."
                        "\nIf you want to ignore this error, add parameter --ignore-local-changes."
                        " See {} -h for help.".format(EXECUTABLE_NAME)
                    )
                    sys.exit(-1)
            api_rev, pushed, api_remote = get_revision(api_repo)
            if not pushed:
                logger.error(
                    "There are non pushed commits in {} backoffice_api repo. If used --api then local changes must be pused to repo.".format(
                        api_repo
                    )
                )
                sys.exit(-1)
            api_url = get_repo_url(api_repo, api_remote)
        else:
            logger.error(" * Api repo {} doesn't exist or is not a git repository.".format(
                        api_repo ))
            sys.exit(-1)
    else:
        api_url = "https://gitlab.com/openbravo/ci/" + api_java_package  # Hard-coded automation repo default URL
        api_rev = get_repo_rev(api_url, "master")

    return api_url, api_rev

def add_backoffice_context(configuration, arguments):
    """
    Creates a context definition to run backoffice try
    :param configuration: Configuration where it will be added
    :param arguments: Command line arguments needed to create backoffice_context
    """
    logger.info(" * Running checks for try-backoffice")
    # Test if jobs provided are valid for try-backoffice
    jobs_to_run_non_split = arguments.jobs_to_run
    jobs_to_run = []
    if jobs_to_run_non_split != "":
        jobs_to_run = jobs_to_run_non_split.split(",")
        for job in jobs_to_run:
            if job not in valid_jobs:
                logger.error(
                    "{} is not a valid job for try-backoffice. Valid jobs: {}".format(
                        job, valid_jobs
                    )
                )
                sys.exit(-1)
    if (
        not ignore_automation_repo
        and not try_retail
        and check_if_repo_exist(automation_repo)
        and not ignore_local_changes
    ):
        automation_rev, pushed, automation_remote = get_revision(automation_repo)
        if not pushed:
            if ignore_local_changes:
                logger.warn(
                    "There are non pushed commits in {} automation repo. To ignore this repo add --ignore-automation-repo.".format(
                        automation_repo
                    )
                )
            else:
                logger.error(
                    "There are non pushed commits in {} automation repo. To ignore this error add --ignore-local-changes.".format(
                        automation_repo
                    )
                )
                sys.exit(-1)
        automation_url = get_repo_url(automation_repo, automation_remote)
    else:
        automation_url = "https://gitlab.com/openbravo/ci/backoffice-test"  # Hard-coded automation repo default URL
        automation_rev = get_repo_rev(automation_url, "master")
    automation_java_package = "backoffice-test"

    backoffice_api_url, backoffice_api_rev = get_api_checks_repo_changeset(backoffice_api_repo, backoffice_api_java_package)

    # Doing a try to backoffice, instead of retail, add erp context_definition
    backoffice_context = {
        "erp": {"method": "git", "params": {"url": erp_url, "ver": erp_rev}},
        "automation": [
            {
                "method": "git",
                "params": {"url": automation_url, "ver": automation_rev},
                "javapackage": automation_java_package,
            },
        ],
        "backoffice_api": [
            {
                "method": "git",
                "params": {"url": backoffice_api_url, "ver": backoffice_api_rev},
                "javapackage": backoffice_api_java_package,
            },
        ],
    }
    if len(jobs_to_run) > 0:
        configuration["parameters"]["job_groups_to_build"] = jobs_to_run
    configuration["context_definitions"]["backoffice"] = backoffice_context


def add_retail_context(configuration, arguments):
    """
    Checks local modules, both from pack and local external modules and adds them to a try-retail configuration
    :param configuration: Configuration where it will be added
    :param arguments: Command line arguments needed to create retail_context
    """
    # Initialize
    retail_pack_context = {
        "erp": {"method": "git", "params": {"url": erp_url, "ver": erp_rev}},
        "deps": [],
    }

    context_definition_url = get_context_definition_url(
        args.context_definition,
        args.context_definition_from_url,
        args.context_definition_from_local,
    )
    logger.info(" * Using context definition: {}".format(context_definition_url))

    # If true, don't check for local versions
    try_retail_modules_json = get_config_json(context_definition_url)

    logger.info(" * Running checks for try-retail")
    if not ignore_local_repositories and not check_if_modules_exist(retail_modules):
        sys.exit("Some modules repositories don't exist in modules folder.")

    # Check if automation repo provided is valid
    automation_repo_retail = arguments.automation_repo_path
    if not ignore_automation_repo:
        if automation_repo_retail == "../mobile-test":
            if not check_if_repo_exist(automation_repo_retail):
                logger.error(
                    " * No automation repo specified and repo doesn't exist in default path: ../mobile-test. "
                    "Use --ignore-automation-repo parameter to skip this check"
                )
                sys.exit(-1)
            else:
                logger.info(
                    " * No automation repo specified, "
                    "using the local version of the automation repo in the default path: {}".format(
                        automation_repo_retail
                    )
                )
        else:
            if not check_if_repo_exist(automation_repo_retail):
                logger.error(
                    " * Automation repo {} doesn't exist or is not a git repository.".format(
                        automation_repo_retail
                    )
                )
                sys.exit(-1)
        automation_rev, pushed, remote_for_automation = get_revision(automation_repo)
        if not pushed and not ignore_local_changes:
            logger.error("There are changes not pushed on automation repository.")
            sys.exit(-1)
        elif not pushed and ignore_local_changes:
            logger.warning("There are changes not pushed on automation repository.")
        automation_url = get_repo_url(automation_repo, remote_for_automation)
    else:
        # Check automation_repo version from json if present first
        if (
            "automation" in try_retail_modules_json
            and len(try_retail_modules_json["automation"]) > 0
        ):
            list_automation = list(try_retail_modules_json["automation"])
            automation_url = list_automation[0]["params"]["url"]
            automation_rev = list_automation[0]["params"]["ver"]
        else:
            automation_url = "https://gitlab.com/openbravo/ci/mobile-test"  # Hard-coded automation repo default URL
            automation_rev = get_repo_rev(automation_url, "master")

    automation_java_package = "mobile-test"

    mobile_api_url, mobile_api_rev = get_api_checks_repo_changeset(mobile_api_repo, mobile_api_java_package)
    backoffice_api_url, backoffice_api_rev = get_api_checks_repo_changeset(backoffice_api_repo, backoffice_api_java_package)
    # Add automation repo to context
    retail_pack_context["automation"] = [
        {
            "method": "git",
            "params": {"url": automation_url, "ver": automation_rev},
            "javapackage": automation_java_package,
        },
    ]
    retail_pack_context["backoffice_api"] = [
        {
            "method": "git",
            "params": {"url": backoffice_api_url, "ver": backoffice_api_rev},
            "javapackage": backoffice_api_java_package,
        },
    ]
    retail_pack_context["mobile_api"] = [
        {
            "method": "git",
            "params": {"url": mobile_api_url, "ver": mobile_api_rev},
            "javapackage": mobile_api_java_package,
        },
    ]

    # Check on local changes
    if not ignore_local_repositories:
        modules_with_local_changes = []
        for module in retail_modules:
            # Ignore sampledata if not present
            if module[
                "name"
            ] == "org.openbravo.retail.sampledata" and not check_if_repo_exist(
                os.path.join(erp_repo_path, module["path"])
            ):
                continue
            if has_local_changes(module["path"]):
                modules_with_local_changes.append(module["name"])
        if len(modules_with_local_changes) > 0:
            if ignore_local_changes:
                logger.warning(
                    "Local changes detected in repos: {}".format(
                        modules_with_local_changes
                    )
                )
            else:
                logger.error(
                    "Local changes detected in repos: {}\n".format(
                        modules_with_local_changes
                    )
                    + "If you want to ignore this error, add parameter --ignore-local-changes"
                )
                sys.exit(-1)

    list_modules = retail_pack_context["deps"]

    # Checks for non-pushed commits in retail repos repo
    if not ignore_local_repositories:
        logger.debug(" * Checking non-pushed commits in retail repos")
        error = False
        for module in retail_modules:
            full_module_path = os.path.join(erp_repo_path, module["path"])
            # Ignore sampledata if not cloned locally, this happens when test/modules sampledata is present
            if module[
                "name"
            ] == "org.openbravo.retail.sampledata" and not check_if_repo_exist(
                full_module_path
            ):
                mod_url = "https://gitlab.com/openbravo/product/pmods/{}".format(
                    module["name"]
                )
                # get revision from url
                mod_ver = get_repo_rev(mod_url, "master")
                list_modules.append(
                    {
                        "method": "git",
                        "params": {"url": mod_url, "ver": mod_ver, },
                        "javapackage": module["name"],
                    }
                )
                continue
            mod_ver, push, remote_for_module = get_revision(full_module_path)
            if not push:
                logger.error("Commits not pushed in {} module".format(module["name"]))
                error = True
            else:
                mod_url = get_repo_url(full_module_path, remote_for_module)
                # get revision from url if it is a branch or a tag
                list_modules.append(
                    {
                        "method": "git",
                        "params": {"url": mod_url, "ver": mod_ver, },
                        "javapackage": module["name"],
                    }
                )
        if error:
            sys.exit(-1)
    else:
        # Add all retail modules with provided version in json deps
        for module in retail_modules:
            for mod_in_json in try_retail_modules_json["deps"]:
                if mod_in_json["javapackage"] == module["name"]:
                    mod_url = mod_in_json["params"]["url"]
                    mod_ver = mod_in_json["params"]["ver"]
                    break
            else:
                mod_url = f"https://gitlab.com/openbravo/product/pmods/{module['name']}"
                mod_ver = get_repo_rev(mod_url, "master")
            list_modules.append(
                {
                    "method": "git",
                    "params": {"url": mod_url, "ver": mod_ver, },
                    "javapackage": module["name"],
                }
            )
    # Add try_retail_modules mods info to result
    if not ignore_local_repositories:
        not_pushed_modules = []
        for module in try_retail_modules_json["mods"]:
            full_module_path = os.path.join(
                os.path.join(erp_repo_path, "modules"), module["javapackage"]
            )
            if check_if_repo_exist(full_module_path):
                mod_ver, push, remote_for_module = get_revision(full_module_path)
                if not push:
                    not_pushed_modules.append(module["javapackage"])
                else:
                    mod_url = get_repo_url(full_module_path, remote_for_module)
                    module["params"] = {
                        "url": mod_url,
                        "ver": mod_ver,
                    }

        # Add try_retail_modules deps info to result
        for module in try_retail_modules_json["deps"]:
            full_module_path = os.path.join(
                os.path.join(erp_repo_path, "modules"), module["javapackage"]
            )
            if check_if_repo_exist(full_module_path):
                mod_ver, push, remote_for_module = get_revision(full_module_path)
                if not push:
                    not_pushed_modules.append(module["javapackage"])
                else:
                    mod_url = get_repo_url(full_module_path, remote_for_module)
                    module["params"] = {
                        "url": mod_url,
                        "ver": mod_ver,
                    }
        if len(not_pushed_modules) > 0:
            if ignore_local_changes:
                logger.error(
                    "Some external module repositories have commits not pushed. "
                    "Ignore this with --ignore-local-changes: {}".format(
                        not_pushed_modules
                    )
                )
                sys.exit(-1)
            else:
                logger.warning(
                    "Some external module repositories have commits not pushed, "
                    "ignoring them: {}".format(not_pushed_modules)
                )

    retail_extra_context = {
        "erp": {"method": "git", "params": {"url": erp_url, "ver": erp_rev}},
        "mods": try_retail_modules_json["mods"],
        "deps": try_retail_modules_json["deps"],
        "automation": [
            {
                "method": "git",
                "params": {"url": automation_url, "ver": automation_rev},
                "javapackage": automation_java_package,
            },
        ],
    }
    configuration["context_definitions"]["retail_pack"] = retail_pack_context
    configuration["context_definitions"]["retail_pack_extra"] = retail_extra_context


def add_pos2_context(configuration, arguments, pos2_modules):
    """
    Checks local modules, both from pack and local external modules and adds them to a try-pos2 configuration
    :param configuration: Configuration where it will be added
    :param arguments: Command line arguments needed to create pos2_context
    """
    # Initialize
    pos2_base_context = {
        "erp": {"method": "git", "params": {"url": erp_url, "ver": erp_rev}},
        "mods": [],
        "deps": [],
    }

    # retail modules java package name, used to build deps section of pos2
    ret_mods = []
    for mod in retail_modules:
        ret_mods.append(mod["name"])

    context_definition_url = get_context_definition_url(
        args.context_definition,
        args.context_definition_from_url,
        args.context_definition_from_local,
    )
    logger.info(" * Using context definition: {}".format(context_definition_url))

    # If true, don't check for local versions
    try_pos2_modules_json = get_config_json(context_definition_url)

    logger.info(" * Running checks for try-pos2")
    # Check if source version prior to 23Q4 and include samplebpintegration
    if not ignore_local_repositories:
        ad_module_path = os.path.join(erp_repo_path, "src-db/database/sourcedata/AD_MODULE.xml")
        from xml.dom.minidom import Document
        # Check if the file exists and parse the XML
        if os.path.exists(ad_module_path):
            with open(ad_module_path, 'r') as adModule:
                xml = parseXml(adModule.read())
        else:
            raise FileNotFoundError(f"{ad_module_path} not found")
        if xml is None:
            raise ValueError("'xml' not set")
        version = xml.getElementsByTagName('VERSION')[0].firstChild.nodeValue  # type: ignore
        currentMinor = version.split('.')[-1]
        if int(currentMinor) < 233900:
            pos2_modules = pos2_modules + samplebpintegration

    if not ignore_local_repositories and not check_if_modules_exist(pos2_modules):
        sys.exit("Some modules repositories don't exist in modules folder.")

    # Check on local changes
    if not ignore_local_repositories:
        modules_with_local_changes = []
        for module in pos2_modules:
            if has_local_changes(module["path"]):
                modules_with_local_changes.append(module["name"])
        if len(modules_with_local_changes) > 0:
            if ignore_local_changes:
                logger.warning(
                    "Local changes detected in repos: {}".format(
                        modules_with_local_changes
                    )
                )
            else:
                logger.error(
                    "Local changes detected in repos: {}\n".format(
                        modules_with_local_changes
                    )
                    + "If you want to ignore this error, add parameter --ignore-local-changes"
                )
                sys.exit(-1)

    list_modules = pos2_base_context["mods"]
    list_modules_deps = pos2_base_context["deps"]

    # Checks for non-pushed commits in pos2 repos repo
    if not ignore_local_repositories:
        logger.debug(" * Checking non-pushed commits in pos2 repos")
        error = False
        for module in pos2_modules:
            full_module_path = os.path.join(erp_repo_path, module["path"])
            mod_ver, push, remote_for_module = get_revision(full_module_path)
            if not push:
                logger.error("Commits not pushed in {} module".format(module["name"]))
                error = True
            else:
                mod_url = get_repo_url(full_module_path, remote_for_module)
                # get revision from url if it is a branch or a tag
                if module["name"] in ret_mods:
                    list_modules_deps.append(
                        {
                            "method": "git",
                            "params": {"url": mod_url, "ver": mod_ver, },
                            "javapackage": module["name"],
                        }
                    )
                else:
                    list_modules.append(
                        {
                            "method": "git",
                            "params": {"url": mod_url, "ver": mod_ver, },
                            "javapackage": module["name"],
                        }
                    )
        if error:
            sys.exit(-1)
    else:
        # Add all pos2 modules with provided version in json deps
        for module in pos2_modules:

            for mod_in_json in try_pos2_modules_json["deps"]:
                if mod_in_json["javapackage"] == module["name"]:
                    mod_url = mod_in_json["params"]["url"]
                    mod_ver = mod_in_json["params"]["ver"]
                    break
            else:
                mod_url = f"https://gitlab.com/openbravo/product/pmods/{module['name']}"
                mod_ver = get_repo_rev(mod_url, "master")
            if module["name"] in ret_mods:
                list_modules_deps.append(
                    {
                        "method": "git",
                        "params": {"url": mod_url, "ver": mod_ver, },
                        "javapackage": module["name"],
                    }
                )
            else:
                list_modules.append(
                    {
                        "method": "git",
                        "params": {"url": mod_url, "ver": mod_ver, },
                        "javapackage": module["name"],
                    }
                )
    # Add try_pos2_modules mods info to result
    if not ignore_local_repositories:
        not_pushed_modules = []
        for module in try_pos2_modules_json["mods"]:
            full_module_path = os.path.join(
                os.path.join(erp_repo_path, "modules"), module["javapackage"]
            )
            if check_if_repo_exist(full_module_path):
                mod_ver, push, remote_for_module = get_revision(full_module_path)
                if not push:
                    not_pushed_modules.append(module["javapackage"])
                else:
                    mod_url = get_repo_url(full_module_path, remote_for_module)
                    module["params"] = {
                        "url": mod_url,
                        "ver": mod_ver,
                    }

        # Add try_pos2_modules deps info to result
        for module in try_pos2_modules_json["deps"]:
            full_module_path = os.path.join(
                os.path.join(erp_repo_path, "modules"), module["javapackage"]
            )
            if check_if_repo_exist(full_module_path):
                mod_ver, push, remote_for_module = get_revision(full_module_path)
                if not push:
                    not_pushed_modules.append(module["javapackage"])
                else:
                    mod_url = get_repo_url(full_module_path, remote_for_module)
                    module["params"] = {
                        "url": mod_url,
                        "ver": mod_ver,
                    }
        if len(not_pushed_modules) > 0:
            if ignore_local_changes:
                logger.error(
                    "Some external module repositories have commits not pushed. "
                    "Ignore this with --ignore-local-changes: {}".format(
                        not_pushed_modules
                    )
                )
                sys.exit(-1)
            else:
                logger.warning(
                    "Some external module repositories have commits not pushed, "
                    "ignoring them: {}".format(not_pushed_modules)
                )
    pos2_extra_context = {
        "erp": {"method": "git", "params": {"url": erp_url, "ver": erp_rev}},
        "mods": try_pos2_modules_json["mods"],
        "deps": try_pos2_modules_json["deps"],
    }

    configuration["context_definitions"]["pos2"] = pos2_base_context
    configuration["context_definitions"]["pos2_extra"] = pos2_extra_context


def multiprocess_get_revision(module):
    """
    Obtains revision of module if it is a branch, intended to be used in a pool of workers
    Doesn't modify the initial revision if it is an SHA1 rev
    :param module: Module
    :return: Module with or without revision modified, depending on revision provided
    """
    mod_ver = module["params"]["ver"]
    if not re.match(r"\b[0-9a-f]{7,40}\b", mod_ver):
        module["params"]["ver"] = get_repo_rev(
            module["params"]["url"], module["params"]["ver"]
        )
    return module


def add_revision_for_branches(conf):
    """
    For each branch in modules adds the revision obtained from remote repository
    :param conf: Configuration with multiple context_definitions
    """
    for con_def in conf["context_definitions"]:
        context_definition = conf["context_definitions"].get(con_def)
        if "mods" in context_definition:
            pool = Pool(processes=multiprocessing_batch_size)
            multiple_results = []
            for module in context_definition["mods"]:
                # set the revisions in parallel
                multiple_results.append(
                    pool.apply_async(multiprocess_get_revision, [module])
                )
            all_mods = []
            for res in multiple_results:
                module = res.get()
                all_mods.append(module)
            context_definition["mods"] = all_mods

        if "deps" in context_definition:
            pool = Pool(processes=multiprocessing_batch_size)
            multiple_results = []
            for module in context_definition["deps"]:
                # set the revisions in parallel
                multiple_results.append(
                    pool.apply_async(multiprocess_get_revision, [module])
                )
            all_deps = []
            for res in multiple_results:
                module = res.get()
                all_deps.append(module)
            context_definition["deps"] = all_deps

        if "automation" in context_definition:
            # This doesn't need to be multithreaded
            automation_repos = []
            for automation_repo in context_definition["automation"]:
                automation_modified = multiprocess_get_revision(automation_repo)
                automation_repos.append(automation_modified)
            context_definition["automation"] = automation_repos


def push_config_to_repo(desc):
    """
    Pushes a try/try-retail configuration to try-queue for execution
    """
    # Clone try-queue repo and push changes to it
    if os.path.exists(try_save_path):
        shutil.rmtree(try_save_path)
    ssh_url = try_queue_url.replace("https://gitlab.com/", "git@gitlab.com:")
    has_error = run_process("git clone --depth 1 --branch {} {} {}".format(branch, ssh_url, try_save_path), False)
    # if it fails, try http (required for CI)
    if has_error == RUN_PROCESS_ERROR:
        has_error = run_process(
            "git clone --depth 1 --branch {} {}.git {}".format(branch, try_queue_url, try_save_path)
        )
        if has_error == RUN_PROCESS_ERROR:
            logger.error("Could not clone try-queue repo. Exiting...")
            sys.exit(-1)

    # push to the queue repo
    max_retries = 3
    delay = 1
    for _ in range(max_retries):
        run_process(f"git -C {try_save_path} pull")
        shutil.copy(out_file_path, os.path.join(try_save_path, "try_tryretail.json"))
        run_process(f"git -C {try_save_path} commit -am \"Trigger {build_target} with '{desc}'\"")

        # check for errors after push command
        has_error = None
        # in dev_mode, we test that the retry logic is working but we do not push the build
        if args.dev_mode and delay < 2:
            has_error = RUN_PROCESS_ERROR
            logger.attention(f"dev mode: despite subsequent messages, build to '{build_target}' won't be triggered")
        else:
            if not args.dev_mode:
                has_error = run_process(f"git -C {try_save_path} push origin {branch}", False)
        if has_error == RUN_PROCESS_ERROR:
            logger.attention(f"   push command failed. Retrying in {delay} seconds...")
            # Ensure the repo is in a clean state before any further operations
            run_process(f"git -C {try_save_path} reset --hard HEAD~1")
            run_process(f"git -C {try_save_path} clean -fd")
            time.sleep(delay)
            delay *= 2
            continue
        # clean up
        shutil.rmtree(try_save_path)
        break
    else:
        logger.failed(f"ERROR: Failed to push to {try_queue_url} after {max_retries} attempts")
        sys.exit(1)


def url_exists(url):
    req = request.Request(url, method='HEAD')
    try:
        with request.urlopen(req) as response:
            return response.status == 200
    except error.HTTPError:
        return False


def normalize_nodejs(NODEJS_VERSION):
    """
    Check, expand, and normalize the NODEJS_VERSION parameter.

    The NODEJS_VERSION can accept:
    - A two-digit number corresponding to a node.js major version, e.g. '18'.
    - A detailed version format, e.g. '18.17.0'.

    Note:
    - This function resides in two locations:
        1. `run_try` script
        2. Jenkins-managed script: 'Create properties files for modules jobs'.

      Any modifications made to this function should be mirrored in both places.

    - There's a corresponding Groovy version in the pipelines, which might be disregarded.
    """
    if NODEJS_VERSION:
        if re.match(r'^\d+$', NODEJS_VERSION):
            if not re.match(r'^\d{2}$', NODEJS_VERSION) or int(NODEJS_VERSION) <= 15:
                logger.failed(f"ERROR: NODEJS_VERSION ('{NODEJS_VERSION}') must be a 2-digit number greater than 15")
                sys.exit(1)
            logger.info(f" * Retrieving the latest '{NODEJS_VERSION}' version from nodejs.org...")
            url = f'https://nodejs.org/dist/latest-v{NODEJS_VERSION}.x/'
            if url_exists(url):
                response = request.urlopen(url)
                body = response.read().decode()
                versions = re.findall(r'node-v(\d+\.\d+\.\d+)', body)
                versions.sort(key=lambda s: list(map(int, s.split('.'))))
                NODEJS_VERSION_LATEST = versions[-1] if versions else None
                if NODEJS_VERSION_LATEST is None:
                    logger.failed(f"ERROR: failed to retrieve the latest version of '{NODEJS_VERSION}' from nodejs.org")
                    sys.exit(1)
                logger.info(f" * Latest version found in nodejs.org: {NODEJS_VERSION_LATEST}")
                NODEJS_VERSION = NODEJS_VERSION_LATEST
            else:
                logger.failed(f"ERROR: failed to retrieve the latest version of '{NODEJS_VERSION}' from nodejs.org")
                sys.exit(1)
        elif re.match(r'^\d+\.\d+\.\d+$', NODEJS_VERSION):
            url = f'https://nodejs.org/dist/v{NODEJS_VERSION}/'
            if not url_exists(url):
                logger.failed(f"ERROR: NODEJS_VERSION '{NODEJS_VERSION}' is not available in nodejs.org")
                sys.exit(1)
        else:
            logger.failed(f"ERROR: NODEJS_VERSION ('{NODEJS_VERSION}') does not contain a valid version number. e.g. '18.17.0'")
            sys.exit(1)
    else:
        NODEJS_VERSION = 'system'
    return NODEJS_VERSION


def cleanup_temp_dir() -> None:
    """
    Removes the try_save_path directory and its contents if it exists.
    """
    if os.path.isdir(try_save_path):
        try:
            shutil.rmtree(try_save_path)
        except (PermissionError, FileNotFoundError):
            pass


if __name__ == "__main__":
    if sys.version_info < (3, 6):
        print("Error: Python version prior to 3.6 is not supported.")
        sys.exit(1)

    atexit.register(cleanup_temp_dir)

    args, parser = _parse_args()

    if args.dev_mode:
        LOG_FORMATTER = logging.Formatter("%(asctime)s :%(lineno)-4d %(message)s", datefmt='%Y-%m-%d %H:%M:%S')
        stream_handler.setFormatter(LOG_FORMATTER)
        stream_handler.setLevel(logging.DEBUG)
        logger.attention("dev mode active")
    if args.dry_run:
        logger.attention("DRY_RUN mode active")
    if not args.dev_mode:
        logger.info("Checking for new versions of this script")
        REPO_URL = run_process("git -C {} config --get remote.origin.url".format(REPO_PATH))
        auto_update()
    else:
        logger.attention(f"dev mode: not checking for new versions of this script")

    erp_repo_path = os.path.abspath(args.repository_path)
    out_file_path = args.out_file

    if args.quiet:
        stream_handler.setLevel(logging.WARNING)
        logger.debug("set logging level to warning")
    if args.verbose:
        stream_handler.setLevel(logging.DEBUG)
        logger.debug("set logging level to debug")
    automation_repo = args.automation_repo_path
    description = args.desc
    if not description or description == "":
        logger.error(
            "A valid description must be provided\n" "{}".format(parser.format_usage())
        )
        sys.exit(-1)

    try_backoffice = args.backoffice
    try_retail = args.retail
    try_pos2 = args.pos2
    custom_api = args.api

    if try_retail:
        build_target = "try-retail"
    elif try_backoffice:
        build_target = "try"
    elif try_pos2:
        build_target = "try-pos2"
    else:
        raise ValueError("Unsupported target")

    logger.success("Preparing a new build for {}{}".format(build_target, " {}(cicd){}".format(ORANGE, NC) if args.cicd else ''))

    if not try_backoffice and not try_retail and not try_pos2:
        logger.error(
            "Specify --backoffice or --retail or --pos2 to execute "
            "try-backoffice (try) or try-retail or try-pos2 respectively"
            ". See {} -h for help".format(EXECUTABLE_NAME)
        )
        sys.exit(-1)

    if (try_backoffice and try_retail) or (try_backoffice and try_pos2) or (try_retail and try_pos2):
        logger.error(
            "Multiple pushes not allowed, specify --backoffice or --retail or --pos2 to execute "
            "try-backoffice (try) or try-retail or try-pos2 respectively."
            ". See {} -h for help".format(EXECUTABLE_NAME)
        )
        sys.exit(-1)

    ignore_automation_repo = args.ignore_automation_repo
    priority = args.priority
    edit_before_push = args.edit_before_push
    ignore_local_changes = args.ignore_local_changes
    ignore_local_repositories = args.ignore_local_repositories
    if try_backoffice and not try_retail:
        # Only backoffice execution, change automation_repo_path to default if unchanged
        if automation_repo == "../mobile-test":
            automation_repo = "../backoffice-test"

    backoffice_api_repo = "../backoffice-api"
    mobile_api_repo = "../mobile-api"
    backoffice_api_java_package = "backoffice-api"
    mobile_api_java_package = "mobile-api"

    logger.info(" * Running checks")

    args.nodejs_version = normalize_nodejs(args.nodejs_version)

    parameters = get_params(args)

    # Check if modules folder exist
    if ignore_local_repositories:
        erp_url = "https://gitlab.com/openbravo/product/openbravo"
        erp_rev = get_repo_rev(erp_url, "master")
    else:
        if not os.path.isdir(os.path.join(os.getcwd(), "modules")):
            logger.error(
                " * This script must be executed inside Openbravo root directory."
                "\nIf you want to ignore this error, add parameter --ignore-local-repositories."
                " See {} -h for help.".format(EXECUTABLE_NAME)
            )
            sys.exit(-1)
        else:
            # Check repos for local changes
            if has_local_changes(erp_repo_path):
                if ignore_local_changes:
                    logger.warning("Local changes detected in erp repo.")
                else:
                    logger.error(
                        "Local changes detected in erp repo."
                        "\nIf you want to ignore this error, add parameter --ignore-local-changes."
                        " See {} -h for help.".format(EXECUTABLE_NAME)
                    )
                    sys.exit(-1)

            # Gets erp current revisions
            erp_rev, pushed, remote_for_erp = get_revision(erp_repo_path)
            if not pushed:
                logger.error("There are changes not pushed on ERP repository.")
                sys.exit(-1)

            erp_url = get_repo_url(erp_repo_path, remote_for_erp)

    # Initialize result configuration with provided arguments/parameters
    result_conf = {
        "desc": description,
        "context_definitions": {},
        "priority": priority,
    }
    # Add parameters if any
    if parameters:
        result_conf["parameters"] = parameters
    else:
        result_conf["parameters"] = {}

    if try_retail:
        add_retail_context(result_conf, args)
    elif try_backoffice:
        add_backoffice_context(result_conf, args)
    elif try_pos2:
        add_pos2_context(result_conf, args, pos2_modules)

    # set branch to use cicd or builds based on parameter
    branch = "master"  # default branch
    if args.cicd:
        branch = "cicd"
        logger.info(" * Using {} branch to trigger {} in cicd".format(branch, build_target))

    # All context definitions have been added, revise those and swap master/branch version by the sha obtained from URL
    logger.info(" * Adding remote revisions for branches")
    add_revision_for_branches(result_conf)
    # Add unique ID to json, datetime with certain format, special characters removed
    result_conf["ID"] = datetime.utcnow().strftime("%Y%m%d%H%M%S%f")

    # Save file result_conf in provided out_file
    with open(out_file_path, "w") as f:
        json.dump(result_conf, f, indent=4, sort_keys=True)
        logger.info(f" * json configuration for {build_target} has been saved in {out_file_path}")

    if edit_before_push:
        # Ask user about modifying resulting json file
        while True:
            modify = input("Do you want to modify the payload? [y/N]:") or "n"
            if modify.lower() == "y":
                EDITOR = os.environ.get("EDITOR", "vim")
                p = subprocess.Popen((EDITOR, out_file_path))
                p.wait()
                break
            elif modify.lower() != "n":
                logger.warn("Invalid option: {}. [Y/n]".format(modify))
            else:
                break

        # Recheck that the file is valid by trying to parse it
        if not is_json_file(out_file_path):
            logger.error(
                "Could not parse json file. Faulty file: {}. ".format(out_file_path)
                + "Fix it and push it to {} or rerun script".format(try_queue_url)
            )
            sys.exit(
                "Errors in the {} json file. Fix json and proceed.".format(
                    out_file_path
                )
            )
        else:
            logger.info("{} ✔️".format(out_file_path))

    # At this point it is pushed to try-try-retail-queue, this can be changed easily by a request
    if args.dry_run:
        logger.attention("DRY_RUN: build to {} not triggered".format(build_target))
    else:
        logger.info(" * Sending to {} queue...".format(build_target))
        push_config_to_repo(description)
        logger.success("Build successfully pushed to {}{} ✔️".format(build_target, " {}(cicd){}".format(ORANGE, NC) if args.cicd else ''))
        jenkins_host = 'cicd' if args.cicd else 'builds'
        logger.info(f" * check the queue (wait some seconds): https://{jenkins_host}.openbravo.com/view/rm/job/rm_queueHtml/lastBuild")
