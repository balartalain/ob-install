#!/usr/bin/env python3

"""
Transform a config file for swf-util into config format for use in jenkins modules
"""

import json
import sys
import os
import socket


def usage():
    print("Usage: {} snapshot_file_path <output_file_path>".format(os.path.basename(__file__)))


if len(sys.argv) < 2:
    if (not 'openbravo.com' in socket.gethostname()):
        print("NOTE: testing in '{}' (presumably a dev host)".format(socket.gethostname()))
        # change to the directory where the running script file(.py) exists
        os.chdir(os.path.dirname(os.path.abspath(__file__)))
        file_path = '/tmp/snapshot_test'
    else:
        usage()
        sys.exit("ERROR: missing arguments")
else:
    file_path = sys.argv[1]

if len(sys.argv) >= 3:
    json_output_filename = sys.argv[2]
else:
    json_output_filename = os.path.abspath(os.path.basename("{}.json".format(file_path.lower())))

# argument checks:
if not os.path.exists(file_path):
    sys.exit("ERROR: snapshot file not found at '{}'".format(file_path))

with open(file_path, "r") as f:
    swf_config = f.read().split("\n")

mod_config = {}

desc = file_path.split("/")[-1]
mod_config["desc"] = desc

# first line is always ERP
swf_config_details = swf_config[0].split(" ")
if len(swf_config_details) < 3:
    sys.exit("ERROR: the erp line must contain url, revision and javapackage")
(url, ver, javapackage) = swf_config[0].split(" ")[:3]
default_method = 'git'
mod_config["erp"] = {
    "method": default_method,
    "params": {
        "url": url,
        "ver": ver
    }
}

mod_config["mods"] = []
for mod in swf_config[1:]:
    # ignore non-repository lines
    if (mod.strip() == "") or ("CORE" in mod) or (mod.startswith('*')):
        continue
    mod_details = mod.split(" ")
    if len(mod_details) < 2:
        print("ERROR: the repository entry requires information about repo, version and javapackage. (found: '{}') ".format(mod))
    (url, ver, javapackage) = mod_details[:3]
    if len(mod_details) > 3:
        method = mod_details[3].lower()
    else:
        method = default_method
    print(url, ver, javapackage, method)

    mod_config["mods"].append(
        {
            "method": method,
            "params": {
                "url": url,
                "ver": ver
            },
            "javapackage": javapackage,
        }
    )

print(json.dumps(mod_config, indent=4))
# save to a file
with open(json_output_filename, 'w') as json_output_file:
    json.dump(mod_config, json_output_file, sort_keys=False, indent=4)
print("Saved to '{}'".format(json_output_filename))
