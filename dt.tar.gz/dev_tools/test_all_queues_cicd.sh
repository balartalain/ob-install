#!/bin/bash
# Integration tests for run-try.

set -e

# test try-pos2 queue
python3 run-try.py -d test_pos2_queue_minimal --pos2 --cicd --build-with-dry-run --ignore-local-repositories --ignore-automation-repo --suite-prefix 90

echo
# test try-retail queue
python3 run-try.py  -d test_ret_queue_minimal --retail --cicd --build-with-dry-run --ignore-local-repositories --ignore-automation-repo --suite-prefix 90

echo
# test try queue
python3 run-try.py  -d test_backoffice_queue_minimal --backoffice --cicd --ignore-local-repositories --jobs-to-run SIMPLE
