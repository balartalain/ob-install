#!/bin/bash
# Integration tests for run-try.
# This script does not deploy builds to the Jenkins servers


set -e

COMMON_PARAMS="--dry-run --dev-mode --build-with-dry-run --ignore-local-repositories --ignore-automation-repo"

echo_and_run() {
   desc=$(echo "$1" | sed 's/--//g; s/ /_/g; s/$/_test/')
   command="python3 run-try.py -d ${desc} ${1} ${COMMON_PARAMS} outfile output.json"
   echo ${command}
   eval ${command}
   echo
}

echo_and_run "--backoffice --cicd --nodejs-version 18 --build-with-dry-run"
echo_and_run "--retail --cicd --build-with-dry-run --suite-prefix 90"
echo_and_run "--backoffice"
echo_and_run "--pos2"

# check --dry-mode and --dry-run. neither of them should trigger a build
python3 run-try.py -d test --dev-mode --backoffice --build-with-dry-run --ignore-local-repositories outfile output.json
echo
python3 run-try.py -d test --dev-mode --backoffice --cicd --build-with-dry-run --ignore-local-repositories outfile output.json
echo
python3 run-try.py -d test --dry-run --backoffice --build-with-dry-run --ignore-local-repositories outfile output.json

# run all try jobs
python3 run-try.py --dev-mode  -d test_all_backoffice --backoffice --cicd --ignore-local-repositories outfile output.json --jobs-to-run ALL
echo
# run all try-retail jobs
python3 run-try.py --dev-mode -d test_all_retail --retail --cicd --ignore-local-repositories --ignore-automation-repo outfile output.json --suite-prefix 90
echo
# run all try-pos2 jobs
python3 run-try.py --dev-mode -d test_all_pos2 --pos2 --cicd --ignore-local-repositories --ignore-automation-repo outfile output.json --suite-prefix 90

# send minimal test to try-retail
python3 run-try.py --dry-run  -d test_ret_minimal --retail --cicd --build-with-dry-run --ignore-local-repositories --ignore-automation-repo --suite-prefix 90
