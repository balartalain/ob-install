#!/bin/bash

set -e

DT_SCRIPTS_FOLDER=${DT_SCRIPTS_FOLDER:-$( readlink -f $0 | sed -E 's#/[^/]+$##' )}
. $DT_SCRIPTS_FOLDER/load_config.sh


NUM_ARGS=2
if [ $# != $NUM_ARGS ]
then
  echo "Usage: $(basename $0) CONTEXT_DEFINITION WITH_RESET_HARD" >&2
  exit 1
fi

CONTEXT_DEFINITION=$1
WITH_RESET_HARD=$2

CONTEXT_DEFINITION=$(echo $CONTEXT_DEFINITION | sed 's/@/ /')

if [ "$WITH_RESET_HARD" = "true" ] ; then
  WITH_RESET_HARD_PARAM='--with-reset-hard'
fi

if [ ! -d modules ] ; then
  echo "ERROR: this scripts needs to be called in openbravo folder"
  exit 1
fi

cd ..
clone_context.py --pristines-dir $GIT_PRISTINES_PATH --output-dir openbravo --fix-existing-repos --clone-automation $CONTEXT_DEFINITION $WITH_RESET_HARD_PARAM
cd openbravo

if [ "$WITH_RESET_HARD" = "true" ] ; then
  $DT_SCRIPTS_FOLDER/add_upstreams.py
fi

checkIfAnyReposIsDeletedFromJson.py $CONTEXT_DEFINITION --workspace-directory modules

echo ""
$DT_SCRIPTS_FOLDER/fix-classpath.sh


