#!/usr/bin/env python3


import json
import os
import re

try:
    import git
except:
    print("ERROR: missing gitpython lib. Install it with: pip3 install gitpython")
    exit(1)


def checkCorrectErpFolder(erpPath):
    if not os.path.exists(erpPath + "/modules"):
        print("Execute inside an openbravo folder")
        exit(1)


def getModulesRepos(erpPath):
    return [
        f.name
        for f in os.scandir(erpPath + "/modules")
        if f.is_dir() and os.path.exists(f.path + "/.git")
    ]


def addUpstream(repoPath):
    repo = git.Repo(repoPath)
    branch = repo.active_branch

    remote_name = branch.tracking_branch().remote_name
    remote_url = repo.remotes[remote_name].url

    if "/devel/" in remote_url:
        if "/devel/ci/" in remote_url:
            upstream_url = remote_url.replace("/devel/ci/", "/ci/")
        else:
            upstream_url = remote_url.replace("/devel/", "/product/")
        print("Added upstream:" + upstream_url + " for " + repoPath)
        if "upstream" in repo.remotes:
            repo.remotes.upstream.set_url(upstream_url)
        else:
            repo.create_remote("upstream", url=upstream_url)


# Main
erpPath = os.path.abspath(os.getcwd())
checkCorrectErpFolder(erpPath)

modulesRepos = getModulesRepos(erpPath)

addUpstream(erpPath)
if os.path.exists(erpPath + "../mobile-test"):
    addUpstream(erpPath + "/../mobile-test")
for mod in modulesRepos:
    addUpstream(erpPath + "/modules/" + mod)
