#!/usr/bin/env python3

import os
import json
import sys
import shlex
import argparse
import subprocess
import tempfile
from urllib import request
from urllib.request import Request

RUN_PROCESS_ERROR = "RUN_PROCESS_ERROR"

erp_repos = ['org.openbravo.service.datasource', 'org.openbravo.service.integration.google', 'org.openbravo.client.htmlwidget', 'org.openbravo.client.myob', 'org.openbravo.utility.cleanup.log', 'org.openbravo.client.querylist', 'org.openbravo.v3', 'org.openbravo.client.kernel', 'org.openbravo.advpaymentmngt', 'org.openbravo.service.integration.openid', 'org.openbravo.userinterface.selector', 'org.openbravo.reports.ordersawaitingdelivery', 'org.openbravo.userinterface.smartclient', 'org.openbravo.v3.datasets', 'org.openbravo.service.json', 'org.openbravo.client.widgets', 'org.openbravo.client.application', 'org.openbravo.userinterface.skin.250to300Comp', 'org.openbravo.apachejdbcconnectionpool', 'org.openbravo.financial.paymentreport', 'org.openbravo.base.weld', 'org.openbravo.v3.framework']

def run_process(command, break_on_failure=True):
    """
    Runs a command as a subprocess and returns the result of execution, this is synchronous
    :param command: Bash command to be executed
    :param break_on_failure: Generates an exception if process exited with failure(exitcode != 0)
    :return: Result of execution
    """
    kwargs = {"stdout": subprocess.PIPE, "stderr": subprocess.PIPE}
    proc = subprocess.Popen(shlex.split(command), **kwargs)
    (stdout_str, stderr_str) = proc.communicate()
    return_code = proc.wait()
    if return_code != 0:
        if break_on_failure:
            print(stdout_str.decode("UTF-8"))
            raise Exception(stderr_str.decode("UTF-8"))
        return RUN_PROCESS_ERROR
    return stdout_str.decode("UTF-8")



def get_context_definition_url(
    context_definition,
    context_definition_from_url,
    context_definition_from_local,
    context_definition_from_codesnapshot_file,
):
    if context_definition:
        context_definition_url = "https://gitlab.com/openbravo/ci/context_definitions/-/raw/master/{}.json".format(
            context_definition
        )
    elif context_definition_from_url:
        context_definition_url = context_definition_from_url
    elif context_definition_from_local:
        context_definition_url = "file://{}".format(context_definition_from_local)
    elif context_definition_from_codesnapshot_file:
        global temporaryFileForCodesnapshot
        temporaryFileForCodesnapshot = tempfile.NamedTemporaryFile()
        dest_file = temporaryFileForCodesnapshot.name
        run_process(
            "snapshot2json.py {} {}".format(
                context_definition_from_codesnapshot_file, dest_file
            )
        )
        context_definition_url = "file://{}".format(dest_file)
    else:
        context_definition_url = "https://gitlab.com/openbravo/ci/context_definitions/-/raw/master/retail/try-retail.json"
    return context_definition_url

def get_context_erp_automation_and_modules(
    context_definition_url, erp, automation, modules
):
    # User agent is needed because gitlab blocks webscrappers
    req = Request(context_definition_url, headers={"User-Agent": "Mozilla/5.0"})
    in_file = request.urlopen(req).read()
    config = json.loads(in_file.decode("utf-8"))
    if "imports" in config:
        for imp in config.get("imports"):
            context_definition_url = get_context_definition_url(
                imp.get("context-definition"),
                imp.get("context-definition-from-url"),
                imp.get("context-definition-from-file"),
                imp.get("context-definition-from-codesnapshot-file"),
            )
            erp, automation, modules = get_context_erp_automation_and_modules(
                context_definition_url, erp, automation, modules
            )
    if "erp" in config:
        erp = config["erp"]
    if "automation" in config:
        for automation_repo in config["automation"]:
            automation[automation_repo["javapackage"]] = automation_repo
    if "mods" in config:
        for mod in config["mods"]:
            modules[mod["javapackage"]] = mod
    if "deps" in config:
        for mod in config["deps"]:
            modules[mod["javapackage"]] = mod
    return erp, automation, modules


def get_subfolders(directory):
    return [folder for folder in os.listdir(directory) if os.path.isdir(os.path.join(directory, folder))]

def check_subfolders(modules, directory):
    folders_to_delete = []
    # javapackages = [entry.get("javapackage", "") for entry in json_data.get("modules", []) + json_data.get("deps", [])]

    subfolders = get_subfolders(directory)

    for subfolder in subfolders:
         # if not any(subfolder in javapackage for javapackage in javapackages):
         if subfolder not in modules and subfolder not in erp_repos:
            folders_to_delete.append(subfolder)
    return folders_to_delete

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="This script will check if there are repos not present in a context definition and if so, just notify the user. It will never delete any repo."
    )
    parser.add_argument(
        "--workspace-directory",
        "-d",
        help="workspace directory",
        dest="workspace_dir",
        required=True,
    )
    parser.add_argument(
        "--context-definition",
        "-c",
        help="Use a json from https://gitlab.com/openbravo/ci/context_definitions"
        "Example: retail/try-retail",
        dest="context_definition",
    )
    parser.add_argument(
        "--context-definition-from-url",
        "-u",
        help="Use a json from any url",
        dest="context_definition_from_url",
    )
    parser.add_argument(
        "--context-definition-from-file",
        "-l",
        help="Use a json from local file system",
        dest="context_definition_from_local",
    )
    parser.add_argument(
        "--context-definition-from-codesnapshot-file",
        "-s",
        help="Use a json converted from a local codesnapshot file",
        dest="context_definition_from_codesnapshot_file",
    )
    args = parser.parse_args()

    workspace_dir = args.workspace_dir
    context_definition_url = get_context_definition_url(
        args.context_definition,
        args.context_definition_from_url,
        args.context_definition_from_local,
        args.context_definition_from_codesnapshot_file,
    )


    erp, automation, modules = get_context_erp_automation_and_modules(
        context_definition_url, {}, {}, {}
    )

    folders_to_delete = check_subfolders(modules, workspace_dir)

    if folders_to_delete:
        print('\n\nWARNING: These repos are not in the json, consider if mantain or delete them:\n\n', ''.join(map(lambda x: ' modules/'+x, folders_to_delete)),'\n\n')
