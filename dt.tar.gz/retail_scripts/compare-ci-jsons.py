#!/usr/bin/env python3

import json
import sys

fileName1 = sys.argv[1]
fileName2 = sys.argv[2]

with open(fileName1) as json_data1:
    json1 = json.load(json_data1)

with open(fileName2) as json_data2:
    json2 = json.load(json_data2)

erpver1 = json1["erp"]["params"]["ver"]
erpver2 = json2["erp"]["params"]["ver"]
if erpver1 != erpver2:
    print(
        " * erp:\n"
        + json1["erp"]["params"]["url"].replace('git@gitlab.com:','https://gitlab.com/')
        + "/-/compare/"
        + erpver1
        + "..."
        + erpver2
        + "\n"
    )

if "automation" in json1:
    automationver1 = json1["automation"][0]["params"]["ver"]
    automationver2 = json2["automation"][0]["params"]["ver"]
    if automationver1 != automationver2:
        print(
            " * automation:\n"
            + json1["automation"][0]["params"]["url"].replace('git@gitlab.com:','https://gitlab.com/')
            + "/-/compare/"
            + automationver1
            + "..."
            + automationver2
            + "\n"
        )

for group in ["mods", "deps"]:
    for mod in json1[group]:
        ver1 = mod["params"]["ver"]
        mods2 = None
        for checkmod in json2[group]:
            if checkmod["javapackage"] == mod["javapackage"]:
                mod2 = checkmod
                break
        if mod2 == None:
            print(
                "Not found mod "
                + mod["javapackage"]
                + " from first json in the second json"
            )
        ver2 = mod2["params"]["ver"]
        if ver1 != ver2:
            print(
                " * "
                + mod["javapackage"]
                + ":\n"
                + mod["params"]["url"].replace('git@gitlab.com:','https://gitlab.com/')
                + "/-/compare/"
                + ver1
                + "..."
                + ver2
                + "\n"
            )
