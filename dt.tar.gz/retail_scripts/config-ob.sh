#!/bin/bash

set -e


## Config

DT_SCRIPTS_FOLDER=${DT_SCRIPTS_FOLDER:-$( readlink -f $0 | sed -E 's#/[^/]+$##' )}
. $DT_SCRIPTS_FOLDER/load_config.sh "true"



## Main

NUM_ARGS=4
if [ $# -ne $NUM_ARGS ]
then
  echo "Usage: $(basename $0) WORKSPACE_NAME DUMP SQL_SCRIPT_FILE" >&2
  exit 1
fi

NAME=$1
DUMP=$2
SQL_SCRIPT_FILE=$3
postgresql_version=$4

DB_NAME=$( get_dbname $NAME )

cd $WORKSPACES_PATH
cd $NAME
cd openbravo

cp config/Openbravo.properties.template config/Openbravo.properties
if [ -f config/log4j2.xml.template ] ; then
  ant setup -DnonInteractive=yes -DacceptLicense=yes
else
  cp config/log4j.lcf.template config/log4j.lcf
  cp config/Format.xml.template config/Format.xml
  cp .settings/org.eclipse.wst.common.component.template .settings/org.eclipse.wst.common.component
  cp src-test/.classpath.template src-test/.classpath
fi

$DT_SCRIPTS_FOLDER/fix-classpath.sh

sed -i.sedtemp "s#^bbdd.sid=.*#bbdd.sid=$DB_NAME#" config/Openbravo.properties
sed -i.sedtemp "s#^bbdd.systemPassword=.*#bbdd.systemPassword=$POSTGRES_ADMIN_PASS#" config/Openbravo.properties
sed -i.sedtemp "s#^context.url=.*#context.url=http://localhost/openbravo#" config/Openbravo.properties
sed -i.sedtemp "s#^source.path=.*#source.path=$WORKSPACES_PATH/$NAME/openbravo#" config/Openbravo.properties
sed -i.sedtemp "s#^attach.path=.*#attach.path=$WORKSPACES_PATH/$NAME/openbravo/attachments#" config/Openbravo.properties
sed -i.sedtemp "s#^deploy.mode=.*#deploy.mode=none#" config/Openbravo.properties
if [ "$postgresql_version"  != "default" ] ; then
  port=$(pg_lsclusters | grep "^$postgresql_version" | sed -r 's/\s+/ /g' | cut -d' ' -f3)
  pg_port=" -p $port "
  pg_cluster=" --cluster ${postgresql_version}/main "
  sed -i.sedtemp "s#^bbdd.url=.*#bbdd.url=jdbc:postgresql://localhost:$port#" config/Openbravo.properties
fi
rm config/Openbravo.properties.sedtemp

if [ -f config/log4j2.xml.template ] ; then
  sed -i.sedtemp 's#<!-- <AppenderRef ref="Console"/> -->#<AppenderRef ref="Console"/>#' config/log4j2-web.xml
  sed -i.sedtemp 's#^      <AppenderRef ref="RollingFile"/>#      <!-- <AppenderRef ref="RollingFile"/> -->#' config/log4j2-web.xml
  rm config/log4j2-web.xml.sedtemp
else
  sed -i.sedtemp "s#log4j.rootCategory=INFO, R#log4j.rootCategory=INFO, R, C#" config/log4j.lcf
  rm config/log4j.lcf.sedtemp
fi

cd ..

if [ -d mobile-test ] ; then
  cd mobile-test
  python3 setup.py ../openbravo .
  if [ "$(uname -s | grep Darwin)" != "" ] ; then
    echo "chromedriverPath=$HOME/Documents/chromedrivers/chromedriver-default" >> config/OpenbravoERPTest.properties
    echo 'forceUrl=http://localhost/' >> config/OpenbravoERPTest.properties
  fi
  cd ..
elif [ -d pi-mobile ] ; then
  cd pi-mobile
  python3 setup.py ../openbravo .
  cd ..
fi



# cd openbravo
# # delete a check that is also disabled in ci
# FRANCE_CERT_CHECK_FILE="modules/org.openbravo.certification.france/src/org/openbravo/certification/france/ticket/TicketInitialValidation.java"
# if [ -f $FRANCE_CERT_CHECK_FILE ] ; then
#   rm $FRANCE_CERT_CHECK_FILE
# fi
# cd ..

if [ -f openbravo/package.json ] ; then
  cd openbravo
  npm install
  cd ..
fi

if [ -f $DT_SCRIPTS_FOLDER/eclipse.tgz ]; then
  tar xf $DT_SCRIPTS_FOLDER/eclipse.tgz
  # for location in .metadata/.plugins/org.eclipse.core.resources/.projects/*/.location ; do
  #  sed -i.sedtemp -r "s#URI//file:/.+/openbravo/src-core#URI//file:$WORKSPACES_PATH/$NAME/openbravo/src-core#" $location
  #  rm ${location}.sedtemp
  # done
fi

cd openbravo
$DT_SCRIPTS_FOLDER/fix-vscode-workspace-file.py
cd ..

if [ -d openbravo/modules/org.openbravo.core2 ] ; then
  cp openbravo/modules/org.openbravo.core2/web-jspack/org.openbravo.core2/src-test/cypress.env.json.template openbravo/modules/org.openbravo.core2/web-jspack/org.openbravo.core2/src-test/cypress.env.json
fi

cd openbravo
if [ "$DUMP" == "no" ] ; then
  ant install.source
  PGPASSWORD=tad psql $pg_cluster -h localhost -d $DB_NAME -U tad -c "update ad_module set isindevelopment = 'Y' where javapackage = 'org.openbravo.retail.posterminal';"
  if [ "$SQL_SCRIPT_FILE" != "no" ] ; then
    PGPASSWORD=tad psql $pg_cluster -h localhost -d $DB_NAME -U tad -f $SQL_SCRIPT_FILE
  fi
else
  PGPASSWORD=$POSTGRES_ADMIN_PASS psql $pg_cluster -h localhost -d postgres -U postgres -c "CREATE ROLE tad LOGIN PASSWORD 'tad' CREATEDB CREATEROLE VALID UNTIL 'infinity';" || true # no problem if role tad already exists
  PGPASSWORD=$POSTGRES_ADMIN_PASS psql $pg_cluster -h localhost -d postgres -U postgres -c "CREATE DATABASE ${DB_NAME} WITH ENCODING='UTF8' TEMPLATE=template0;"
  PGPASSWORD=$POSTGRES_ADMIN_PASS psql $pg_cluster -h localhost -d postgres -U postgres -c "ALTER DATABASE ${DB_NAME} OWNER TO tad;"
  PGPASSWORD=tad pg_restore $pg_cluster -j 2 -U tad -d $DB_NAME -h "localhost" -v -O $DUMP || true # bad practice but usually there are errors that can be ignored
  if [ "$SQL_SCRIPT_FILE" != "no" ] ; then
    PGPASSWORD=tad psql $pg_cluster -h localhost -d $DB_NAME -U tad -a -f $SQL_SCRIPT_FILE
  fi
  ant update.database compile.complete.deploy -Dforce=yes
fi
cd ..

if [ -d openbravo/modules/org.openbravo.core2 ] ; then
  cd openbravo/modules/org.openbravo.core2/ && ant build
  cd ../../..
fi

if [ "$(command -v code)" != "" ] ; then
  code $NAME.code-workspace
fi

if [ -f $DT_SCRIPTS_FOLDER/eclipse.tgz ]; then
  eclipse -clean -refresh -data $WORKSPACES_PATH/$NAME &
else
  # if file diff don't exist
  echo "

Not found a saved eclipse.tgz (in $DT_SCRIPTS_FOLDER)

  1.- Start eclipse in a clean workspace (for example the just created)

  2.- Follow the workspace setup guide:
    http://wiki.openbravo.com/wiki/Retail:Developers_Guide/How-to/How_to_Install,_Setup_and_Run_Retail_Automated_Tests#Eclipse_workspace_setup

  3.- Close eclipse, and create a tgz with all the configurations:
     - tar czf eclipse.tgz Servers/ RemoteSystemsTempFiles/ .metadata/
     - mv eclipse.tgz $DT_SCRIPTS_FOLDER/
         Note: This tgz will be used for next workspaces created by the script,
         to avoid to do the config of eclipse again and again
"

fi

echo "all done, exiting"
