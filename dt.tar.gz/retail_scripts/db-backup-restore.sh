#!/bin/bash

set -e


## Config

DT_SCRIPTS_FOLDER=${DT_SCRIPTS_FOLDER:-$( readlink -f $0 | sed -E 's#/[^/]+$##' )}
. $DT_SCRIPTS_FOLDER/load_config.sh "true"

num_args=1
if [ $# -lt $num_args ]
then
  echo "Usage: $(basename $0) backup [dump]" >&2
  exit 1
fi

backup=$1  # backup or restore
DUMP=$2 # optional

## Main

if [ ! -d modules ] ; then
  echo "Needs to be in an openbravo source.path"
  exit 1
fi

DB_NAME=$( cat config/Openbravo.properties | grep ^bbdd.sid | cut -d= -f2 )
pg_port=$( cat config/Openbravo.properties | grep ^bbdd.url | cut -d: -f4 )
pg_cluster=$(pg_lsclusters | grep $pg_port | cut -d' ' -f1)

if [ "$backup" = "backup" ] ; then
  backup_file_name="../backup_$(date '+%Y-%m-%d_%H-%M-%S').dmp"
  PGPASSWORD=tad pg_dump -U tad -h localhost -p $pg_port -F c -b -f $backup_file_name $DB_NAME
  echo "Created $backup_file_name"
elif [ "$backup" = "restore" ] ; then
  PGPASSWORD=$POSTGRES_ADMIN_PASS psql --cluster $pg_cluster/main -h localhost -d postgres -U postgres -c "DROP DATABASE ${DB_NAME};" || true
  PGPASSWORD=$POSTGRES_ADMIN_PASS psql --cluster $pg_cluster/main -h localhost -d postgres -U postgres -c "CREATE ROLE tad LOGIN PASSWORD 'tad' CREATEDB CREATEROLE VALID UNTIL 'infinity';" || true # no problem if role tad already exists
  PGPASSWORD=$POSTGRES_ADMIN_PASS psql --cluster $pg_cluster/main -h localhost -d postgres -U postgres -c "CREATE DATABASE ${DB_NAME} WITH ENCODING='UTF8' TEMPLATE=template0;"
  PGPASSWORD=$POSTGRES_ADMIN_PASS psql --cluster $pg_cluster/main -h localhost -d postgres -U postgres -c "alter user TAD superuser;"
  PGPASSWORD=tad pg_restore --cluster $pg_cluster/main -j 2 -U tad -d $DB_NAME -h "localhost" -O $DUMP || true # bad practice but usually there are errors that can be ignored
  PGPASSWORD=$POSTGRES_ADMIN_PASS psql --cluster $pg_cluster/main -h localhost -d postgres -U postgres -c "alter user TAD nosuperuser;"
  echo "Restored dump $DUMP"
else
  echo "Not supported $backup. No change done."
  exit 1
fi
