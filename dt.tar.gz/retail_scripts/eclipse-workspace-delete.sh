#!/bin/bash

set -e


## Config

DT_SCRIPTS_FOLDER=${DT_SCRIPTS_FOLDER:-$( readlink -f $0 | sed -E 's#/[^/]+$##' )}
. $DT_SCRIPTS_FOLDER/load_config.sh "true"


## Main

NUM_ARGS=1
if [ $# -ne $NUM_ARGS ]
then
  echo "Usage: $(basename $0) WORKSPACE_NAME" >&2
  exit 1
fi

NAME=$1

if [ -d $WORKSPACES_PATH/$NAME ]; then
  PATH_DELETE=$WORKSPACES_PATH/$NAME
elif [ -d $WORKSPACES_PATH/pushed/$NAME ] ; then
  PATH_DELETE=$WORKSPACES_PATH/pushed/$NAME
fi

DB_NAME=$( get_dbname $NAME )
pg_port=$( cat $WORKSPACES_PATH/$NAME/openbravo/config/Openbravo.properties | grep ^bbdd.url | cut -d: -f4 )

while true; do
  echo ""
  echo ""
  echo "This will delete $NAME workspace."
  echo ""
  echo "- Will delete folder: $PATH_DELETE"
  echo "- Will delete db: $DB_NAME"
  echo ""
  echo -n "Do you want to continue? (y/N)"
  read yn
  case $yn in
    y* | Y* ) break ;;
    * )   echo "Exiting." ; exit 1 ;;
  esac
done

if [ "$PATH_DELETE" != "" ] ; then
  rm -rf $PATH_DELETE
else
  echo "Not found folder to delete. Skipping step"
fi

if [ "$(uname -s | grep Darwin)" != "" ] ; then
    psql -p $pg_port -c "drop database $DB_NAME;"
else
  pg_cluster=$(pg_lsclusters | grep $pg_port | cut -d' ' -f1)
  sudo -u postgres psql --cluster $pg_cluster/main -c "drop database $DB_NAME;"
fi

echo "All done, exiting."
