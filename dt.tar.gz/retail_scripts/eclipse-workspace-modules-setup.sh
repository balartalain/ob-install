#!/bin/bash

set -e

error() {  echo -e "\n\nThere was an error.\nWhen you're finished fixing the problem, you can run again with --continue"; }
trap -- error ERR

## Config

DT_SCRIPTS_FOLDER=${DT_SCRIPTS_FOLDER:-$( readlink -f $0 | sed -E 's#/[^/]+$##' )}
. $DT_SCRIPTS_FOLDER/load_config.sh "true"


## Functions

function link_module_repo {
  REPO=$1
  ln -s ../../../$ORIGINAL_NAME/$REPO $REPO
}

function link_pi_mobile_repo {
  REPO=$1
  ln -s ../$ORIGINAL_NAME/$REPO $REPO
}

## Main

NUM_ARGS=9
if [ $# != $NUM_ARGS ]
then
  echo "Usage: $(basename $0) ORIGINAL_WORKSPACE_NAME/WORKSPACE_NAME  LINK_TO_PACK(true/false)  CONTEXT_DEFINITION DUMP SQL_SCRIPT_FILE WITH_RESET_HARD BACKUP" >&2
  exit 1
fi

ORIGINAL_NAME=$1
LINK_TO_PACK=$2
CONTEXT_DEFINITION=$3
DUMP=$4
CONTINUE=$5
SQL_SCRIPT_FILE=$6
WITH_RESET_HARD=$7
BACKUP=$8
postgresql_version=$9

CONTEXT_DEFINITION=$(echo $CONTEXT_DEFINITION | sed 's/@/ /')

if [ "$LINK_TO_PACK" == "true" ] ; then
  NAME="${ORIGINAL_NAME}-modules"
else
  NAME="${ORIGINAL_NAME}"
fi

cd $WORKSPACES_PATH
if [ "$CONTINUE" != "true" ] ; then
  mkdir $NAME
fi
cd $NAME

if [ "$(which clone_context.py | grep '^/')" = "" ] ; then
  echo -e "\n\nERROR: clone_context.py not available.\n"
  echo -e "It can installed by clonning repo: https://gitlab.com/openbravo/ci/dev_tools.git"
  echo -e "And adding it to the path, in .bashrc, or .zshrc:"
  echo -e 'export PATH=$PATH:/home/openbravo/dev_tools'
  echo -e "Fix previous line with the path to where you have clone the repo in your local"
  echo -e "\nYou need to open a new terminal, in order to be available the new path"
  exit 1
fi

if [ "$BACKUP" != "no" ] ; then
  tmpFolder='/tmp/retail_scripts_restore_backup'
  mkdir -p $tmpFolder
  echo "Uncompressing backup"
  tar xf $BACKUP -C $tmpFolder
  mkdir -p $tmpFolder/sources
  echo "Uncompressing sources"
  tar xf $tmpFolder/sources.tar* -C $tmpFolder/sources
  mv $tmpFolder/sources openbravo
  if [ -f $tmpFolder/db.dump.tar* ] ; then
    echo "Uncompressing dump"
    tar xf $tmpFolder/db.dump.tar* -C $tmpFolder/
  fi
  mv $tmpFolder/db.dump .
  DUMP=$WORKSPACES_PATH/$NAME/db.dump
  rm -r $tmpFolder
else
  if [ "$LINK_TO_PACK" == "true" ] ; then
    echo "Uncommited changes in $WORKSPACES_PATH/$ORIGINAL_NAME/openbravo:"
    git -C $WORKSPACES_PATH/$ORIGINAL_NAME/openbravo status
    clone_context.py --pristines-dir $GIT_PRISTINES_PATH --output-dir openbravo --only-erp $CONTEXT_DEFINITION
    link_pi_mobile_repo mobile-test

    for i in $RETAIL_MODS ; do
      link_module_repo openbravo/modules/$i
    done
  fi


  if [ "$WITH_RESET_HARD" = "true" ] ; then
    WITH_RESET_HARD_PARAM='--with-reset-hard'
  fi

  clone_context.py --pristines-dir $GIT_PRISTINES_PATH --output-dir openbravo --clone-automation $CONTEXT_DEFINITION $WITH_RESET_HARD_PARAM

  if [ -d openbravo/modules/org.openbravo.test.mobile.sampledata ] ; then
    rm -rf openbravo/modules/org.openbravo.retail.sampledata
  fi

  if [ "$WITH_RESET_HARD" = "true" ] ; then
    cd openbravo
    $DT_SCRIPTS_FOLDER/add_upstreams.py
    cd ..
  fi
fi

$DT_SCRIPTS_FOLDER/config-ob.sh $NAME $DUMP $SQL_SCRIPT_FILE $postgresql_version
