#!/bin/bash

set -e

error() {  echo -e "\n\nThere was an error.\nWhen you're finished fixing the problem, you can run again with --continue"; }
trap -- error ERR

## Config

DT_SCRIPTS_FOLDER=${DT_SCRIPTS_FOLDER:-$( readlink -f $0 | sed -E 's#/[^/]+$##' )}
. $DT_SCRIPTS_FOLDER/load_config.sh "true"

## Main

NUM_ARGS=7
if [ $# != $NUM_ARGS ]
then
  echo "Usage: $(basename $0) WORKSPACE_NAME CONTEXT_DEFINITION DUMP SQL_SCRIPT_FILE postgresql_version" >&2
  exit 1
fi

NAME=$1
CONTEXT_DEFINITION=$2
DUMP=$3
CONTINUE=$4
SQL_SCRIPT_FILE=$5
WITH_RESET_HARD=$6
postgresql_version=$7

CONTEXT_DEFINITION=$(echo $CONTEXT_DEFINITION | sed 's/@/ /')

cd $WORKSPACES_PATH
if [ "$CONTINUE" != "true" ] ; then
  mkdir $NAME
fi
cd $NAME

if [ "$(which clone_context.py | grep '^/')" = "" ] ; then
  echo -e "\n\nERROR: clone_context.py not available.\n"
  echo -e "It can installed by clonning repo: https://gitlab.com/openbravo/ci/dev_tools.git"
  echo -e "And adding it to the path, in .bashrc, or .zshrc:"
  echo -e 'export PATH=$PATH:/home/openbravo/dev_tools'
  echo -e "Fix previous line with the path to where you have clone the repo in your local"
  echo -e "\nYou need to open a new terminal, in order to be available the new path"
  exit 1
fi

if [ "$WITH_RESET_HARD" = "true" ] ; then
  WITH_RESET_HARD_PARAM='--with-reset-hard'
fi


clone_context.py --pristines-dir $GIT_PRISTINES_PATH --output-dir openbravo --clone-automation --only-pack $CONTEXT_DEFINITION $WITH_RESET_HARD_PARAM

if [ "$WITH_RESET_HARD" = "true" ] ; then
  cd openbravo
  $DT_SCRIPTS_FOLDER/add_upstreams.py
  cd ..
fi

$DT_SCRIPTS_FOLDER/config-ob.sh $NAME $DUMP $SQL_SCRIPT_FILE $postgresql_version
