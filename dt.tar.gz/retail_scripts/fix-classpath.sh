#!/bin/bash

set -e


## Config

DT_SCRIPTS_FOLDER=${DT_SCRIPTS_FOLDER:-$( readlink -f $0 | sed -E 's#/[^/]+$##' )}
. $DT_SCRIPTS_FOLDER/load_config.sh "true"



## Main

if [ ! -d modules ] ; then
  echo "Needs to be in an openbravo source.path"
  exit 1
fi

cp .classpath.template .classpath

sed -i.sedtemp '/<\/classpath>/d' .classpath
rm .classpath.sedtemp
for i in $(ls modules) ; do
  if [ -d modules/$i/src ] && [ "$(grep 'path="modules/'$i'/src"' .classpath)" = "" ] ; then
    echo -e "\t<classpathentry kind=\"src\" path=\"modules/$i/src\"/>" >> .classpath
  fi
done
echo '</classpath>' >> .classpath

echo "Fix of classpath done, remember the refresh in eclipse workspace"
