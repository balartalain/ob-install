#!/bin/bash

set -e


## Config

DT_SCRIPTS_FOLDER=${DT_SCRIPTS_FOLDER:-$( readlink -f $0 | sed -E 's#/[^/]+$##' )}
. $DT_SCRIPTS_FOLDER/load_config.sh "true"



## Main

if [ ! -d modules ] ; then
  echo "Needs to be in an openbravo source.path"
  exit 1
fi

git checkout -- src-test/.project
cp src-test/.classpath.template src-test/.classpath

for i in $(ls modules) ; do
  if [ -d modules/$i/src-test ] && [ "$(grep '<locationURI>MODULES\/'$i'/src-test<\/locationURI>' src-test/.project)" = "" ] ; then
    sed -i.sedtemp '/<\/linkedResources>/i \
<link><name>'$i'<\/name><type>2<\/type><locationURI>MODULES\/'$i'/src-test<\/locationURI><\/link>
' src-test/.project 
    sed -i.sedtemp '/^<\/classpath>/i \
<classpathentry kind="src" path="'$i'"\/>
' src-test/.classpath
    rm src-test/.project.sedtemp src-test/.classpath.sedtemp
  fi
done

echo "Added all src-test, remember the refresh in eclipse workspace"
