#!/usr/bin/env python3

import json, sys, os, pathlib, re
from shutil import copyfile

current_folder = str(pathlib.Path().absolute())
scripts_folder = str(pathlib.Path(__file__).parent.absolute())

if not os.path.isdir(current_folder + "/modules"):
    print("Error: this script needs to be executed in an openbravo folder")
    exit(1)

workspace_dir = "/".join(current_folder.split("/")[0:-1])
name = current_folder.split("/")[-2]
workspace_config_file = workspace_dir + "/" + name + ".code-workspace"

copyfile(
    scripts_folder + "/code-workspace-template.json",
    workspace_config_file,
)

modules_list = [
    f.path.split("/")[-1]
    for f in os.scandir(workspace_dir + "/openbravo/modules")
    if os.path.isdir(f.path + "/.git")
]

modules_list = sorted(modules_list)

folders = []
for module in modules_list:
    folders += [{"name": module, "path": "openbravo/modules/" + module}]
folders += [{"name": "openbravo", "path": "openbravo"}]

with open(workspace_config_file, "r") as f:
    data = json.load(f)

data["folders"] = folders
data["settings"]["jest.disabledWorkspaceFolders"] = modules_list

# workaround for jestrunner: https://github.com/firsttris/vscode-jest-runner/issues/69
data["settings"]["jestrunner.jestPath"] = (
    workspace_dir + "/openbravo/node_modules/jest/bin/jest.js"
)
data["settings"]["jestrunner.projectPath"] = (
    workspace_dir + "/openbravo"
)


dbname=""
dbport=0
regexDbName = re.compile(r'^bbdd.sid=(.*)')
regexDbPort = re.compile("^bbdd.url=jdbc:postgresql://localhost:(.*)")
with open(workspace_dir+'/openbravo/config/Openbravo.properties') as f:
    for line in f:
        nameResult = regexDbName.search(line)
        if nameResult:
            dbname = nameResult.group(1)
        portResult = regexDbPort.search(line)
        if portResult:
            dbport = portResult.group(1)

data["settings"]["sqltools.connections"][0]["name"] = dbname
data["settings"]["sqltools.connections"][0]["database"] = dbname
data["settings"]["sqltools.connections"][0]["port"] = int(dbport)

with open(workspace_config_file, "w") as f:
    json.dump(data, f, indent=4)
