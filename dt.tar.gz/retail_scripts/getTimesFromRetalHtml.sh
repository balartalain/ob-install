#!/bin/bash

NUM_ARGS=1
if [ $# -ne $NUM_ARGS ]
then
  echo "Usage: $(basename $0) path_to_retail.html" >&2
  exit 1
fi

retail_html_file=$1

#cat retail.html| grep -oE '\[[0-9]{1}:[0-9]{2}:[0-9]{2} - Time of suite [a-zA-Z0-9]+\]' | sed -r 's#\[([0-9]{1}:[0-9]{2}:[0-9]{2}) - Time of suite ([a-zA-Z0-9]+)\]#\2#' 

list_times=$( cat $retail_html_file | grep -oE '\[[0-9]{1}:[0-9]{2}:[0-9]{2} - Time of suite [a-zA-Z0-9]+\]|modules pgsql suite1' | sed -r 's#\[([0-9]{1}:[0-9]{2}:[0-9]{2}) - Time of suite ([a-zA-Z0-9]+)\]#{\"name\":\"\2\", \"duration\": \"\1\"}#' | tr '\n' ',' )


pack=$(echo $list_times | tr '\n' ',' | sed -r 's#(.*)modules pgsql suite1(.*)#\1#' | sed -r 's/,+$//' | sed -r 's/^,+//')
modules=$(echo $list_times | tr '\n' ',' | sed -r 's#(.*)modules pgsql suite1(.*)#\2#' | sed -r 's/,+$//'| sed -r 's/^,+//')

#pack=$(echo $pack | sed 's/,$//')
#modules=$(echo $modules | sed 's/,$//')


echo -e "{\"pack\": [ $pack ], \n\n \"modules\": [ $modules ]}"