#!/usr/bin/env python3


import json
import os
import re

try:
    import git
except:
    print("ERROR: missing gitpython lib. Install it with: 'apt install python3-git' or 'pip3 install gitpython'")
    exit(1)


def checkCorrectErpFolder(erpPath):
    if not os.path.exists(erpPath + "/modules"):
        print("Execute inside an openbravo folder")
        exit(1)


def getModulesRepos(erpPath):
    return [
        f.name
        for f in os.scandir(erpPath + "/modules")
        if f.is_dir() and os.path.exists(f.path + "/.git")
    ]


def getBranchUrlAndRevisionOfARepo(repoPath):
    repo = git.Repo(repoPath)
    remote_url = repo.remotes.origin.url
    remote_https_url = remote_url.replace(
         "git@gitlab.com:", "https://gitlab.com/")
    version = repo.head.object.hexsha
    return ( remote_https_url, version)


# Main
erpPath = os.path.abspath(os.getcwd())

checkCorrectErpFolder(erpPath)

modulesRepos = getModulesRepos(erpPath)

erpInfo = getBranchUrlAndRevisionOfARepo(erpPath)
result = {
    "erp": {
        "method": "git",
        "params": {"url": erpInfo[0], "ver": erpInfo[1]},
    },
    "mods": [],
}
if os.path.exists(erpPath + "../mobile-test"):
    automationInfo = getBranchUrlAndRevisionOfARepo(
        erpPath + "/../mobile-test")
    result.automation = {
        "javapackage": "mobile-test",
        "method": "git",
        "params": {
            "url": automationInfo[0],
            "ver": automationInfo[1]
        },
    }

for mod in modulesRepos:
    modInfo = getBranchUrlAndRevisionOfARepo(erpPath + "/modules/" + mod)
    result["mods"].append(
        {
            "javapackage": mod,
            "method": "git",
            "params": {
                "url": modInfo[0],
                "ver": modInfo[1]
            },
        }
    )

resultJson = json.dumps(result, indent=4)

erpParentPath = re.match("(^.*)/[^/]+/?", erpPath)[1]
workspaceName = re.match("^.*/([^/]+)/?", erpParentPath)[1]
fileToSave = erpParentPath + "/" + workspaceName + ".json"
with open(fileToSave, "w") as outfile:
    outfile.write(resultJson)

print("Json saved in: " + fileToSave)
