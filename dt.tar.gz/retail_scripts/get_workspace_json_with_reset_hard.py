#!/usr/bin/env python3


import json
import os
import re

try:
    import git
except:
    print("ERROR: missing gitpython lib. Install it with: 'apt install python3-git' or 'pip3 install gitpython'")
    exit(1)


def checkCorrectErpFolder(erpPath):
    if not os.path.exists(erpPath + "/modules"):
        print("Execute inside an openbravo folder")
        exit(1)


def getModulesRepos(erpPath):
    return [
        f.name
        for f in os.scandir(erpPath + "/modules")
        if f.is_dir() and os.path.exists(f.path + "/.git")
    ]


def getBranchUrlAndRevisionOfARepo(repoPath):
    repo = git.Repo(repoPath)
    branch = repo.active_branch

    remote_name = branch.tracking_branch().remote_name
    remote_url = repo.remotes[remote_name].url
    remote_https_url = remote_url.replace(
        "git@gitlab.com:", "https://gitlab.com/")

    version = repo.head.object.hexsha
    return (branch.name, remote_https_url, version)


# Main
erpPath = os.path.abspath(os.getcwd())

checkCorrectErpFolder(erpPath)

modulesRepos = getModulesRepos(erpPath)

erpInfo = getBranchUrlAndRevisionOfARepo(erpPath)
result = {
    "erp": {
        "method": "git",
        "params": {"url": erpInfo[1], "ver": erpInfo[0], "reset_hard_to": erpInfo[2]},
    },
    "mods": [],
}
if os.path.exists(erpPath + "../mobile-test"):
    automationInfo = getBranchUrlAndRevisionOfARepo(
        erpPath + "/../mobile-test")
    result.automation = {
        "javapackage": "mobile-test",
        "method": "git",
        "params": {
            "url": automationInfo[1],
            "ver": automationInfo[0],
            "reset_hard_to": automationInfo[2],
        },
    }

for mod in modulesRepos:
    modInfo = getBranchUrlAndRevisionOfARepo(erpPath + "/modules/" + mod)
    result["mods"].append(
        {
            "javapackage": mod,
            "method": "git",
            "params": {
                "url": modInfo[1],
                "ver": modInfo[0],
                "reset_hard_to": modInfo[2],
            },
        }
    )

resultJson = json.dumps(result, indent=4)

erpParentPath = re.match("(^.*)/[^/]+/?", erpPath)[1]
workspaceName = re.match("^.*/([^/]+)/?", erpParentPath)[1]
fileToSave = erpParentPath + "/" + workspaceName + ".json"
with open(fileToSave, "w") as outfile:
    outfile.write(resultJson)

print("Json saved in: " + fileToSave)
