#!/bin/bash

set -e

NUM_ARGS=2
if [ $# -ne $NUM_ARGS ]
then
  echo "Usage: $(basename $0) FIX(true/false) ALL(true/false)" >&2
  exit 1
fi

FIX=$1
ALL=$2


if [ ! -d ../../modules ] && [ ! -d modules ] ; then
  echo "ERROR: called the script from an incorrect path"
  echo "Can be called from a module to check only that module or from openbravo folder to do all the project"
  exit 1
fi


if [ "$FIX" = "true" ] ; then
  FORTMATER_APPEND=" -w"
  JSLINT_APPEND=" -f"
fi

if [ -d modules ] ; then
  PRE_PATH="modules"
else
  PRE_PATH=".."
fi

if [ "$ALL" = "true" ] ; then
  if [ "$PRE_PATH" != "modules" ]; then
    cd ../../
  fi
  modules/org.openbravo.client.kernel/jsformatter/jsformatter $FORTMATER_APPEND
  modules/org.openbravo.client.kernel/jslint/jslint $JSLINT_APPEND
  if [ "$PRE_PATH" != "modules" ]; then
    cd -
  fi
else
  $PRE_PATH/org.openbravo.client.kernel/jsformatter/jsformatter $FORTMATER_APPEND
  $PRE_PATH/org.openbravo.client.kernel/jslint/jslint $JSLINT_APPEND
fi

