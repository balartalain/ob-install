#!/bin/bash

set -e

DT_SCRIPTS_FOLDER=${DT_SCRIPTS_FOLDER:-$( readlink -f $0 | sed -E 's#/[^/]+$##' )}

UPDATE=$1
if [ "$UPDATE" = "true" ] ; then
  echo " * Checking new versions of the script"
  rev1=$(git -C $DT_SCRIPTS_FOLDER rev-parse HEAD)
  git -C $DT_SCRIPTS_FOLDER pull
  rev2=$(git -C $DT_SCRIPTS_FOLDER rev-parse HEAD)
  if [ "$rev1" != "$rev2" ] ; then
    echo -e "\n\nIMPORTANT : Detected new version, please launch again your command !! \n\n"
    exit 0
  fi
fi


RETAIL_MODS="org.openbravo.mobile.core org.openbravo.retail.config org.openbravo.retail.discounts org.openbravo.retail.pack org.openbravo.retail.poshwmanager org.openbravo.retail.posterminal org.openbravo.retail.returns org.openbravo.retail.sampledata"

if [ ! -f $DT_SCRIPTS_FOLDER/devtools.config ] ; then
  echo "ERROR: Config file $DT_SCRIPTS_FOLDER/devtools.config don't exits"
  echo "Please read the README on how to setup the scripts."
  exit 1
fi

PARAMS_TEMPLATE=$(cat $DT_SCRIPTS_FOLDER/devtools.config.template | grep -E '^export' | sed 's/export //' | cut -d'=' -f1)
PARAMS_CONFIG=$(cat $DT_SCRIPTS_FOLDER/devtools.config | grep -E '^export' | sed 's/export //' | cut -d'=' -f1 | sed 's#\(.*\)#\\b\1\\b#')
PARAM_DIFF=$( echo "$PARAMS_TEMPLATE" | grep -v "$PARAMS_CONFIG" || true )

if [ "$PARAM_DIFF" != "" ] ; then
  echo "ERROR: There are new parameters in the $DT_SCRIPTS_FOLDER/devtools.config.template, please update your $DT_SCRIPTS_FOLDER/devtools.config file."
  echo "Missing config parameters: $PARAM_DIFF"
  exit 1
fi

. $DT_SCRIPTS_FOLDER/devtools.config


get_dbname(){
  local name=$1
  echo $name | tr '-' '_' | tr '.' '_' | sed 's/^/db_/' | tr '[:upper:]' '[:lower:]'
}

