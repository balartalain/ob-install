#!/bin/bash

set -e

## Config

DT_SCRIPTS_FOLDER=${DT_SCRIPTS_FOLDER:-$( readlink -f $0 | sed -E 's#/[^/]+$##' )}
. $DT_SCRIPTS_FOLDER/load_config.sh



VALLBLANCAUSER="3073EDF96A3C42CC86C7069E379522D2";
VALLBLANCAROLE="5FA11B3DD8F04C0986C774624809C31E";
DEMOUSER="E49545E7D0A2413E90C31C2CDC2153B1";
DEMOUSERROLE="463683CFA16C40C0A4EC8CF934114146";

# Function run query
function pg_sql {
  SQL="$1"
  #echo "$SQL"
  PGPASSWORD=tad psql --cluster $pg_cluster/main -h localhost -U tad -d $DB_NAME -c "$SQL"
}

function set_property {
  PREFERENCE=$1
  VALUE=$2
  local USER=$3
  local ROLE=$4
  if [ "$USER" = "" ] ; then
    USER=null
  else
    USER="'$USER'"
  fi
  if [ "$ROLE" = "" ] ; then
    ROLE=null
  else
    ROLE="'$ROLE'"
  fi
  SQL="INSERT INTO ad_preference (ad_preference_id, ad_client_id, ad_org_id, isactive, created, createdby, updated, updatedby, ad_window_id, ad_user_id, attribute, value, property, ispropertylist, visibleat_client_id, visibleat_org_id, visibleat_role_id, selected, ad_module_id) VALUES (get_uuid(), '39363B0921BB4293B48383844325E84C', 'D270A5AC50874F8BA67A88EE977F8E3B','Y',now(), 0, now(), 0, null, $USER, null, '$VALUE', '$PREFERENCE', to_char('Y'), null, null, $ROLE, 'Y', null)"
  pg_sql "$SQL"
}

function unset_property {
  PREFERENCE=$1
  SQL="delete from AD_Preference where property='$PREFERENCE' and ad_client_id='39363B0921BB4293B48383844325E84C' and ad_org_id='D270A5AC50874F8BA67A88EE977F8E3B'"
  pg_sql "$SQL"
}

function enableAllHighVolumePreferences {
  USER=$1
  ROLE=$2
  set_property "OBPOS_remote.order" "Y" $USER $ROLE
  set_property "OBPOS_remote.discount.bp" "Y" $USER $ROLE
  set_property "OBPOS_remote.product" "Y" $USER $ROLE
  set_property "OBPOS_remote.customer" "Y" $USER $ROLE
}

function disableAllHighVolumePreferences {
  unset_property "OBPOS_remote.order"
  unset_property "OBPOS_remote.discount.bp"
  unset_property "OBPOS_remote.product"
  unset_property "OBPOS_remote.customer"
}

function activateHighVolumeMode {
  # enableAllHighVolumePreferences $VALLBLANCAUSER $VALLBLANCAROLE
  # enableAllHighVolumePreferences $DEMOUSER $DEMOUSERROL
  enableAllHighVolumePreferences
}

function deactivateHighVolumeMode {
  disableAllHighVolumePreferences
}

function activateTerminalAuthentication {
  unset_property "OBPOS_TerminalAuthentication"
}

function deactivateTerminalAuthentication {
  set_property "OBPOS_TerminalAuthentication" "N"
}

function activateDevelopment {
  pg_sql "update ad_module set isindevelopment = 'Y' where name = 'Mobile Core Infrastructure'"
  pg_sql "update ad_module set isindevelopment = 'Y' where name = 'Web POS'"
}

function disableDevelopment {
  pg_sql "update ad_module set isindevelopment = 'N' where isindevelopment = 'Y'"
}

## Main

NUM_ARGS=1
if [ $# -ne $NUM_ARGS ]
then
  echo "Usage: $(basename $0) highvol_enable/highvol_disable/terminal_auth_enable/terminal_auth_disable" >&2
  exit 1
fi

ACTION=$1

if [ ! -d modules ] ; then
  echo "This scripts needs to be executed in a openbravo folder"
  exit 1
fi

DB_NAME=$( cat config/Openbravo.properties | grep ^bbdd.sid | cut -d= -f2 )
pg_port=$( cat config/Openbravo.properties | grep ^bbdd.url | cut -d: -f4 )
pg_cluster=$(pg_lsclusters | grep $pg_port | cut -d' ' -f1)

case $ACTION in
  "highvol_enable")
    activateHighVolumeMode
    ;;
  "highvol_disable")
    deactivateHighVolumeMode
    ;;
  "terminal_auth_enable")
    activateTerminalAuthentication
    ;;
  "terminal_auth_disable")
    deactivateTerminalAuthentication
    ;;
  "development_enable")
    activateDevelopment
    ;;
  "development_disable")
    disableDevelopment
    ;;
  *)
    echo "ERROR: ACTION not recognized. Passed ($VALUE)"
    exit 1
    ;;
esac

