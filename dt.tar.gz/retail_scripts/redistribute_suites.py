#!/usr/bin/env python3

from operator import itemgetter
from collections import OrderedDict
from pathlib import Path

import json, re, sys, datetime, subprocess, os, argparse, shlex

PI_MOBILE_NUM_SUITES = 8
PI_MOBILE_MODULES_NUM_SUITES = 6
RUN_PROCESS_ERROR = "RUN_PROCESS_ERROR"

# Functions


def run_process(command, break_on_failure=True):
    """
    Runs a command as a subprocess and returns the result of execution, this is synchronous
    :param command: Bash command to be executed
    :param break_on_failure: Generates an exception if process exited with failure(exitcode != 0)
    :return: Result of execution
    """
    kwargs = {"stdout": subprocess.PIPE, "stderr": subprocess.PIPE}
    proc = subprocess.Popen(shlex.split(command), **kwargs)
    (stdout_str, stderr_str) = proc.communicate()
    return_code = proc.wait()
    if return_code != 0:
        if break_on_failure:
            print(stdout_str.decode("UTF-8"))
            raise Exception(stderr_str.decode("UTF-8"))
        return RUN_PROCESS_ERROR
    return stdout_str.decode("UTF-8")


def joinPgAndOraTimes(suites):
    new_suites = {}
    for suite in suites:
        if suite["name"] not in new_suites.keys():
            new_suites[suite["name"]] = (
                datetime.datetime.strptime(suite["duration"], "%H:%M:%S")
                - datetime.datetime(1900, 1, 1)
            ).total_seconds()

    return new_suites


def getSuitesTimes(suites):
    suite_times = {}
    for suite_name, suite_time in suites.items():
        suite_has_hv = False
        suite_has_sync = False
        suite_has_od = False
        suite_has_sa = False
        if suite_name[-2:] == "HV":
            suite_name = suite_name[:-2]
            suite_has_hv = True
        elif suite_name[-16:] == "SynchronizedMode":
            suite_name = suite_name[:-16]
            suite_has_sync = True
        elif suite_name[-2:] == "OD":
            suite_name = suite_name[:-2]
            suite_has_od = True
        elif suite_name[-2:] == "SA":
            suite_name = suite_name[:-2]
            suite_has_sa = True
        if suite_name in suite_times.keys():
            suite_times[suite_name]["time"] += suite_time
        else:
            suite_times.update({suite_name: {"name": suite_name, "time": suite_time}})
        if suite_has_hv:
            suite_times[suite_name]["HV"] = True
        if suite_has_sync:
            suite_times[suite_name]["SYNC"] = True
        if suite_has_od:
            suite_times[suite_name]["OD"] = True
        if suite_has_sa:
            suite_times[suite_name]["SA"] = True
    return suite_times


def redistributeSuites(suite_times, num_jobs):
    jobs = {}
    # idea sort the suites times from longer to sorter, and put the suite in the job that has less duration
    # sort suites by time descending
    sorted_suits = OrderedDict(
        sorted(suite_times.items(), key=lambda k: k[1]["time"], reverse=True)
    )
    # create jobs estructure
    for num in range(0, num_jobs):
        jobs.update({num: {"suites": {}, "time": 0}})
    job_min_time = 0
    for suite in sorted_suits:
        jobs[job_min_time]["suites"].update({suite: sorted_suits[suite]})
        jobs[job_min_time]["time"] += sorted_suits[suite]["time"]
        # calculate which is the job with less duration
        min_time = 999999
        for num in range(0, num_jobs):
            if jobs[num]["time"] < min_time:
                job_min_time = num
                min_time = jobs[num]["time"]
    return jobs


def replaceJobNameInFile(file_name, oldName, newName):
    with open(file_name, "r") as file:
        filedata = file.read()
    filedata = filedata.replace(oldName, newName)
    with open(file_name, "w") as file:
        file.write(filedata)


def git_move(orig, dest):
    if orig != dest:
        run_process("git mv {} {}".format(orig, dest))


def moveFile(suite, job_num, folder, num_jobs):
    suite_name = suite["name"].split(".")[-1:][0]
    for num in range(1, num_jobs + 1):
        file_orig = folder + "/job01" + str(num) + "/" + suite_name + ".java"
        file_dest = folder + "/job01" + str(job_num + 1) + "/" + suite_name + ".java"
        if Path(file_orig).exists():
            git_move(file_orig, file_dest)
            replaceJobNameInFile(
                file_dest, "job01" + str(num), "job01" + str(job_num + 1)
            )
        if "HV" in suite.keys():
            file_orig_hv = (
                folder + "/job01" + str(num) + "/" + suite_name + "HV.java"
            )
            file_dest_hv = (
                folder + "/job01" + str(job_num + 1) + "/" + suite_name + "HV.java"
            )
            if Path(file_orig_hv).exists():
                git_move(file_orig_hv, file_dest_hv)
                replaceJobNameInFile(
                    file_dest_hv, "job01" + str(num), "job01" + str(job_num + 1)
                )
        if "SYNC" in suite.keys():
            file_orig_sync = (
                folder
                + "/job01"
                + str(num)
                + "/"
                + suite_name
                + "SynchronizedMode.java"
            )
            file_dest_sync = (
                folder
                + "/job01"
                + str(job_num + 1)
                + "/"
                + suite_name
                + "SynchronizedMode.java"
            )
            if Path(file_orig_sync).exists():
                git_move(file_orig_sync, file_dest_sync)

                replaceJobNameInFile(
                    file_dest_sync, "job01" + str(num), "job01" + str(job_num + 1)
                )
        if "OD" in suite.keys():
            file_orig_od = (
                folder + "/job01" + str(num) + "/" + suite_name + "OD.java"
            )
            file_dest_od = (
                folder + "/job01" + str(job_num + 1) + "/" + suite_name + "OD.java"
            )
            if Path(file_orig_od).exists():
                git_move(file_orig_od, file_dest_od)
                replaceJobNameInFile(
                    file_dest_od, "job01" + str(num), "job01" + str(job_num + 1)
                )
        if "SA" in suite.keys():
            file_orig_sa = (
                folder + "/job01" + str(num) + "/" + suite_name + "SA.java"
            )
            file_dest_sa = (
                folder + "/job01" + str(job_num + 1) + "/" + suite_name + "SA.java"
            )
            if Path(file_orig_sa).exists():
                git_move(file_orig_sa, file_dest_sa)
                replaceJobNameInFile(
                    file_dest_sa, "job01" + str(num), "job01" + str(job_num + 1)
                )


def moveSuitesFiles(jobs, folder, num_jobs):
    for job in jobs:
        for suite in jobs[job]["suites"]:
            moveFile(jobs[job]["suites"][suite], job, folder, num_jobs)


# Main


parser = argparse.ArgumentParser(
    description="",
    epilog="""
Example of usage:
  %(prog)s -f /home/openbravo/retail.html
                        """,
    formatter_class=argparse.RawTextHelpFormatter,
)

parser.add_argument("--file", "-f", required=True, help="path to retail.html file")
args = parser.parse_args()

if args.file:
    retail_html_file = args.file


if not Path("config/OpenbravoERPTest.properties.template").exists():
    print("ERROR: This script should be called in mobile-test folder. Exiting")
    exit(1)


print("Using file:", retail_html_file)

retail_html_times_json = run_process(
    "{} {}".format("getTimesFromRetalHtml.sh", retail_html_file)
)

builds_map = json.loads(retail_html_times_json)

# with open(retail_html_file, "r") as outfile:
#     builds_map = json.load(outfile)

# old code to get n try-retail executions
# builds_map = get_n_try_retail_executions(1)

# help debug saving the json
# with open ("buils_map", "w") as outfile:
#  json.dump(builds_map, outfile)
# with open ("buils_map", "r") as outfile:
#  builds_map = json.load(outfile)
# print("json loaded from disk")

# suite_times = getSuitesTimes(builds_map)

pack_times = joinPgAndOraTimes(builds_map["pack"])
modules_times = joinPgAndOraTimes(builds_map["modules"])

suite_times = {
    "pack": getSuitesTimes(pack_times),
    "modules": getSuitesTimes(modules_times),
}

jobs_suites_pack = redistributeSuites(suite_times["pack"], PI_MOBILE_NUM_SUITES)
jobs_suites_modules = redistributeSuites(
    suite_times["modules"], PI_MOBILE_MODULES_NUM_SUITES
)

# print (json.dumps(jobs_suites_pack, indent=4, sort_keys=True))
# print (json.dumps(jobs_suites_modules, indent=4, sort_keys=True))

moveSuitesFiles(
    jobs_suites_pack,
    "src-test/org/openbravo/test/mobile/retail/pack/selenium/suites/concurrent",
    PI_MOBILE_NUM_SUITES,
)
moveSuitesFiles(
    jobs_suites_modules,
    "src-test/org/openbravo/test/mobile/retail/extmodules/selenium/suites/concurrent",
    PI_MOBILE_MODULES_NUM_SUITES,
)

max_time = 0
print("pack jobs:")
for job in jobs_suites_pack:
    job_time = jobs_suites_pack[job]["time"]
    print(
        " - job01"
        + str(job + 1)
        + ": "
        + str(datetime.timedelta(seconds=int(job_time)))
    )
    if job_time > max_time:
        max_time = job_time
    for suite in jobs_suites_pack[job]["suites"]:
        suite_name = jobs_suites_pack[job]["suites"][suite]["name"].split(".")[-1:][0]
        suite_time = jobs_suites_pack[job]["suites"][suite]["time"]
        print(
            "    - "
            + suite_name
            + ": "
            + str(datetime.timedelta(seconds=int(suite_time)))
        )

print("modules jobs:")
for job in jobs_suites_modules:
    job_time = jobs_suites_modules[job]["time"]
    print(
        " - job01"
        + str(job + 1)
        + ": "
        + str(datetime.timedelta(seconds=int(job_time)))
    )
    if job_time > max_time:
        max_time = job_time
    for suite in jobs_suites_modules[job]["suites"]:
        suite_name = jobs_suites_modules[job]["suites"][suite]["name"].split(".")[-1:][
            0
        ]
        suite_time = jobs_suites_modules[job]["suites"][suite]["time"]
        print(
            "    - "
            + suite_name
            + ": "
            + str(datetime.timedelta(seconds=int(suite_time)))
        )

print("Tests execution time: " + str(datetime.timedelta(seconds=int(max_time))))
print(
    "To this time is needed to add the compilation, clones and other enviroment setup times"
)

print("\n ** REMEMBER to review the changes and commit them")