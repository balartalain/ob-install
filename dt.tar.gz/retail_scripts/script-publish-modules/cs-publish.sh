#!/bin/bash

set -e

MIN_ARGS=1
if [ $# -ne $MIN_ARGS ]
then
  echo "Usage: $(basename $0) WORKSPACE_PATH" >&2
  exit 1
fi

ERP_FOLDER=$1

# main
 
#./uploadOBX promote $ERP_FOLDER cs $(cat modulesOrder)
./uploadOrPromoteOBX.py promote $ERP_FOLDER cs $(cat modulesOrder)

echo "All done"
