#!/usr/bin/env python2.7

import json
import urllib2
import sys

ignore_list = ["org.openbravo.mobile.core", "org.openbravo.retail.config",
               "org.openbravo.retail.discounts", "org.openbravo.retail.pack",
               "org.openbravo.retail.poshwmanager",
               "org.openbravo.retail.posterminal",
               "org.openbravo.retail.returns",
               "org.openbravo.retail.sampledata",
               "org.openbravo.financial.cashflowforecast",
               "org.openbravo.agingbalance",
               "org.openbravo.utility.multiplebpselector"]

# rev = "tip"
# file_name = "temp-try-retail"
# file_repo ="https://code.openbravo.com/erp/devel/try-mods/config/raw-file"
# json_file = ('%s/%s/%s.json' % (file_repo, rev, file_name))

json_file = sys.argv[1]

response = urllib2.urlopen('%s' % (json_file))
response_content = response.read().decode('utf8')
config = json.loads(response_content)

for mod in config['mods']:
    print(mod["javapackage"] + "*" + mod["params"]["url"])

for mod in config['deps']:
    if mod["javapackage"] not in ignore_list:
        print(mod["javapackage"] + "*" + mod["params"]["url"])
