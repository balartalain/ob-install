#!/bin/bash

set -e


MIN_ARGS=2
if [ $# -ne $MIN_ARGS ]
then
  echo "Usage: $(basename $0) WORKSPACE_PATH TAG" >&2
  exit 1
fi

ERP_FOLDER=$1
TAG=$2  # example 20Q4

FILE_WITH_MOD_TO_PACKAGE="file_with_mod_to_package.txt"
MODULES_FOLDER="$ERP_FOLDER/modules"


remove_updateinfo () {
  MOD=$1

  # grep 'UPDATEINFO' $MODULES_FOLDER/$MOD/src-db/database/sourcedata/AD_MODULE.xml && echo "$MOD" || true
  # cat a | sed -r ':a;N;$!ba;s#<!--[^-]*-->  <UPDATEINFO>[^<]*</UPDATEINFO>##g'
  echo "Removing updateinfo of module $MOD"
  sed -i.bak '/<UPDATEINFO>.*<\/UPDATEINFO>/d' $MODULES_FOLDER/$MOD/src-db/database/sourcedata/AD_MODULE.xml
  rm $MODULES_FOLDER/$MOD/src-db/database/sourcedata/AD_MODULE.xml.bak
  echo "$MOD" >> /tmp/a
  git -C $MODULES_FOLDER/$MOD diff >> /tmp/a
}

update_module_version () {
  MOD=$1

  MOD_CUR_VER=""

  MOD_CUR_VER=$(cat $MODULES_FOLDER/$MOD/src-db/database/sourcedata/AD_MODULE.xml | grep '<VERSION>' | sed -e 's/.*<VERSION><!\[CDATA\[\(.*\)\]\]><\/VERSION>/\1/')

  if [ "$MOD_CUR_VER" = "" ] ; then
    echo -e "\n\n\n###########\nNot found current version for module $MOD\nMaybe first time publish?\nPlease make first publish manually\n###########\n\n\n "
    return
  fi

  MAJOR_VER="$(echo $MOD_CUR_VER | cut -d'.' -f1,2)"
  MINOR_VER="$(echo $MOD_CUR_VER | cut -d'.' -f3)"
  NEW_MINOR="$(echo $TAG | sed -E 's_([0-9]{2})Q([1-4]{1})_\1\2000_' )" # transform 20Q4 into 204000

  CALCULATED_VER="${MAJOR_VER}.${NEW_MINOR}"

  echo "Updating version of module $MOD from $MOD_CUR_VER to $CALCULATED_VER"
  sed -i.bak 's/\(.*<VERSION><!\[CDATA\[\)[^]]*\(.*\)/\1'$CALCULATED_VER'\2/' $MODULES_FOLDER/$MOD/src-db/database/sourcedata/AD_MODULE.xml
  rm $MODULES_FOLDER/$MOD/src-db/database/sourcedata/AD_MODULE.xml.bak

}

commit_and_tag () {
  MOD=$1
  echo $MOD
  if [ -f $MODULES_FOLDER/$MOD/src-db/database/sourcedata/AD_MODULE.xml ] ; then
    MOD_NEW_VER=$(cat $MODULES_FOLDER/$MOD/src-db/database/sourcedata/AD_MODULE.xml | grep '<VERSION>' | sed -e 's/.*<VERSION><!\[CDATA\[\(.*\)\]\]><\/VERSION>/\1/')
    git -C $MODULES_FOLDER/$MOD commit -am "Update version for $TAG"
    git -C $MODULES_FOLDER/$MOD tag $MOD_NEW_VER
  fi
}

update_module_dependencies () {
  MOD=$1

  MOD_ID=""
  MOD_NEW_VER=""

  if [ "$MOD" = "erp" ] ; then
    MOD_PATH="$ERP_FOLDER"
  else
    MOD_PATH="$MODULES_FOLDER/$MOD"
  fi

  if [ -f $MOD_PATH/src-db/database/sourcedata/AD_MODULE.xml ] ; then
    MOD_ID=$(cat $MOD_PATH/src-db/database/sourcedata/AD_MODULE.xml | grep AD_MODULE_ID | sed -e 's/.*<AD_MODULE_ID><!\[CDATA\[\(.*\)\]\]><\/AD_MODULE_ID>/\1/')
    MOD_NEW_VER=$(cat $MOD_PATH/src-db/database/sourcedata/AD_MODULE.xml | grep '<VERSION>' | sed -e 's/.*<VERSION><!\[CDATA\[\(.*\)\]\]><\/VERSION>/\1/')
  fi

  #echo -e "\nUpdating dependencies for mod: $MOD. Mod id: $MOD_ID. New version: $MOD_NEW_VER"

  if [ "$MOD_NEW_VER" = "" ]  || [ "$MOD_ID" = "" ]  ; then
    #echo -e "\n\n\n###########\nNot found current version or id for module $MOD\nMaybe first time publish?\nPlease make first publish manually\n###########\n\n\n "
    return
  fi

  for MOD_DEP in $MODS_TO_PACKAGE ; do
    if [ -f $MODULES_FOLDER/$MOD_DEP/src-db/database/sourcedata/AD_MODULE_DEPENDENCY.xml ] && [ "$(cat $MODULES_FOLDER/$MOD_DEP/src-db/database/sourcedata/AD_MODULE_DEPENDENCY.xml | grep -F '<AD_DEPENDENT_MODULE_ID><![CDATA['$MOD_ID']]></AD_DEPENDENT_MODULE_ID>')" != "" ] ; then
      DEP_ID=$(cat $MODULES_FOLDER/$MOD_DEP/src-db/database/sourcedata/AD_MODULE_DEPENDENCY.xml | grep -F '<AD_DEPENDENT_MODULE_ID><![CDATA['$MOD_ID']]></AD_DEPENDENT_MODULE_ID>' | sed -E 's/<!--([^-]+)-->.*/\1/')
      dep_enforcement_none=$(cat $MODULES_FOLDER/$MOD_DEP/src-db/database/sourcedata/AD_MODULE_DEPENDENCY.xml | grep '<!--$DEP_ID-->  <DEPENDENCY_ENFORCEMENT><![CDATA[NONE]]></DEPENDENCY_ENFORCEMENT>' || true)
      if [ "$dep_enforcement_none" != "" ] ; then
        echo "INFO: Dependency from module $MOD_DEP to module $MOD ignored to updated, since has enforcement none"
        continue
      fi
      if [ -d $MODULES_FOLDER/$MOD_DEP/referencedata/translation ] ; then
        echo "INFO: Dependency from module $MOD_DEP to module $MOD ignored to updated, since it is a translation module"
        continue
      fi
      dep_manualy_ignored=$(echo "$MOD_DEP" | grep -f list_of_modules_to_ignore_update_dependencies || true)
      if [ "$dep_manualy_ignored" != "" ] ; then
        echo "INFO: Dependency from module $MOD_DEP to module $MOD ignored to updated, since it was manually set to ignore"
        continue
      fi
      if [ "$DEP_ID" = "" ] ; then
        echo -e "###########\n   ERROR: Not found DEP_ID. Dependency from module\n   '$MOD_DEP'\n   to module\n   '$MOD'\n   NOT UPDATED !!!!\n###########\n"
      else
        echo "Updating dependency from module $MOD_DEP to module $MOD to version $MOD_NEW_VER. (DEP_ID=$DEP_ID)"
        sed -i.bak 's/\(<!--'$DEP_ID'-->  <STARTVERSION><!\[CDATA\[\)[^]]*\(.*\)/\1'$MOD_NEW_VER'\2/' $MODULES_FOLDER/$MOD_DEP/src-db/database/sourcedata/AD_MODULE_DEPENDENCY.xml
        rm $MODULES_FOLDER/$MOD_DEP/src-db/database/sourcedata/AD_MODULE_DEPENDENCY.xml.bak
        #git -C $MODULES_FOLDER/$MOD_DEP diff
      fi
    fi
  done


}

reset_repo () {
  MOD=$1
  MOD_JAVA_PACKAGE=$(echo $MOD | cut -d'*' -f1)
  echo -e  "\nRemoving local commits and tags from: $MOD"
  git -C $MODULES_FOLDER/$MOD_JAVA_PACKAGE reset --hard origin/master
  git -C $MODULES_FOLDER/$MOD_JAVA_PACKAGE fetch --prune --prune-tags
}


# main
while IFS='' read -r line || [[ -n "$line" ]]; do

  if [ "$MODE" != "" ] ; then
    echo -n "To $MODE: "
  fi

  line="$( echo "$line"| sed -E 's/^ +//g' | sed -E 's/ +$//g' )" # trim line
  echo -e "Line: '$line'"

  if [ "$line" = "" ] ; then
    continue
  fi
  if [ "$line" = "###  From test to QA  ###" ] ; then
    MODE="test-to-qa"
  elif [ "$line" = "###  Last commit not a tag  ###" ] ; then
    MODE="package"
  else
    if [ "$MODE" = "" ]; then
      echo "Not found any of lines: '###  From test to QA  ###' or '###  Last commit not a tag  ###'"
      continue
    fi
    if [ "$MODE" = "package" ] ; then
      MOD=$(echo $line)
      MODS_TO_PACKAGE="$MODS_TO_PACKAGE $MOD"
    elif [ "$MODE" = "test-to-qa" ] ; then
      JAVAPACKAGE=$(echo $line | cut -d' ' -f4 )
      VERSION=$(echo $line | cut -d' ' -f2 )
      MODS_TO_PROMOTE="$MODS_TO_PROMOTE $JAVAPACKAGE:$VERSION"
    fi
  fi
done < "$FILE_WITH_MOD_TO_PACKAGE"


date

echo -e "\n\n** Checking all modules to publish are in the workspace\n"
for MOD in $MODS_TO_PACKAGE ; do
  MOD_JAVA_PACKAGE=$(echo $MOD | cut -d'*' -f1)
  if [ ! -d "$MODULES_FOLDER/$MOD_JAVA_PACKAGE" ] ; then
     CONTINUE="False"
     echo "Missing module $MOD"
  fi
done
for MOD in $MODS_TO_PROMOTE ; do
  MOD_JAVA_PACKAGE=$(echo $MOD | cut -d':' -f1)
  if [ ! -d "$MODULES_FOLDER/$MOD_JAVA_PACKAGE" ] ; then
     CONTINUE="False"
     echo "Missing module $MOD"
  fi
done
if [ "$CONTINUE" = "False" ] ; then
  echo -e "\n\nERROR: add the missing repos to the corresponding team json\n update the merged json\n Push the changes. Run:\ndt add-new-modules-to-workspace --context-definition: merged/merged.json\n"
  exit 1
fi

date

echo -e "\n\n** Checking all modules to publish have ad_module.xml\n"
for MOD in $MODS_TO_PACKAGE ; do
  MOD_JAVA_PACKAGE=$(echo $MOD | cut -d'*' -f1)
  if [ ! -f "$MODULES_FOLDER/$MOD_JAVA_PACKAGE/src-db/database/sourcedata/AD_MODULE.xml" ] ; then
     CONTINUE="False"
     echo "Missing AD_MODULE.xml in $MOD"
  fi
done
for MOD in $MODS_TO_PROMOTE ; do
  MOD_JAVA_PACKAGE=$(echo $MOD | cut -d':' -f1)
  if [ ! -f "$MODULES_FOLDER/$MOD_JAVA_PACKAGE/src-db/database/sourcedata/AD_MODULE.xml" ] ; then
     CONTINUE="False"
     echo "Missing AD_MODULE.xml in $MOD"
  fi
done
if [ "$CONTINUE" = "False" ] ; then
  echo -e "\n\nERROR: some repos don't have AD_MODULE.xml , probably not ready to be published\n"
  exit 1
fi

date

echo -e "\n\n** Revert previous executions\n"
for MOD in $MODS_TO_PACKAGE ; do
  reset_repo $MOD
done

date

echo -e "\n\n** Updating version\n"
for MOD in $MODS_TO_PACKAGE ; do
  update_module_version $MOD
done

date

echo -e "\n\n** Updating dependencies\n"
ALL_MODULES="erp $(ls $MODULES_FOLDER)"
for MOD in $ALL_MODULES ; do
  update_module_dependencies $MOD
done

date

echo -e "\n\n** Ensure updateinfo is empty\n"
echo '' > /tmp/a
for MOD in $MODS_TO_PACKAGE ; do
  remove_update_info_manualy_ignored=$(echo "$MOD" | grep -f list_of_modules_to_ignore_update_updateinfo || true)
  if [ "$remove_update_info_manualy_ignored" != "" ] ; then
    echo "INFO: Skip remove the updateinfo for module $MOD, since it was manually set to ignore"
    continue
  fi
  remove_updateinfo $MOD
done


echo -e "\n\n** Commit and tag changes\n"
for MOD in $MODS_TO_PACKAGE ; do
  commit_and_tag $MOD
done

date

echo -e "\n\n** Update new versions and dependencies into db\n"
ant -f $ERP_FOLDER/build.xml update.database -Dforce=yes

date

echo -e "\n\n** Check modules consistency\n"
ant -f $ERP_FOLDER/build.xml check.module.consistency

date

echo -e "\n\n** Create obx\n"
for MOD in $MODS_TO_PACKAGE ; do
  ant -f $ERP_FOLDER/build.xml package.module -Dmodule=$MOD
done

date

echo -e "\n\n** Sort obx to upload based on dependencies\n"
MOD_LIST=""
for MOD in $MODS_TO_PACKAGE; do
  ID=$(grep AD_MODULE_ID $ERP_FOLDER/modules/$MOD/src-db/database/sourcedata/AD_MODULE.xml | sed -e 's/.*<AD_MODULE_ID><!\[CDATA\[\(.*\)\]\]><\/AD_MODULE_ID>/\1/')
  if [ "$(echo $MOD | grep 'org.openbravo.reporting.tools' )" != "" ] ; then
    echo "INFO: Module $MOD ignored for upload OBX as detected reporting.tools*"
  else
    MOD_LIST="$MOD_LIST $ID"
  fi
done
LIST="($(echo $MOD_LIST | tr ' ' '|'))"
echo -n '' > modulesOrder
for i in $MODS_TO_PACKAGE; do
  for MOD in $MODS_TO_PACKAGE; do
    ID=$(grep AD_MODULE_ID $ERP_FOLDER/modules/$MOD/src-db/database/sourcedata/AD_MODULE.xml | sed -e 's/.*<AD_MODULE_ID><!\[CDATA\[\(.*\)\]\]><\/AD_MODULE_ID>/\1/')
    if [ "" != "$(echo $ID | grep -E $LIST || echo -n '')" ] ; then
      if [ "" = "$(cat $ERP_FOLDER/modules/$MOD/src-db/database/sourcedata/AD_MODULE_DEPENDENCY.xml | grep AD_DEPENDENT_MODULE_ID | grep -E $LIST || echo -n '')" ] ; then
        echo "$(ls $ERP_FOLDER/${MOD}-*.obx)" >> modulesOrder
        LIST=$(echo $LIST | sed "s/$ID//" | sed 's/(|/(/g' | sed 's/|)/)/g' | sed 's/||/|/')
      fi
    fi
  done
done

date

echo -e "\n\n**  Sort obx to upload based on dependencies for Promote\n"
echo -n '' > modulesOrderPromote
MOD_LIST=""
for MOD_VER in $MODS_TO_PROMOTE; do
    MOD=$(echo $MOD_VER | cut -d':' -f1)
    VERSION=$(echo $MOD_VER | cut -d':' -f2)
  ID=$(grep AD_MODULE_ID $ERP_FOLDER/modules/$MOD/src-db/database/sourcedata/AD_MODULE.xml | sed -e 's/.*<AD_MODULE_ID><!\[CDATA\[\(.*\)\]\]><\/AD_MODULE_ID>/\1/')
  MOD_LIST="$MOD_LIST $ID"
done
LIST="($(echo $MOD_LIST | tr ' ' '|'))"
for i in $MODS_TO_PROMOTE; do
  for MOD_VER in $MODS_TO_PROMOTE; do
    MOD=$(echo $MOD_VER | cut -d':' -f1)
    VERSION=$(echo $MOD_VER | cut -d':' -f2)
    ID=$(grep AD_MODULE_ID $ERP_FOLDER/modules/$MOD/src-db/database/sourcedata/AD_MODULE.xml | sed -e 's/.*<AD_MODULE_ID><!\[CDATA\[\(.*\)\]\]><\/AD_MODULE_ID>/\1/')
    if [ "" != "$(echo $ID | grep -E $LIST || echo -n '')" ] ; then
      if [ "" = "$(cat $ERP_FOLDER/modules/$MOD/src-db/database/sourcedata/AD_MODULE_DEPENDENCY.xml | grep AD_DEPENDENT_MODULE_ID | grep -E $LIST || echo -n '')" ] ; then
        echo "$ERP_FOLDER/${MOD}-${VERSION}.obx" >> modulesOrderPromote
        LIST=$(echo $LIST | sed "s/$ID//" | sed 's/(|/(/g' | sed 's/|)/)/g' | sed 's/||/|/')
      fi
    fi
  done
done

date

echo "All done"
