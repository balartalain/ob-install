#!/bin/bash

set -e


MIN_ARGS=1
if [ $# -ne $MIN_ARGS ]
then
  echo "Usage: $(basename $0) WORKSPACE_PATH" >&2
  exit 1
fi

ERP_FOLDER=$1


FILE_MODIFIED_MODULES="modifiedModules"
FILE_WITH_MOD_TO_PACKAGE="file_with_mod_to_package.txt"
WORK_FOLDER="$ERP_FOLDER/modules"

push_to_repo () {
  MOD=$1
  echo "Repo: $MOD"
  git -C $WORK_FOLDER/$MOD push
  git -C $WORK_FOLDER/$MOD push --tags
  echo ""
}

# main
 
while IFS='' read -r line || [[ -n "$line" ]]; do
    if [ "$MODE" != "" ] ; then
      echo -n "To $MODE: "
    fi

    line="$( echo "$line"| sed -E 's/^ +//g' | sed -E 's/ +$//g' )" # trim line
    echo -e "Line: '$line'"
    if [ "$line" = "" ] ; then
      echo "skiped line $line"
      continue
    fi
    if [ "$line" = "###  From test to QA  ###" ] ; then
      MODE="test-to-qa"
    elif [ "$line" = "###  Last commit not a tag  ###" ] ; then
      MODE="package"
    else
      if [ "$MODE" = "" ]; then
        echo "Not found any of lines: '###  From Test to QA  ###' or '###  Last commit not a tag  ###'"
        continue
      fi
      if [ "$MODE" = "package" ] ; then
        MOD=$(echo $line)
        if [ -f $WORK_FOLDER/$MOD/src-db/database/sourcedata/AD_MODULE.xml ] ; then
          MODS_TO_PACKAGE="$MODS_TO_PACKAGE $MOD"
        else
          echo -e "\n\n\n###########\nModule $MOD don't look like an openbravo module\nDon't have src-db/database/sourcedata/AD_MODULE.xml. Ignoring it\n###########\n\n\n "
        fi
      fi
    fi
done < "$FILE_WITH_MOD_TO_PACKAGE"

echo -e "\n\n** Promote modules from test to qa\n"
#./uploadOBX promote $ERP_FOLDER qa $(cat modulesOrderPromote)
time ./uploadOrPromoteOBX.py promote $ERP_FOLDER qa $(cat modulesOrderPromote)

echo -e "\n\n** Upload obx\n"
#./uploadOBX upload qa $(cat modulesOrder)
time ./uploadOrPromoteOBX.py upload qa $(cat modulesOrder)

echo -e "\n\n** Push to repos\n"
for MOD in $MODS_TO_PACKAGE ; do
  #push_to_repo $MOD
  echo push_to_repo $MOD
done

echo "All done"
