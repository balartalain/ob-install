#!/bin/bash

set -e

MIN_ARGS=1
if [ $# -ne $MIN_ARGS ]
then
  echo "Usage: $(basename $0) WORKSPACE_PATH" >&2
  exit 1
fi

ERP_FOLDER=$1


FILE_WITH_MOD_TO_PACKAGE="file_with_mod_to_package.txt"
WORK_FOLDER="$ERP_FOLDER/modules"


# main
 
while IFS='' read -r line || [[ -n "$line" ]]; do
    #echo -e "\nProcessing line [with mode $MODE]: $line"
    if [ "$line" = "" ] ; then
      #echo "skiped line $line"
      continue
    fi
    if [ "$line" = "###  From Test to QA  ###" ] ; then
      MODE="test-to-qa"
    elif [ "$line" = "###  Last commit not a tag  ###" ] ; then
      MODE="package"
    elif [ "$line" = "###  From QA to QAA  ###" ] ; then
      MODE="publish"
    else
      if [ "$MODE" = "" ]; then
        echo "Not found any of lines: '###  From Test to QA  ###' or '###  Last commit not a tag  ###'"
        continue
      fi
      if [ "$MODE" = "publish" ] ; then
        JAVAPACKAGE=$(echo $line | cut -d' ' -f4 )
        VERSION=$(echo $line | cut -d' ' -f2 )
        if [ -f $WORK_FOLDER/$JAVAPACKAGE/src-db/database/sourcedata/AD_MODULE.xml ] ; then
          MODS_TO_PUBLISH="$MODS_TO_PUBLISH $JAVAPACKAGE:$VERSION"
        else
          echo -e "This module needs to be published manually: \t$line"
        fi
      fi
    fi
done < "$FILE_WITH_MOD_TO_PACKAGE"



echo -e "\n\n** Publish: Sort obx to upload based on dependencies\n"
echo -n '' > modulesOrder
MOD_LIST=""
for MOD_VER in $MODS_TO_PUBLISH; do
    MOD=$(echo $MOD_VER | cut -d':' -f1)
    VERSION=$(echo $MOD_VER | cut -d':' -f2)
  ID=$(grep AD_MODULE_ID $ERP_FOLDER/modules/$MOD/src-db/database/sourcedata/AD_MODULE.xml | sed -e 's/.*<AD_MODULE_ID><!\[CDATA\[\(.*\)\]\]><\/AD_MODULE_ID>/\1/')
  MOD_LIST="$MOD_LIST $ID"
done
LIST="($(echo $MOD_LIST | tr ' ' '|'))"
for i in $MODS_TO_PUBLISH; do
  for MOD_VER in $MODS_TO_PUBLISH; do
    MOD=$(echo $MOD_VER | cut -d':' -f1)
    VERSION=$(echo $MOD_VER | cut -d':' -f2)
    ID=$(grep AD_MODULE_ID $ERP_FOLDER/modules/$MOD/src-db/database/sourcedata/AD_MODULE.xml | sed -e 's/.*<AD_MODULE_ID><!\[CDATA\[\(.*\)\]\]><\/AD_MODULE_ID>/\1/')
    if [ "" != "$(echo $ID | grep -E $LIST || echo -n '')" ] ; then
      if [ "" = "$(cat $ERP_FOLDER/modules/$MOD/src-db/database/sourcedata/AD_MODULE_DEPENDENCY.xml | grep AD_DEPENDENT_MODULE_ID | grep -E $LIST || echo -n '')" ] ; then
        echo "$ERP_FOLDER/${MOD}-${VERSION}.obx" >> modulesOrder
        LIST=$(echo $LIST | sed "s/$ID//" | sed 's/(|/(/g' | sed 's/|)/)/g' | sed 's/||/|/')
      fi
    fi
  done
done

echo "All done"