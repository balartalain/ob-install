#!/usr/bin/env python2

# script: fixed modules versions

import json
import re
import os
import sys
from mercurial import ui, hg, node


def parse_url(url, javapackage=""):
    return javapackage


def process_mods(mods):
    for mod in mods:
        #revisionAskedByDev = mod["params"]["ver"]
        revisionAskedByDev = "default" # allways take the latest version of the repo (default branch)
        repo_url = parse_url(mod["params"]["url"], mod["javapackage"])
        try:
            # get the changeset information from code.openbravo.com
            peer = hg.peer(ui.ui(), {}, repo_url)
            id = node.short(peer.lookup(revisionAskedByDev))
        except Exception as ex:
            print(ex)
            print("Hint: verify that the revision asked by the developer ('{}'), exists in the server ('{}')".format(
                  revisionAskedByDev, repo_url))
            sys.exit(1)
        # update the field with the node id
        mod["params"]["ver"] = id
        print('%s/rev/%s (%s)' %
              (repo_url, mod["params"]["ver"], revisionAskedByDev))


def process_json(config):
    print("Repository revisions to be tested:")
    if "mods" in config.keys():
        print("modules ('mods'):")
        process_mods(config["mods"])
    if "deps" in config.keys():
        print("dependencies ('deps'):")
        process_mods(config["deps"])


file_json = sys.argv[1];
with open(file_json, 'r') as f:
    config = json.load(f)

print("")
process_json(config)
print("")

with open(file_json, "w") as f:
    f.write(json.dumps(config, indent=4))
