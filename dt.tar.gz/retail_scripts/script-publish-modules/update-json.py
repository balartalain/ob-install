#!/usr/bin/env python3

# script: fixed modules versions

import json
import re
import os
import sys
import subprocess

modules_managed_by_rm = [
    'https://gitlab.com/openbravo/product/openbravo',
    'https://gitlab.com/openbravo/ci/mobile-test',
    'https://gitlab.com/openbravo/product/pmods/org.openbravo.retail.posterminal',
    'https://gitlab.com/openbravo/product/pmods/org.openbravo.retail.discounts',
    'https://gitlab.com/openbravo/product/pmods/org.openbravo.retail.config',
    'https://gitlab.com/openbravo/product/pmods/org.openbravo.mobile.core',
    'https://gitlab.com/openbravo/product/pmods/org.openbravo.retail.pack',
    'https://gitlab.com/openbravo/product/pmods/org.openbravo.retail.poshwmanager',
    'https://gitlab.com/openbravo/product/pmods/org.openbravo.retail.returns',
    'https://gitlab.com/openbravo/product/pmods/org.openbravo.pos2',
    'https://gitlab.com/openbravo/product/pmods/org.openbravo.pos2.sampledata',
    'https://gitlab.com/openbravo/product/pmods/org.openbravo.core2',
    'https://gitlab.com/openbravo/product/pmods/org.openbravo.retail.sampledata'
    ]

def process_mod(mod):
    repo_url = mod["params"]["url"]
    if repo_url in modules_managed_by_rm:
        revisionAskedByDev = 'release/'+tag
        id = revisionAskedByDev
    else:
        revisionAskedByDev = "master" # allways take the latest version of the repo (default branch)
        try:
            repo_url_ssh = repo_url.replace("https://gitlab.com/", "git@gitlab.com:")
            id = subprocess.run(['git', 'ls-remote', repo_url_ssh, revisionAskedByDev], stdout=subprocess.PIPE).stdout.decode('utf-8')[:-1]
            id = id.split('\t')[0]
        except Exception as ex:
            print(ex)
            print("Hint: verify that the revision asked by the developer ('{}'), exists in the server ('{}')".format(
                revisionAskedByDev, repo_url))
            sys.exit(1)
        # update the field with the node id
    mod["params"]["ver"] = id
    print('%s/rev/%s (%s)' %
          (repo_url, mod["params"]["ver"], revisionAskedByDev))


def process_json(config):
    print("erp:")
    process_mod(config["erp"])

    if "automation" in config:
        print("mobile-test:")
        process_mod(config["automation"][0])

    print("mods:")
    for mod in config["mods"]:
        process_mod(mod)

    print("deps:")
    for mod in config["deps"]:
        process_mod(mod)


file_json = sys.argv[1]
with open(file_json, 'r') as f:
    config = json.load(f)

tag = re.compile('.*(try-retail|pos2-modules)-([0-9]{2}Q[0-4]{1}).json').match(file_json)[2]

print('\nCalculted release tag based on json name: ' + tag)

print("")
process_json(config)
print("")

with open(file_json, "w") as f:
    f.write(json.dumps(config, indent=4))
