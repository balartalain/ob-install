#!/usr/bin/env python3

import fnmatch
import os
import sys
import re
import requests
import zipfile
import xml.etree.ElementTree as ElementTree

# TODO: Update to https before merging
CR_URL = "http://localhost:8080/openbravo/org.openbravo.utility.centralrepository"
CR_URL = "http://centralrepository.openbravo.com/openbravo/org.openbravo.utility.centralrepository"
CREDENTIALS_FILE = "~/.sso_user"


def main():
    action, workspace_folder, status, module_files = get_validated_args(sys.argv)

    user, password = get_user_credentials()

    session = requests.Session()

    for file in module_files:
        print("")

        obx_version = get_obx_version(file)
        if obx_version is None:
            print(
                f"{file} does not have a standard obx version, no action will be performed. For example: module-javapackage-1.0.1.obx"
            )
            sys.exit(1)

        if action == "promote":
            print(f"Promoting {file} ...")
            module_id = get_mod_id(workspace_folder, file)
            module_version = obx_version
        else:
            # This first part is done to make sure we're not trying to upload a file with a mismatch vesion
            print(f"Uploading {file} ...")
            module_id, module_version = get_mod_id_and_version_for_upload(
                file, obx_version
            )

        print(f"AD_MODULE_ID='{module_id}'")
        if module_id is None:
            print(f"Could not retrieve module id. Exiting {action} process.")
            sys.exit(1)

        maturity_status = get_maturity_status(status)

        if action == "promote":
            request_response = promote_module(
                user, password, session, module_id, module_version, maturity_status
            )
        else:
            request_response = upload_module(
                user, password, session, file, maturity_status
            )

        try:
            result = request_response.json()
        except:
            result = None

        if result != None and request_response.status_code == 200 and result["files"] == 1:
            print(f"{action} to {status} module was completed successfully.")
        else:
            error_msg = None
            if result is None:
                if request_response.status_code == 401:
                    error_msg = f"[Error code: {request_response.status_code} Message: Unauthorized call, check credentials]"
                else:
                    error_msg = f"[Error code: {request_response.status_code} Message: {request_response.text}]"
            else:
                error_msg = result["errors"]
            print(f"Failed to {action} the obx. {error_msg}")
            sys.exit(1)


def get_validated_args(args):
    n_args = len(args)
    expected_args = 4 if n_args > 1 and args[1] == "promote" else 3
    if n_args < expected_args:
        print_usage(args[0])
        sys.exit(1)

    action = args[1]
    if action == "promote":
        workspace_folder = args[2]
        status = args[3]
        module_files = args[4:]
    elif action == "upload":
        status = args[2]
        module_files = args[3:]
        workspace_folder = None
    else:
        print(f"Action not supported: {action}")
        print_usage(args[0])
        sys.exit(1)

    return action, workspace_folder, status, module_files


def print_usage(script_path):
    print(
        f"Usage: {os.path.basename(script_path)} upload/promote [erp_folder] test|qa|qaa|cs obx_file1 [obx_file2]*"
    )


def get_maturity_status(status):
    status_correlation = {"cs": 500, "qaa": 200, "qa": 150, "test": 100}
    if status not in status_correlation:
        print(f"Maturity status {status} is not supported.")
        sys.exit(1)

    return status_correlation[status]


def upload_module(user, password, session, file, maturity_status):
    with open(file, "rb") as f:
        r = session.post(
            f"{CR_URL}/PublishModuleBundle",
            data={
                "maturity": maturity_status,
                "numOfFiles": 1,
                "skipDependencyBundle": True,
            },
            files={"obx0": f},
            auth=(user, password),
        )
    return r


def promote_module(user, password, session, module_id, version, maturity_status):
    return session.post(
        f"{CR_URL}/PromoteModule",
        data={
            "newMaturityStatus": maturity_status,
            "moduleId": module_id,
            "version": version,
        },
        auth=(user, password),
    )


def get_mod_id_and_version_for_upload(file, obx_version):
    with zipfile.ZipFile(file, "r") as zip_ref:
        matched_files = fnmatch.filter(zip_ref.namelist(), "*/sourcedata/AD_MODULE.xml")
        if not matched_files:
            print(f"Missing AD_MODULE.xml file in the obx {file}.")
            sys.exit(1)
        temp_xml = zip_ref.read(matched_files[0])
        root = ElementTree.fromstring(temp_xml).find("AD_MODULE")
        module_id = root.find("AD_MODULE_ID").text
        version = root.find("VERSION").text

    if version != obx_version:
        print(
            f"Version mismatch between obx file name ({obx_version}) and version in the ad_module.xml of the obx ({version})"
        )
        sys.exit(1)
    return module_id, version


def get_mod_id(erp_folder, file):
    module_javapackage = re.search(r"([^\\/-]+)-[^\\/]+$", os.path.abspath(file)).group(
        1
    )
    module_id = None
    ad_module_path = f"{erp_folder}/modules/{module_javapackage}/src-db/database/sourcedata/AD_MODULE.xml"
    # openbravo core has a different path to modules
    if module_javapackage == "org.openbravo":
        ad_module_path = f"{erp_folder}/src-db/database/sourcedata/AD_MODULE.xml"
    if not os.path.isfile(ad_module_path):
        print(
            f"AD_MODULE file does not exist for module {module_javapackage} at {ad_module_path}."
        )
        return module_id
    with open(
        ad_module_path,
        "r",
    ) as f:
        root = ElementTree.fromstring(f.read()).find("AD_MODULE")
        module_id = root.find("AD_MODULE_ID").text
    return module_id


def get_obx_version(file):
    obx_version_match = re.search(r".*-(\d*\.\d*).*(\.\d*)\.obx", file)
    if obx_version_match is None:
        return None

    return obx_version_match.group(1) + obx_version_match.group(2)


def get_user_credentials():
    filepath = os.path.expanduser(CREDENTIALS_FILE)
    if not os.path.isfile(filepath):
        print(f"User and password file has not been configured at path: {filepath}")
        sys.exit(1)
    with open(filepath, "r") as f:
        lines = f.readlines()
        user = lines[0].split("=")[1].strip()
        password = lines[1].split("=")[1].strip()
    return user, password


if __name__ == "__main__":
    main()
