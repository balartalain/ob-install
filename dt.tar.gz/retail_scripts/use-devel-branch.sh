#!/bin/bash

set -e


## Config

DT_SCRIPTS_FOLDER=${DT_SCRIPTS_FOLDER:-$( readlink -f $0 | sed -E 's#/[^/]+$##' )}
. $DT_SCRIPTS_FOLDER/load_config.sh "true"

num_args=1
if [ $# -lt $num_args ]
then
  echo "Usage: $(basename $0) use [branch]" >&2
  exit 1
fi

use=$1  # true or false if use the personal fork or revert it
branch=$2 # optional, if we want to use/create a branch in the fork

## Main

if [ "$use" = "true" ] ; then
  current_origin=$(git config --get remote.origin.url )
  if [ "$(echo $current_origin | grep '/product/')" ] ; then
    new_origin=$(echo $current_origin | sed -r 's#/product/#/devel/#' )
  elif [ "$(echo $current_origin | grep '/ci/')" ] ; then
    new_origin=$(echo $current_origin | sed -r 's#/ci/#/devel/ci/#' )
  elif [ "$(echo $current_origin | grep 'openbravo/customers/')" ] ; then
    new_origin=$(echo $current_origin )
  else
    echo "Not supported origin url"
    exit 1
  fi

  if [ "$new_origin" != "$current_origin" ] ; then
    git remote add upstream $current_origin
    git remote set-url origin $new_origin
  fi
  git fetch --all --prune
  if [ "$branch" != "" ] ; then
    if [ "$(git branch -a | grep 'remotes/origin/'$branch'$')" != "" ] ; then
      git checkout $branch
    else
      git checkout -b $branch
      git branch --set-upstream-to=origin/$branch $branch
    fi
  fi
elif [ "$use" = "false" ] ; then
  current_upstream=$(git config --get remote.upstream.url || echo "")
  if [ "$current_upstream" != "" ] ; then
    git remote set-url origin $current_upstream
    git remote remove upstream
  fi
  git fetch --all --prune
  git checkout master
else
  echo "Not supported use. No change done."
  exit 1
fi
